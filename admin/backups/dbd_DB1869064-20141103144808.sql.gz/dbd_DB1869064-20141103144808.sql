-- XT-Commerce & compatible
--
-- Database Backup Ver. 1.92 (c) by web28 - www.rpa-com.de
-- Spezial - Fensterdichtungen für alle Fenstertarten
-- Fensterdichtungen.org - Stareno GmbH
--
-- Database: DB1869064
-- Database Server: rdbms.strato.de
--
-- MySQL-Client-Version: 5.0.96
--
-- Backup Date: 03.11.2014 14:48:08

DROP TABLE IF EXISTS `address_book`;
CREATE TABLE `address_book` (
  `address_book_id` int(11) NOT NULL AUTO_INCREMENT,
  `customers_id` int(11) NOT NULL,
  `entry_gender` char(1) COLLATE latin1_german1_ci NOT NULL,
  `entry_company` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `entry_firstname` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `entry_lastname` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `entry_street_address` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `entry_suburb` varchar(32) COLLATE latin1_german1_ci DEFAULT NULL,
  `entry_postcode` varchar(10) COLLATE latin1_german1_ci NOT NULL,
  `entry_city` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `entry_state` varchar(32) COLLATE latin1_german1_ci DEFAULT NULL,
  `entry_country_id` int(11) NOT NULL DEFAULT '0',
  `entry_zone_id` int(11) NOT NULL DEFAULT '0',
  `address_date_added` datetime DEFAULT '0000-00-00 00:00:00',
  `address_last_modified` datetime DEFAULT '0000-00-00 00:00:00',
  `address_class` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  PRIMARY KEY (`address_book_id`),
  KEY `idx_address_book_customers_id` (`customers_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `address_book` DISABLE KEYS */;
INSERT INTO `address_book` (`address_book_id`, `customers_id`, `entry_gender`, `entry_company`, `entry_firstname`, `entry_lastname`, `entry_street_address`, `entry_suburb`, `entry_postcode`, `entry_city`, `entry_state`, `entry_country_id`, `entry_zone_id`, `address_date_added`, `address_last_modified`, `address_class`) VALUES ('1','1','m','Fensterdichtungen.org - Stareno GmbH','Hardy','Zich','Hohldrift 17','','33181','Bad Wünnenberg','','81','0','0000-00-00 00:00:00','2014-11-01 17:03:52','');
INSERT INTO `address_book` (`address_book_id`, `customers_id`, `entry_gender`, `entry_company`, `entry_firstname`, `entry_lastname`, `entry_street_address`, `entry_suburb`, `entry_postcode`, `entry_city`, `entry_state`, `entry_country_id`, `entry_zone_id`, `address_date_added`, `address_last_modified`, `address_class`) VALUES ('3','3','m','','Hardy','Zich','Hohldrift 3','','33181','Helmern',NULL,'81','0','2014-10-16 22:51:59','2014-10-16 22:51:59','');
INSERT INTO `address_book` (`address_book_id`, `customers_id`, `entry_gender`, `entry_company`, `entry_firstname`, `entry_lastname`, `entry_street_address`, `entry_suburb`, `entry_postcode`, `entry_city`, `entry_state`, `entry_country_id`, `entry_zone_id`, `address_date_added`, `address_last_modified`, `address_class`) VALUES ('4','4','m','','Bernhard','Dietzel','Am Sandweg 11','','36469','Tiefenort',NULL,'81','0','2014-11-01 17:41:43','2014-11-01 17:41:43','');
INSERT INTO `address_book` (`address_book_id`, `customers_id`, `entry_gender`, `entry_company`, `entry_firstname`, `entry_lastname`, `entry_street_address`, `entry_suburb`, `entry_postcode`, `entry_city`, `entry_state`, `entry_country_id`, `entry_zone_id`, `address_date_added`, `address_last_modified`, `address_class`) VALUES ('5','5','m','','Ulf','Jakubke','Sakrower Landstraße 41','','14089','Berlin',NULL,'81','0','2014-11-02 19:47:44','2014-11-02 19:47:44','');
INSERT INTO `address_book` (`address_book_id`, `customers_id`, `entry_gender`, `entry_company`, `entry_firstname`, `entry_lastname`, `entry_street_address`, `entry_suburb`, `entry_postcode`, `entry_city`, `entry_state`, `entry_country_id`, `entry_zone_id`, `address_date_added`, `address_last_modified`, `address_class`) VALUES ('6','6','m','','Frank','Mladek','Wupperstraße 25','','16515','Oranienburg',NULL,'81','0','2014-11-02 22:13:39','2014-11-02 22:13:39','');
INSERT INTO `address_book` (`address_book_id`, `customers_id`, `entry_gender`, `entry_company`, `entry_firstname`, `entry_lastname`, `entry_street_address`, `entry_suburb`, `entry_postcode`, `entry_city`, `entry_state`, `entry_country_id`, `entry_zone_id`, `address_date_added`, `address_last_modified`, `address_class`) VALUES ('7','7','m','','Hans-Ulrich','Tappe','Roesgenstraße','Ahrweiler','53474','Bad Neuemahr-Ahrweiler',NULL,'81','0','2014-11-03 09:37:55','2014-11-03 09:37:55','');
INSERT INTO `address_book` (`address_book_id`, `customers_id`, `entry_gender`, `entry_company`, `entry_firstname`, `entry_lastname`, `entry_street_address`, `entry_suburb`, `entry_postcode`, `entry_city`, `entry_state`, `entry_country_id`, `entry_zone_id`, `address_date_added`, `address_last_modified`, `address_class`) VALUES ('8','8','m','','willi','kröner','keglerstr. 22','','89537','giengen',NULL,'81','0','2014-11-03 10:17:12','2014-11-03 10:17:12','');
INSERT INTO `address_book` (`address_book_id`, `customers_id`, `entry_gender`, `entry_company`, `entry_firstname`, `entry_lastname`, `entry_street_address`, `entry_suburb`, `entry_postcode`, `entry_city`, `entry_state`, `entry_country_id`, `entry_zone_id`, `address_date_added`, `address_last_modified`, `address_class`) VALUES ('9','9','m','','konrad','Bremer','Ringelnatzweg 1','','30926','Seelze',NULL,'81','0','2014-11-03 12:02:39','2014-11-03 12:02:39','');
/*!40000 ALTER TABLE `address_book` ENABLE KEYS */;

DROP TABLE IF EXISTS `address_format`;
CREATE TABLE `address_format` (
  `address_format_id` int(11) NOT NULL AUTO_INCREMENT,
  `address_format` varchar(128) COLLATE latin1_german1_ci NOT NULL,
  `address_summary` varchar(48) COLLATE latin1_german1_ci NOT NULL,
  PRIMARY KEY (`address_format_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `address_format` DISABLE KEYS */;
INSERT INTO `address_format` (`address_format_id`, `address_format`, `address_summary`) VALUES ('1','$firstname $lastname$cr$streets$cr$city, $postcode$cr$statecomma$country','$city / $country');
INSERT INTO `address_format` (`address_format_id`, `address_format`, `address_summary`) VALUES ('2','$firstname $lastname$cr$streets$cr$city, $state    $postcode$cr$country','$city, $state / $country');
INSERT INTO `address_format` (`address_format_id`, `address_format`, `address_summary`) VALUES ('3','$firstname $lastname$cr$streets$cr$city$cr$postcode - $statecomma$country','$state / $country');
INSERT INTO `address_format` (`address_format_id`, `address_format`, `address_summary`) VALUES ('4','$firstname $lastname$cr$streets$cr$city ($postcode)$cr$country','$postcode / $country');
INSERT INTO `address_format` (`address_format_id`, `address_format`, `address_summary`) VALUES ('5','$firstname $lastname$cr$streets$cr$postcode $city$cr$country','$city / $country');
INSERT INTO `address_format` (`address_format_id`, `address_format`, `address_summary`) VALUES ('6','$firstname $lastname$cr$streets$cr$city $state $postcode$cr$country','$country / $city');
INSERT INTO `address_format` (`address_format_id`, `address_format`, `address_summary`) VALUES ('7','$firstname $lastname$cr$streets, $city$cr$postcode $state$cr$country','$country / $city');
INSERT INTO `address_format` (`address_format_id`, `address_format`, `address_summary`) VALUES ('8','$firstname $lastname$cr$streets$cr$city$cr$state$cr$postcode$cr$country','$postcode / $country');
/*!40000 ALTER TABLE `address_format` ENABLE KEYS */;

DROP TABLE IF EXISTS `admin_access`;
CREATE TABLE `admin_access` (
  `customers_id` varchar(32) COLLATE latin1_german1_ci NOT NULL DEFAULT '0',
  `configuration` int(1) NOT NULL DEFAULT '0',
  `modules` int(1) NOT NULL DEFAULT '0',
  `countries` int(1) NOT NULL DEFAULT '0',
  `currencies` int(1) NOT NULL DEFAULT '0',
  `zones` int(1) NOT NULL DEFAULT '0',
  `geo_zones` int(1) NOT NULL DEFAULT '0',
  `tax_classes` int(1) NOT NULL DEFAULT '0',
  `tax_rates` int(1) NOT NULL DEFAULT '0',
  `accounting` int(1) NOT NULL DEFAULT '0',
  `backup` int(1) NOT NULL DEFAULT '0',
  `cache` int(1) NOT NULL DEFAULT '0',
  `server_info` int(1) NOT NULL DEFAULT '0',
  `whos_online` int(1) NOT NULL DEFAULT '0',
  `languages` int(1) NOT NULL DEFAULT '0',
  `define_language` int(1) NOT NULL DEFAULT '0',
  `orders_status` int(1) NOT NULL DEFAULT '0',
  `shipping_status` int(1) NOT NULL DEFAULT '0',
  `module_export` int(1) NOT NULL DEFAULT '0',
  `customers` int(1) NOT NULL DEFAULT '0',
  `create_account` int(1) NOT NULL DEFAULT '0',
  `customers_status` int(1) NOT NULL DEFAULT '0',
  `customers_group` int(1) NOT NULL DEFAULT '0',
  `orders` int(1) NOT NULL DEFAULT '0',
  `campaigns` int(1) NOT NULL DEFAULT '0',
  `print_packingslip` int(1) NOT NULL DEFAULT '0',
  `print_order` int(1) NOT NULL DEFAULT '0',
  `popup_memo` int(1) NOT NULL DEFAULT '0',
  `coupon_admin` int(1) NOT NULL DEFAULT '0',
  `listproducts` int(1) NOT NULL DEFAULT '0',
  `listcategories` int(1) NOT NULL DEFAULT '0',
  `gv_queue` int(1) NOT NULL DEFAULT '0',
  `gv_mail` int(1) NOT NULL DEFAULT '0',
  `gv_sent` int(1) NOT NULL DEFAULT '0',
  `validproducts` int(1) NOT NULL DEFAULT '0',
  `validcategories` int(1) NOT NULL DEFAULT '0',
  `mail` int(1) NOT NULL DEFAULT '0',
  `categories` int(1) NOT NULL DEFAULT '0',
  `new_attributes` int(1) NOT NULL DEFAULT '0',
  `products_attributes` int(1) NOT NULL DEFAULT '0',
  `manufacturers` int(1) NOT NULL DEFAULT '0',
  `reviews` int(1) NOT NULL DEFAULT '0',
  `specials` int(1) NOT NULL DEFAULT '0',
  `products_expected` int(1) NOT NULL DEFAULT '0',
  `stats_products_expected` int(1) NOT NULL DEFAULT '0',
  `stats_products_viewed` int(1) NOT NULL DEFAULT '0',
  `stats_products_purchased` int(1) NOT NULL DEFAULT '0',
  `stats_customers` int(1) NOT NULL DEFAULT '0',
  `stats_sales_report` int(1) NOT NULL DEFAULT '0',
  `stats_campaigns` int(1) NOT NULL DEFAULT '0',
  `banner_manager` int(1) NOT NULL DEFAULT '0',
  `banner_statistics` int(1) NOT NULL DEFAULT '0',
  `module_newsletter` int(1) NOT NULL DEFAULT '0',
  `start` int(1) NOT NULL DEFAULT '0',
  `content_manager` int(1) NOT NULL DEFAULT '0',
  `content_preview` int(1) NOT NULL DEFAULT '0',
  `credits` int(1) NOT NULL DEFAULT '0',
  `blacklist` int(1) NOT NULL DEFAULT '0',
  `orders_edit` int(1) NOT NULL DEFAULT '0',
  `popup_image` int(1) NOT NULL DEFAULT '0',
  `csv_backend` int(1) NOT NULL DEFAULT '0',
  `products_vpe` int(1) NOT NULL DEFAULT '0',
  `cross_sell_groups` int(1) NOT NULL DEFAULT '0',
  `fck_wrapper` int(1) NOT NULL DEFAULT '0',
  `econda` int(1) NOT NULL DEFAULT '0',
  `cleverreach` int(1) NOT NULL DEFAULT '0',
  `sofortueberweisung_install` int(1) NOT NULL DEFAULT '0',
  `shop_offline` int(1) NOT NULL DEFAULT '0',
  `xajax` int(1) NOT NULL DEFAULT '0',
  `blz_update` int(1) NOT NULL DEFAULT '0',
  `removeoldpics` int(1) NOT NULL DEFAULT '0',
  `janolaw` int(1) NOT NULL DEFAULT '0',
  `haendlerbund` int(1) NOT NULL DEFAULT '0',
  `safeterms` int(1) NOT NULL DEFAULT '0',
  `easymarketing` int(1) NOT NULL DEFAULT '0',
  `it_recht_kanzlei` int(1) NOT NULL DEFAULT '0',
  `payone_config` int(1) NOT NULL DEFAULT '0',
  `payone_logs` int(1) NOT NULL DEFAULT '0',
  `backup_db` int(1) NOT NULL DEFAULT '0',
  `paypal` int(1) NOT NULL,
  `module_paypal_install` int(1) NOT NULL,
  PRIMARY KEY (`customers_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `admin_access` DISABLE KEYS */;
INSERT INTO `admin_access` (`customers_id`, `configuration`, `modules`, `countries`, `currencies`, `zones`, `geo_zones`, `tax_classes`, `tax_rates`, `accounting`, `backup`, `cache`, `server_info`, `whos_online`, `languages`, `define_language`, `orders_status`, `shipping_status`, `module_export`, `customers`, `create_account`, `customers_status`, `customers_group`, `orders`, `campaigns`, `print_packingslip`, `print_order`, `popup_memo`, `coupon_admin`, `listproducts`, `listcategories`, `gv_queue`, `gv_mail`, `gv_sent`, `validproducts`, `validcategories`, `mail`, `categories`, `new_attributes`, `products_attributes`, `manufacturers`, `reviews`, `specials`, `products_expected`, `stats_products_expected`, `stats_products_viewed`, `stats_products_purchased`, `stats_customers`, `stats_sales_report`, `stats_campaigns`, `banner_manager`, `banner_statistics`, `module_newsletter`, `start`, `content_manager`, `content_preview`, `credits`, `blacklist`, `orders_edit`, `popup_image`, `csv_backend`, `products_vpe`, `cross_sell_groups`, `fck_wrapper`, `econda`, `cleverreach`, `sofortueberweisung_install`, `shop_offline`, `xajax`, `blz_update`, `removeoldpics`, `janolaw`, `haendlerbund`, `safeterms`, `easymarketing`, `it_recht_kanzlei`, `payone_config`, `payone_logs`, `backup_db`, `paypal`, `module_paypal_install`) VALUES ('1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1');
INSERT INTO `admin_access` (`customers_id`, `configuration`, `modules`, `countries`, `currencies`, `zones`, `geo_zones`, `tax_classes`, `tax_rates`, `accounting`, `backup`, `cache`, `server_info`, `whos_online`, `languages`, `define_language`, `orders_status`, `shipping_status`, `module_export`, `customers`, `create_account`, `customers_status`, `customers_group`, `orders`, `campaigns`, `print_packingslip`, `print_order`, `popup_memo`, `coupon_admin`, `listproducts`, `listcategories`, `gv_queue`, `gv_mail`, `gv_sent`, `validproducts`, `validcategories`, `mail`, `categories`, `new_attributes`, `products_attributes`, `manufacturers`, `reviews`, `specials`, `products_expected`, `stats_products_expected`, `stats_products_viewed`, `stats_products_purchased`, `stats_customers`, `stats_sales_report`, `stats_campaigns`, `banner_manager`, `banner_statistics`, `module_newsletter`, `start`, `content_manager`, `content_preview`, `credits`, `blacklist`, `orders_edit`, `popup_image`, `csv_backend`, `products_vpe`, `cross_sell_groups`, `fck_wrapper`, `econda`, `cleverreach`, `sofortueberweisung_install`, `shop_offline`, `xajax`, `blz_update`, `removeoldpics`, `janolaw`, `haendlerbund`, `safeterms`, `easymarketing`, `it_recht_kanzlei`, `payone_config`, `payone_logs`, `backup_db`, `paypal`, `module_paypal_install`) VALUES ('groups','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','2','2','2','2','3','3','3','3','3','3','3','3','4','4','4','4','2','4','2','2','2','2','5','5','5','5','5','5','5','5','5','2','2','2','2','2','2','2','2','2','2','2','1','1','1','1','1','1','1','1','1','5','1','1','1','1','1','1','1','0','0','0');
INSERT INTO `admin_access` (`customers_id`, `configuration`, `modules`, `countries`, `currencies`, `zones`, `geo_zones`, `tax_classes`, `tax_rates`, `accounting`, `backup`, `cache`, `server_info`, `whos_online`, `languages`, `define_language`, `orders_status`, `shipping_status`, `module_export`, `customers`, `create_account`, `customers_status`, `customers_group`, `orders`, `campaigns`, `print_packingslip`, `print_order`, `popup_memo`, `coupon_admin`, `listproducts`, `listcategories`, `gv_queue`, `gv_mail`, `gv_sent`, `validproducts`, `validcategories`, `mail`, `categories`, `new_attributes`, `products_attributes`, `manufacturers`, `reviews`, `specials`, `products_expected`, `stats_products_expected`, `stats_products_viewed`, `stats_products_purchased`, `stats_customers`, `stats_sales_report`, `stats_campaigns`, `banner_manager`, `banner_statistics`, `module_newsletter`, `start`, `content_manager`, `content_preview`, `credits`, `blacklist`, `orders_edit`, `popup_image`, `csv_backend`, `products_vpe`, `cross_sell_groups`, `fck_wrapper`, `econda`, `cleverreach`, `sofortueberweisung_install`, `shop_offline`, `xajax`, `blz_update`, `removeoldpics`, `janolaw`, `haendlerbund`, `safeterms`, `easymarketing`, `it_recht_kanzlei`, `payone_config`, `payone_logs`, `backup_db`, `paypal`, `module_paypal_install`) VALUES ('3','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','0','0','0');
/*!40000 ALTER TABLE `admin_access` ENABLE KEYS */;

DROP TABLE IF EXISTS `banktransfer`;
CREATE TABLE `banktransfer` (
  `orders_id` int(11) NOT NULL DEFAULT '0',
  `banktransfer_owner` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `banktransfer_number` varchar(24) COLLATE latin1_german1_ci DEFAULT NULL,
  `banktransfer_bankname` varchar(255) COLLATE latin1_german1_ci DEFAULT NULL,
  `banktransfer_blz` varchar(8) COLLATE latin1_german1_ci DEFAULT NULL,
  `banktransfer_iban` varchar(34) COLLATE latin1_german1_ci DEFAULT NULL,
  `banktransfer_bic` varchar(11) COLLATE latin1_german1_ci DEFAULT NULL,
  `banktransfer_status` int(11) DEFAULT NULL,
  `banktransfer_prz` char(2) COLLATE latin1_german1_ci DEFAULT NULL,
  `banktransfer_fax` char(2) COLLATE latin1_german1_ci DEFAULT NULL,
  `banktransfer_owner_email` varchar(96) COLLATE latin1_german1_ci DEFAULT NULL,
  KEY `orders_id` (`orders_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `banktransfer` DISABLE KEYS */;
/*!40000 ALTER TABLE `banktransfer` ENABLE KEYS */;

DROP TABLE IF EXISTS `banktransfer_blz`;
CREATE TABLE `banktransfer_blz` (
  `blz` int(10) NOT NULL DEFAULT '0',
  `bankname` varchar(255) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `prz` char(2) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`blz`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `banktransfer_blz` DISABLE KEYS */;
/*!40000 ALTER TABLE `banktransfer_blz` ENABLE KEYS */;

DROP TABLE IF EXISTS `banners`;
CREATE TABLE `banners` (
  `banners_id` int(11) NOT NULL AUTO_INCREMENT,
  `banners_title` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `banners_url` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `banners_image` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `banners_group` varchar(10) COLLATE latin1_german1_ci NOT NULL,
  `banners_html_text` text COLLATE latin1_german1_ci,
  `expires_impressions` int(7) DEFAULT NULL,
  `expires_date` datetime DEFAULT NULL,
  `date_scheduled` datetime DEFAULT NULL,
  `date_added` datetime NOT NULL,
  `date_status_change` datetime DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`banners_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `banners` DISABLE KEYS */;
/*!40000 ALTER TABLE `banners` ENABLE KEYS */;

DROP TABLE IF EXISTS `banners_history`;
CREATE TABLE `banners_history` (
  `banners_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `banners_id` int(11) NOT NULL,
  `banners_shown` int(5) NOT NULL DEFAULT '0',
  `banners_clicked` int(5) NOT NULL DEFAULT '0',
  `banners_history_date` datetime NOT NULL,
  PRIMARY KEY (`banners_history_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `banners_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `banners_history` ENABLE KEYS */;

DROP TABLE IF EXISTS `campaigns`;
CREATE TABLE `campaigns` (
  `campaigns_id` int(11) NOT NULL AUTO_INCREMENT,
  `campaigns_name` varchar(32) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `campaigns_refID` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `campaigns_leads` int(11) NOT NULL DEFAULT '0',
  `date_added` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`campaigns_id`),
  KEY `idx_campaigns_name` (`campaigns_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `campaigns` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaigns` ENABLE KEYS */;

DROP TABLE IF EXISTS `campaigns_ip`;
CREATE TABLE `campaigns_ip` (
  `user_ip` varchar(39) COLLATE latin1_german1_ci NOT NULL,
  `time` datetime NOT NULL,
  `campaign` varchar(32) COLLATE latin1_german1_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `campaigns_ip` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaigns_ip` ENABLE KEYS */;

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `categories_id` int(11) NOT NULL AUTO_INCREMENT,
  `categories_image` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `categories_status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `categories_template` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `group_permission_0` tinyint(1) NOT NULL,
  `group_permission_1` tinyint(1) NOT NULL,
  `group_permission_2` tinyint(1) NOT NULL,
  `group_permission_3` tinyint(1) NOT NULL,
  `listing_template` varchar(64) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `sort_order` int(3) NOT NULL DEFAULT '0',
  `products_sorting` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `products_sorting2` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`categories_id`),
  KEY `idx_categories_parent_id` (`parent_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` (`categories_id`, `categories_image`, `parent_id`, `categories_status`, `categories_template`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `listing_template`, `sort_order`, `products_sorting`, `products_sorting2`, `date_added`, `last_modified`) VALUES ('6','6.jpg','0','1','categorie_listing.html','0','0','0','0','product_listing_v1.html','4','p.products_price','ASC','2014-10-30 19:54:10','2014-10-31 10:56:15');
INSERT INTO `categories` (`categories_id`, `categories_image`, `parent_id`, `categories_status`, `categories_template`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `listing_template`, `sort_order`, `products_sorting`, `products_sorting2`, `date_added`, `last_modified`) VALUES ('2','2.jpg','0','1','categorie_listing.html','0','0','0','0','product_listing_v1.html','1','p.products_sort','ASC','2014-10-21 09:55:20','2014-11-01 10:41:57');
INSERT INTO `categories` (`categories_id`, `categories_image`, `parent_id`, `categories_status`, `categories_template`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `listing_template`, `sort_order`, `products_sorting`, `products_sorting2`, `date_added`, `last_modified`) VALUES ('5','5.jpg','0','1','categorie_listing.html','0','0','0','0','product_listing_v1.html','3','p.products_price','ASC','2014-10-28 12:22:54','2014-10-30 21:58:29');
INSERT INTO `categories` (`categories_id`, `categories_image`, `parent_id`, `categories_status`, `categories_template`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `listing_template`, `sort_order`, `products_sorting`, `products_sorting2`, `date_added`, `last_modified`) VALUES ('4','4.jpg','0','1','categorie_listing.html','0','0','0','0','product_listing_v1.html','2','p.products_price','ASC','2014-10-27 12:43:19','2014-10-30 22:04:05');
INSERT INTO `categories` (`categories_id`, `categories_image`, `parent_id`, `categories_status`, `categories_template`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `listing_template`, `sort_order`, `products_sorting`, `products_sorting2`, `date_added`, `last_modified`) VALUES ('7','7.jpg','0','1','categorie_listing.html','0','0','0','0','product_listing_v1.html','5','p.products_price','ASC','2014-10-31 10:05:34','2014-10-31 10:32:47');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;

DROP TABLE IF EXISTS `categories_description`;
CREATE TABLE `categories_description` (
  `categories_id` int(11) NOT NULL DEFAULT '0',
  `language_id` tinyint(4) NOT NULL DEFAULT '1',
  `categories_name` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `categories_heading_title` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `categories_description` text COLLATE latin1_german1_ci NOT NULL,
  `categories_meta_title` varchar(100) COLLATE latin1_german1_ci NOT NULL,
  `categories_meta_description` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `categories_meta_keywords` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  PRIMARY KEY (`categories_id`,`language_id`),
  KEY `idx_categories_name` (`categories_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `categories_description` DISABLE KEYS */;
INSERT INTO `categories_description` (`categories_id`, `language_id`, `categories_name`, `categories_heading_title`, `categories_description`, `categories_meta_title`, `categories_meta_description`, `categories_meta_keywords`) VALUES ('2','2','Fensterdichtungen Spez. Kunststofffenster','Spezial Dichtungen für Kunststofffenster mit Anschlagdichtung','<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><strong>Eine besondere L&ouml;sung <br />\r\n</strong><br />\r\nbeim Nachtr&auml;glichen Einbau von Fensterdichtungen f&uuml;r Kunststofffenster, bieten Ihnen<br />\r\nunsere neuen Fensterdichtungen aus Silikon. Auf Grund der speziellen Form und des<br />\r\nweichen Materials,l&auml;sst diese sich als Fl&uuml;gel und Rahmendichtung verwenden. <br />\r\nAuch wenn unsere Dichtungsform mit Ihrer Dichtung nicht identisch ist,die Silikon -<br />\r\ndichtungen sind vielfach verwendbar.<br />\r\nUnsere eigene Fensterdichtung eignet sich hervorragend f&uuml;r verschiedene Fenstersysteme<br />\r\naus Kunststoff mit Anschlagdichtung, insbesondere dort, wo der Hersteller oder das <br />\r\nSystem nicht bekannt sind.<br />\r\n<br />\r\nBis zu 4 mm mehr Verstellbereich als bei &quot;handels&uuml;blichen&quot; Dichtungen ist ein ganz<br />\r\nwichtiger Vorteil unserer Spezial - Dichtungen. Unsere Fensterdichtungen aus Silikon<br />\r\nsind wartungsfrei, UV - best&auml;ndig und zeichnen sich durch eine sehr hohe Lebensdauer <br />\r\naus. Diese spezielle Dichtung wurde eigens zum Nachr&uuml;sten der Fensterdichtungen bei<br />\r\n&auml;lteren Kunststofffenstern entwickelt.<br />\r\n<br />\r\nOftmals l&auml;sst sich das Fenster an der Beschlagtechnik nicht mehr ausreichend nachstellen<br />\r\num das Fenster wieder dicht zu bekommen. H&auml;ufig kommt es auch vor, dass die Original<br />\r\nDichtungen nicht mehr gen&uuml;gend abdichten k&ouml;nnen, da sich die Fensterbeschl&auml;ge nach<br />\r\nJahren abgenutzt haben. <br />\r\n<br />\r\nWenn die Original Dichtung nur f&uuml;r 5 mm Anschlagluft ausgelegt ist, dann kann diese<br />\r\nFensterdichtung auch nur 5 mm abdichten. Werden jedoch 6 mm ben&ouml;tigt, ist es ein Problem<br />\r\ndieses Fenster wieder dicht zu bekommen. Es geht also oft nur um wenige Millimeter um<br />\r\nihre Fenster wieder abdichten zu k&ouml;nnen!<br />\r\n<br />\r\nUnsere &quot;sechs&quot; Spezialdichtungen ( der Serie G, K und M ) zum Nachr&uuml;sten f&uuml;r eine <br />\r\nVielzahl von Systemen von Kunststofffenstern,k&ouml;nnen Sie hier im Shop bestellen oder<br />\r\nvorab auch kostenlos ein Muster anfordern!</span></span></p>','Fensterdichtungen,Fensterdichtung kunststofffenste','Fensterdichtungen,Fensterdichtung Kunststofffenster, Dichtung Fenster,Fensterdichtung kaufen, Fensterdichtungen austauschen','Fensterdichtungen kaufen,Fensterdichtung erneuern,Fensterdichtung Silikon,Fensterdichtung austauschen,Fensterdichtungen,Fensterdichtung');
INSERT INTO `categories_description` (`categories_id`, `language_id`, `categories_name`, `categories_heading_title`, `categories_description`, `categories_meta_title`, `categories_meta_description`, `categories_meta_keywords`) VALUES ('4','2','Fensterdichtungen Kunststofffenster TPE','','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Hier finden sie Fensterdichtungen f&uuml;r<br />\r\nKunststofffenster mit Anschlagsdichtung<br />\r\n( Rahmen und Fl&uuml;geldichtungen ).<br />\r\n<br />\r\nEs handelt sich um verschiedene Dichtungen<br />\r\nf&uuml;hrender Hersteller von Fenstersystemen<br />\r\nab dem Herstellungsjahr 1975.<br />\r\n<br />\r\nDer Werkstoff dieser Fensterdichtungen ist<br />\r\nmodifiziert und zeichnet sich durch eine<br />\r\nHohe Lebendauer aus.<br />\r\n<br />\r\nMehr Information entnehmen sie bitte der Produktbeschreibung.<br />\r\n&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<br />\r\n</span></span></p>','Fensterdichtungen,Fensterdichtung Kunststoffenster','Fensterdichtungen,Fensterdichtung Kunststofffenster, Dichtung Fenster,Fensterdichtung kaufen, Fensterdichtungen austauschen','Fensterdichtungen kaufen,Fensterdichtung erneuern,Fensterdichtung Silikon,Fensterdichtung austauschen,Fensterdichtungen,Fensterdichtung');
INSERT INTO `categories_description` (`categories_id`, `language_id`, `categories_name`, `categories_heading_title`, `categories_description`, `categories_meta_title`, `categories_meta_description`, `categories_meta_keywords`) VALUES ('5','2','Fensterdichtungen Holzfenster TPE','','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><strong>Fensterdichtungen f&uuml;r Holzfenster<br />\r\n</strong><br />\r\nMaterial Thermoplastisches Elastomere (TPE )<br />\r\n<br />\r\n<br />\r\n<strong>Typische Einsatzgebiete dieses Werkstoffes:</strong><br />\r\n<br />\r\nFenster, Haust&uuml;ren, Innent&uuml;ren, Stahlzargen, Br&uuml;stungen <br />\r\n<br />\r\nHolz, Holz - Alu. Kunststoff, Aluminium innen und au&szlig;en<br />\r\n<br />\r\n<br />\r\n</span></span></p>','Fensterdichtungen, Fensterdichtungen Holzfenster','','Fensterdichtungen Holzfenster,Fensterdichtung Holzfenster, Fensterdichtung Hozfenster austauschen. Fensterdichtungen Holzfenster kaufen. Fensterdichtungen Holzfenster nachrüsten');
INSERT INTO `categories_description` (`categories_id`, `language_id`, `categories_name`, `categories_heading_title`, `categories_description`, `categories_meta_title`, `categories_meta_description`, `categories_meta_keywords`) VALUES ('6','2','Fensterdichtung Holzfenster super weich','','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Fl&uuml;gelfalz - und &Uuml;berschlagdichtungen f&uuml;r Holzfenster: <strong>super weich</strong><br />\r\n<br />\r\nWerkstoff: Dichtungskopf aus Spezialwerkstoff</span></span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"> f&uuml;r hohen </span></span><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Toleranzausgleich, </span></span><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">mit glatter, leicht</span></span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"> zu reinigender </span></span><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Spezialbeschichtung.</span></span></p>','Finsterdichtung Holzfenster, Dichtung holzfenster','Fensterdichtungen Holzfenster, Fensterdichtung Holzfenster, Dichtung Holzfenster, Diichtungen Holholzfenster kaufen, Dichtungen Holzfenster','Fensterdichtungen Holzfenster,Fensterdichtung Holzfenster, Fensterdichtung Holzfenster austauschen. Fensterdichtungen Holzfenster kaufen. Fensterdichtungen Holzfenster nachrüsten');
INSERT INTO `categories_description` (`categories_id`, `language_id`, `categories_name`, `categories_heading_title`, `categories_description`, `categories_meta_title`, `categories_meta_description`, `categories_meta_keywords`) VALUES ('7','2','Dichtungskleber','','','Kleber für Femnsterdichtungen','Kleber Fensterdichtung Kunststofffenster, Kleber Fensterdichtung Holzfenster','Kleber Fensterdichtungen, Kleber Fensterdichtung');
/*!40000 ALTER TABLE `categories_description` ENABLE KEYS */;

DROP TABLE IF EXISTS `cm_file_flags`;
CREATE TABLE `cm_file_flags` (
  `file_flag` int(11) NOT NULL,
  `file_flag_name` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  PRIMARY KEY (`file_flag`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `cm_file_flags` DISABLE KEYS */;
INSERT INTO `cm_file_flags` (`file_flag`, `file_flag_name`) VALUES ('0','information');
INSERT INTO `cm_file_flags` (`file_flag`, `file_flag_name`) VALUES ('1','content');
/*!40000 ALTER TABLE `cm_file_flags` ENABLE KEYS */;

DROP TABLE IF EXISTS `configuration`;
CREATE TABLE `configuration` (
  `configuration_id` int(11) NOT NULL AUTO_INCREMENT,
  `configuration_key` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `configuration_value` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `configuration_group_id` int(11) NOT NULL,
  `sort_order` int(5) DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `date_added` datetime NOT NULL,
  `use_function` varchar(255) COLLATE latin1_german1_ci DEFAULT NULL,
  `set_function` varchar(255) COLLATE latin1_german1_ci DEFAULT NULL,
  PRIMARY KEY (`configuration_id`),
  KEY `idx_configuration_group_id` (`configuration_group_id`)
) ENGINE=MyISAM AUTO_INCREMENT=605 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `configuration` DISABLE KEYS */;
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('1','STORE_NAME','Spezial - Fensterdichtungen für alle Fenstertarten','1','1','2014-11-01 12:46:57','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('2','STORE_OWNER','Fensterdichtungen.org - Stareno GmbH','1','2','2014-11-01 12:46:57','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('3','STORE_OWNER_EMAIL_ADDRESS','andre.muenstermann@gmail.com','1','3',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('4','EMAIL_FROM','info@fensterdichtungen.org','1','4',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('5','STORE_COUNTRY','81','1','6',NULL,'2014-10-16 20:37:49','xtc_get_country_name','xtc_cfg_pull_down_country_list(');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('6','STORE_ZONE','88','1','7','2014-10-18 10:45:20','2014-10-16 20:37:49','xtc_cfg_get_zone_name','xtc_cfg_pull_down_zone_list(');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('7','EXPECTED_PRODUCTS_SORT','asc','1','8','2014-10-18 10:45:20','2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'asc\', \'desc\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('8','EXPECTED_PRODUCTS_FIELD','products_name','1','9','2014-10-18 10:45:20','2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'products_name\', \'date_expected\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('9','USE_DEFAULT_LANGUAGE_CURRENCY','true','1','10','2014-10-18 10:45:20','2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('10','DISPLAY_CART','true','1','13',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('11','STORE_NAME_ADDRESS','Fensterdichtungen.org - Stareno GmbH\r\nHohldrift 17\r\nD - 33181 Bad Wünnenberg\r\nTel. 02957 - 9849318','1','16','2014-11-01 12:46:57','2014-10-16 20:37:49',NULL,'xtc_cfg_textarea(');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('12','SHOW_COUNTS','true','1','17','2014-10-18 10:45:20','2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('13','DEFAULT_CUSTOMERS_STATUS_ID_ADMIN','0','1','20',NULL,'2014-10-16 20:37:49','xtc_get_customers_status_name','xtc_cfg_pull_down_customers_status_list(');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('14','DEFAULT_CUSTOMERS_STATUS_ID_GUEST','1','1','21',NULL,'2014-10-16 20:37:49','xtc_get_customers_status_name','xtc_cfg_pull_down_customers_status_list(');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('15','DEFAULT_CUSTOMERS_STATUS_ID','2','1','23',NULL,'2014-10-16 20:37:49','xtc_get_customers_status_name','xtc_cfg_pull_down_customers_status_list(');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('16','ALLOW_ADD_TO_CART','true','1','24','2014-10-18 10:45:20','2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('17','CURRENT_TEMPLATE','bootstrap','1','26','2014-10-16 20:42:40','2014-10-16 20:37:49',NULL,'xtc_cfg_pull_down_template_sets(');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('18','PRICE_PRECISION','4','1','28',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('19','CC_KEYCHAIN','changeme','1','29',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('20','CHECKOUT_USE_PRODUCTS_SHORT_DESCRIPTION','true','1','40','2014-10-18 10:45:20','2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('21','CHECKOUT_SHOW_PRODUCTS_IMAGES','true','1','41',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('22','ENTRY_FIRST_NAME_MIN_LENGTH','2','2','1',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('23','ENTRY_LAST_NAME_MIN_LENGTH','2','2','2',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('24','ENTRY_DOB_MIN_LENGTH','10','2','3',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('25','ENTRY_EMAIL_ADDRESS_MIN_LENGTH','6','2','4',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('26','ENTRY_STREET_ADDRESS_MIN_LENGTH','5','2','5',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('27','ENTRY_COMPANY_MIN_LENGTH','2','2','6',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('28','ENTRY_POSTCODE_MIN_LENGTH','4','2','7',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('29','ENTRY_CITY_MIN_LENGTH','3','2','8',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('30','ENTRY_STATE_MIN_LENGTH','0','2','9',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('31','ENTRY_TELEPHONE_MIN_LENGTH','3','2','10',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('32','ENTRY_PASSWORD_MIN_LENGTH','5','2','11',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('33','CC_OWNER_MIN_LENGTH','3','2','12',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('34','CC_NUMBER_MIN_LENGTH','10','2','13',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('35','REVIEW_TEXT_MIN_LENGTH','500','2','14','2014-10-18 10:49:32','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('36','MIN_DISPLAY_BESTSELLERS','1','2','15',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('37','MIN_DISPLAY_ALSO_PURCHASED','1','2','16',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('38','MAX_ADDRESS_BOOK_ENTRIES','5','3','1',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('39','MAX_DISPLAY_SEARCH_RESULTS','20','3','2',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('40','MAX_DISPLAY_PAGE_LINKS','5','3','3',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('41','MAX_DISPLAY_SPECIAL_PRODUCTS','9','3','4',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('42','MAX_DISPLAY_NEW_PRODUCTS','9','3','5',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('43','MAX_DISPLAY_UPCOMING_PRODUCTS','10','3','6',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('44','MAX_DISPLAY_MANUFACTURERS_IN_A_LIST','0','3','7',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('45','MAX_MANUFACTURERS_LIST','1','3','7',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('46','MAX_DISPLAY_MANUFACTURER_NAME_LEN','15','3','8',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('47','MAX_DISPLAY_NEW_REVIEWS','6','3','9',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('48','MAX_RANDOM_SELECT_REVIEWS','10','3','10',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('49','MAX_RANDOM_SELECT_NEW','10','3','11',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('50','MAX_RANDOM_SELECT_SPECIALS','10','3','12',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('51','MAX_DISPLAY_CATEGORIES_PER_ROW','3','3','13',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('52','MAX_DISPLAY_PRODUCTS_NEW','10','3','14',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('53','MAX_DISPLAY_BESTSELLERS','10','3','15',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('54','MAX_DISPLAY_ALSO_PURCHASED','6','3','16',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('55','MAX_DISPLAY_PRODUCTS_IN_ORDER_HISTORY_BOX','6','3','17',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('56','MAX_DISPLAY_ORDER_HISTORY','10','3','18',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('57','PRODUCT_REVIEWS_VIEW','5','3','19',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('58','MAX_PRODUCTS_QTY','1000','3','21',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('59','MAX_DISPLAY_NEW_PRODUCTS_DAYS','30','3','22',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('60','CONFIG_CALCULATE_IMAGE_SIZE','true','4','1',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('61','IMAGE_QUALITY','100','4','2',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('62','PRODUCT_IMAGE_THUMBNAIL_WIDTH','160','4','7','2014-10-18 11:19:18','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('63','PRODUCT_IMAGE_THUMBNAIL_HEIGHT','120','4','8','2014-10-18 11:19:18','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('64','PRODUCT_IMAGE_INFO_WIDTH','200','4','9',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('65','PRODUCT_IMAGE_INFO_HEIGHT','160','4','10',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('66','PRODUCT_IMAGE_POPUP_WIDTH','800','4','11',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('67','PRODUCT_IMAGE_POPUP_HEIGHT','640','4','12',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('68','PRODUCT_IMAGE_THUMBNAIL_BEVEL','','4','13',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('69','PRODUCT_IMAGE_THUMBNAIL_GREYSCALE','','4','14',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('70','PRODUCT_IMAGE_THUMBNAIL_ELLIPSE','','4','15',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('71','PRODUCT_IMAGE_THUMBNAIL_ROUND_EDGES','','4','16',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('72','PRODUCT_IMAGE_THUMBNAIL_MERGE','','4','17',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('73','PRODUCT_IMAGE_THUMBNAIL_FRAME','','4','18',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('74','PRODUCT_IMAGE_THUMBNAIL_DROP_SHADOW','','4','19',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('75','PRODUCT_IMAGE_THUMBNAIL_MOTION_BLUR','','4','20',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('76','PRODUCT_IMAGE_INFO_BEVEL','','4','21',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('77','PRODUCT_IMAGE_INFO_GREYSCALE','','4','22',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('78','PRODUCT_IMAGE_INFO_ELLIPSE','','4','23',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('79','PRODUCT_IMAGE_INFO_ROUND_EDGES','','4','24',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('80','PRODUCT_IMAGE_INFO_MERGE','','4','25',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('81','PRODUCT_IMAGE_INFO_FRAME','','4','26',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('82','PRODUCT_IMAGE_INFO_DROP_SHADOW','','4','27',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('83','PRODUCT_IMAGE_INFO_MOTION_BLUR','','4','28',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('84','PRODUCT_IMAGE_POPUP_BEVEL','','4','29',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('85','PRODUCT_IMAGE_POPUP_GREYSCALE','','4','30',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('86','PRODUCT_IMAGE_POPUP_ELLIPSE','','4','31',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('87','PRODUCT_IMAGE_POPUP_ROUND_EDGES','','4','32',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('88','PRODUCT_IMAGE_POPUP_MERGE','','4','33',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('89','PRODUCT_IMAGE_POPUP_FRAME','','4','34',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('90','PRODUCT_IMAGE_POPUP_DROP_SHADOW','','4','35',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('91','PRODUCT_IMAGE_POPUP_MOTION_BLUR','','4','36',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('92','MO_PICS','1','4','3','2014-10-18 11:19:18','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('93','IMAGE_MANIPULATOR','image_manipulator_GD2.php','4','3',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'image_manipulator_GD2.php\', \'image_manipulator_GD2_advanced.php\', \'image_manipulator_GD1.php\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('94','PRODUCT_IMAGE_NO_ENLARGE_UNDER_DEFAULT','false','4','6',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('95','ACCOUNT_GENDER','true','5','10',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('96','ACCOUNT_DOB','true','5','20',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('97','ACCOUNT_COMPANY','true','5','30',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('98','ACCOUNT_SUBURB','true','5','50',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('99','ACCOUNT_STATE','false','5','60',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('100','ACCOUNT_OPTIONS','account','5','100',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'account\', \'guest\', \'both\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('101','DELETE_GUEST_ACCOUNT','true','5','110',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('102','MODULE_PAYMENT_INSTALLED','paypal.php;paypal_ipn.php;pn_sofortueberweisung.php;eustandardtransfer.php','6','0','2014-11-01 18:18:11','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('103','MODULE_ORDER_TOTAL_INSTALLED','ot_subtotal.php;ot_subtotal_no_tax.php;ot_tax.php;ot_shipping.php;ot_total.php;ot_discount.php','6','0','2014-10-18 13:02:45','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('104','MODULE_SHIPPING_INSTALLED','table.php;ap.php','6','0','2014-10-18 13:45:55','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('105','DEFAULT_CURRENCY','EUR','6','0',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('106','DEFAULT_LANGUAGE','de','6','0',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('107','DEFAULT_ORDERS_STATUS_ID','1','6','0',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('108','DEFAULT_PRODUCTS_VPE_ID','','6','0',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('109','DEFAULT_SHIPPING_STATUS_ID','1','6','0',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('462','MODULE_ORDER_TOTAL_SHIPPING_DESTINATION','both','6','5',NULL,'2014-10-18 13:02:08',NULL,'xtc_cfg_select_option(array(\'national\', \'international\', \'both\'), ');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('461','MODULE_ORDER_TOTAL_SHIPPING_FREE_SHIPPING_OVER_INTERNATIONAL','140','6','4',NULL,'2014-10-18 13:02:08','currencies->format',NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('460','MODULE_ORDER_TOTAL_SHIPPING_FREE_SHIPPING_OVER','140','6','4',NULL,'2014-10-18 13:02:08','currencies->format',NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('459','MODULE_ORDER_TOTAL_SHIPPING_FREE_SHIPPING','false','6','3',NULL,'2014-10-18 13:02:08',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('458','MODULE_ORDER_TOTAL_SHIPPING_SORT_ORDER','60','6','2',NULL,'2014-10-18 13:02:08',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('457','MODULE_ORDER_TOTAL_SHIPPING_STATUS','true','6','1',NULL,'2014-10-18 13:02:08',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'), ');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('117','MODULE_ORDER_TOTAL_SUBTOTAL_STATUS','true','6','1',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('118','MODULE_ORDER_TOTAL_SUBTOTAL_SORT_ORDER','20','6','2',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('119','MODULE_ORDER_TOTAL_TAX_STATUS','true','6','1',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('120','MODULE_ORDER_TOTAL_TAX_SORT_ORDER','50','6','2',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('121','MODULE_ORDER_TOTAL_TOTAL_STATUS','true','6','1',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('122','MODULE_ORDER_TOTAL_TOTAL_SORT_ORDER','99','6','2',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('123','MODULE_ORDER_TOTAL_DISCOUNT_STATUS','false','6','1',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('124','MODULE_ORDER_TOTAL_DISCOUNT_SORT_ORDER','20','6','2',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('125','MODULE_ORDER_TOTAL_SUBTOTAL_NO_TAX_STATUS','true','6','1',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('126','MODULE_ORDER_TOTAL_SUBTOTAL_NO_TAX_SORT_ORDER','40','6','2',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('127','SHIPPING_ORIGIN_COUNTRY','81','7','1',NULL,'2014-10-16 20:37:49','xtc_get_country_name','xtc_cfg_pull_down_country_list(');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('128','SHIPPING_ORIGIN_ZIP','33181','7','2',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('129','SHIPPING_MAX_WEIGHT','30','7','3','2014-10-18 11:22:49','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('130','SHIPPING_BOX_WEIGHT','1','7','4','2014-10-18 11:22:49','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('131','SHIPPING_BOX_PADDING','10','7','5',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('132','SHOW_SHIPPING','true','7','6',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('133','SHIPPING_INFOS','1','7','5',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('134','PRODUCT_LIST_FILTER','true','8','1',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('135','SHOW_BUTTON_BUY_NOW','false','8','20','0000-00-00 00:00:00','2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('136','STOCK_CHECK','true','9','1',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('137','ATTRIBUTE_STOCK_CHECK','true','9','2',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('138','STOCK_LIMITED','true','9','3',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('139','STOCK_ALLOW_CHECKOUT','true','9','4',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('140','STOCK_MARK_PRODUCT_OUT_OF_STOCK','<span style=\\\"color:red\\\">***</span>','9','5','2014-10-18 11:23:43','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('141','STOCK_REORDER_LEVEL','5','9','6',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('142','STOCK_CHECKOUT_UPDATE_PRODUCTS_STATUS','true','9','20',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('143','STORE_PAGE_PARSE_TIME','false','10','1',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('144','STORE_PAGE_PARSE_TIME_LOG','page_parse_time.log','10','2',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('145','STORE_PARSE_DATE_TIME_FORMAT','%d/%m/%Y %H:%M:%S','10','3',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('146','DISPLAY_PAGE_PARSE_TIME','true','10','4',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('147','STORE_DB_TRANSACTIONS','false','10','5',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('148','USE_CACHE','false','11','1',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('149','DIR_FS_CACHE','cache','11','2',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('150','CACHE_LIFETIME','3600','11','3',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('151','CACHE_CHECK','true','11','4',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('152','DB_CACHE','false','11','5',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('153','DB_CACHE_EXPIRE','3600','11','6',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('154','EMAIL_TRANSPORT','mail','12','1',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'sendmail\', \'smtp\', \'mail\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('155','SENDMAIL_PATH','/usr/sbin/sendmail','12','2',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('156','SMTP_MAIN_SERVER','localhost','12','3',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('157','SMTP_BACKUP_SERVER','localhost','12','4',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('158','SMTP_PORT','25','12','5',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('159','SMTP_USERNAME','Please Enter','12','6',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('160','SMTP_PASSWORD','Please Enter','12','7',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('161','SMTP_AUTH','false','12','8',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('162','EMAIL_LINEFEED','LF','12','9',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'LF\', \'CRLF\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('163','EMAIL_USE_HTML','true','12','10',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('164','ENTRY_EMAIL_ADDRESS_CHECK','false','12','11',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('165','SEND_EMAILS','true','12','12',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('166','USE_CONTACT_EMAIL_ADDRESS','false','12','13',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('167','EMAIL_SQL_ERRORS','false','12','14',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('168','CONTACT_US_EMAIL_ADDRESS','info@fensterdichtungen.org','12','20',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('169','CONTACT_US_NAME','Fensterdichtungen.org -  Stareno GmbH','12','21','2014-11-01 13:08:17','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('170','CONTACT_US_REPLY_ADDRESS','info@fensterdichtungen.org','12','22','2014-10-18 11:42:47','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('171','CONTACT_US_REPLY_ADDRESS_NAME','Fensterdichtungen.org -  Stareno GmbH','12','23','2014-11-01 13:08:17','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('172','CONTACT_US_EMAIL_SUBJECT','Anfrage über Kontakt-Formular','12','24','2014-10-18 11:42:47','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('173','CONTACT_US_FORWARDING_STRING','hzich@t-online.de','12','25','2014-10-18 11:42:47','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('174','EMAIL_SUPPORT_ADDRESS','info@fensterdichtungen.org','12','26',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('175','EMAIL_SUPPORT_NAME','Mail send by support systems','12','27',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('176','EMAIL_SUPPORT_REPLY_ADDRESS','Online-Shop Hardy Zich','12','28','2014-10-18 11:42:47','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('177','EMAIL_SUPPORT_REPLY_ADDRESS_NAME','info@fensterdichtungen.org','12','29','2014-10-18 11:42:47','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('178','EMAIL_SUPPORT_SUBJECT','Online-Shop Stareno GmbH','12','30','2014-10-18 11:42:47','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('179','EMAIL_SUPPORT_FORWARDING_STRING','hzich@t-online.de','12','31','2014-10-18 11:42:47','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('180','EMAIL_BILLING_ADDRESS','info@fensterdichtungen.org','12','32',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('181','EMAIL_BILLING_NAME','Fensterdichtungen.org -  Stareno GmbH','12','33','2014-11-01 13:08:17','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('182','EMAIL_BILLING_REPLY_ADDRESS','info@fensterdichtungen.org','12','34','2014-10-18 11:42:47','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('183','EMAIL_BILLING_REPLY_ADDRESS_NAME','Fensterdichtungen.org - Staren GmbH','12','35','2014-11-01 13:08:17','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('184','EMAIL_BILLING_SUBJECT','Ihre Bestellung bei uns','12','36',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('185','EMAIL_BILLING_FORWARDING_STRING','info@fensterdichtungen.org','12','37',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('186','EMAIL_BILLING_SUBJECT_ORDER','Ihre Bestellung {$nr} vom {$date}','12','38',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('187','EMAIL_BILLING_ATTACHMENTS','','12','39',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('188','SHOW_IMAGES_IN_EMAIL','false','12','50',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('189','SHOW_IMAGES_IN_EMAIL_DIR','thumbnail','12','51',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'thumbnail\', \'info\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('190','SHOW_IMAGES_IN_EMAIL_STYLE','max-width:90px;max-height:120px;','12','52',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('191','DOWNLOAD_ENABLED','false','13','1',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('192','DOWNLOAD_BY_REDIRECT','false','13','2',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('193','DOWNLOAD_UNALLOWED_PAYMENT','banktransfer,cod,invoice,moneyorder','13','5',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('194','DOWNLOAD_MIN_ORDERS_STATUS','1','13','5',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('195','GZIP_COMPRESSION','false','14','1',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('196','GZIP_LEVEL','5','14','2',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('197','SESSION_WRITE_DIRECTORY','/tmp','15','1',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('198','SESSION_FORCE_COOKIE_USE','False','15','2',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'True\', \'False\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('199','SESSION_CHECK_SSL_SESSION_ID','False','15','3',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'True\', \'False\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('200','SESSION_CHECK_USER_AGENT','False','15','4',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'True\', \'False\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('201','SESSION_CHECK_IP_ADDRESS','False','15','5',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'True\', \'False\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('202','SESSION_RECREATE','False','15','7',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'True\', \'False\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('203','SESSION_LIFE_CUSTOMERS','1440','15','20',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('204','SESSION_LIFE_ADMIN','7200','15','21',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('205','META_MIN_KEYWORD_LENGTH','6','16','2',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('206','META_KEYWORDS_NUMBER','5','16','3',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('207','META_AUTHOR','Hardy Zich','16','4','2014-10-18 11:00:31','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('208','META_PUBLISHER','fensterdichtungen.org','16','5','2014-10-18 11:00:31','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('209','META_COMPANY','fensterdichtungen.org','16','6','2014-10-18 11:00:31','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('210','META_TOPIC','shopping','16','7',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('211','META_REPLY_TO','info@fensterdichtungen.org','16','8','2014-10-18 11:00:31','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('212','META_REVISIT_AFTER','5','16','9',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('213','META_ROBOTS','index,follow','16','10',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('214','META_DESCRIPTION','Fensterdichtungen- Fensterdichtung-Kunststofffenster-Fenster abdichten - Fenster undicht - Fensterdichtung erneuern-Fensterdichtungen Holzfenster-Dichtung Holzfenster- Türdichtung','16','11','2014-10-18 11:00:31','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('215','META_KEYWORDS','Fensterdichtungen- Fensterdichtung-Kunststofffenster-Fenster abdichten - Fenster undicht - Fensterdichtung erneuern-Fensterdichtungen Holzfenster-Dichtung Holzfenster- Türdichtung','16','12','2014-10-18 11:00:31','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('216','SEARCH_ENGINE_FRIENDLY_URLS','false','16','13','2014-10-17 10:54:04','2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('217','CHECK_CLIENT_AGENT','true','16','14',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('218','USE_WYSIWYG','true','17','1',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('219','ACTIVATE_GIFT_SYSTEM','false','17','2',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('220','SECURITY_CODE_LENGTH','10','17','3',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('221','NEW_SIGNUP_GIFT_VOUCHER_AMOUNT','0','17','4',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('222','NEW_SIGNUP_DISCOUNT_COUPON','','17','5',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('223','ACTIVATE_SHIPPING_STATUS','true','17','6',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('224','DISPLAY_CONDITIONS_ON_CHECKOUT','true','17','7',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('225','SHOW_IP_LOG','false','17','8',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('226','GROUP_CHECK','false','17','9',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('227','ACTIVATE_NAVIGATOR','false','17','10',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('228','QUICKLINK_ACTIVATED','true','17','11',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('229','ACTIVATE_REVERSE_CROSS_SELLING','true','17','12',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('230','DISPLAY_REVOCATION_ON_CHECKOUT','true','17','13',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('231','REVOCATION_ID','9','17','14',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('232','GOOGLE_RSS_FEED_REFID','','17','15',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('233','SHIPPING_STATUS_INFOS','11','17','14',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('234','ACCOUNT_COMPANY_VAT_CHECK','true','18','4',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('235','STORE_OWNER_VAT_ID','DE 183 387 281','18','3','2014-10-18 11:02:31','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('236','DEFAULT_CUSTOMERS_VAT_STATUS_ID','1','18','23',NULL,'2014-10-16 20:37:49','xtc_get_customers_status_name','xtc_cfg_pull_down_customers_status_list(');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('237','ACCOUNT_COMPANY_VAT_LIVE_CHECK','true','18','4',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('238','ACCOUNT_COMPANY_VAT_GROUP','true','18','4',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('239','ACCOUNT_VAT_BLOCK_ERROR','true','18','4',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('240','DEFAULT_CUSTOMERS_VAT_STATUS_ID_LOCAL','3','18','24','0000-00-00 00:00:00','2014-10-16 20:37:49','xtc_get_customers_status_name','xtc_cfg_pull_down_customers_status_list(');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('241','GOOGLE_CONVERSION_ID','','19','2',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('242','GOOGLE_LANG','de','19','3',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('243','GOOGLE_CONVERSION','false','19','0',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('244','CSV_TEXTSIGN','\"','20','1',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('245','CSV_SEPERATOR',';','20','2',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('246','COMPRESS_EXPORT','false','20','3',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('247','AFTERBUY_PARTNERID','','21','2',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('248','AFTERBUY_PARTNERPASS','','21','3',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('249','AFTERBUY_USERID','','21','4',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('250','AFTERBUY_ORDERSTATUS','1','21','5',NULL,'2014-10-16 20:37:49','xtc_get_order_status_name','xtc_cfg_pull_down_order_statuses(');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('251','AFTERBUY_ACTIVATED','false','21','6',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('252','SEARCH_IN_DESC','true','22','2',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('253','SEARCH_IN_ATTR','true','22','3',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('254','ADVANCED_SEARCH_DEFAULT_OPERATOR','and','22','4',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'and\', \'or\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('255','TRACKING_ECONDA_ACTIVE','false','23','1',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('256','TRACKING_ECONDA_ID','','23','2',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('257','TRACKING_COUNT_ADMIN_ACTIVE','false','24','1',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('258','TRACKING_GOOGLEANALYTICS_ACTIVE','false','24','2',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('259','TRACKING_GOOGLEANALYTICS_ID','UA-XXXXXXX-X','24','3',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('260','TRACKING_PIWIK_ACTIVE','false','24','4',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('261','TRACKING_PIWIK_LOCAL_PATH','www.domain.de/piwik','24','5',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('262','TRACKING_PIWIK_ID','1','24','6',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('263','TRACKING_PIWIK_GOAL','1','24','7',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('264','_PAYMENT_MONEYBOOKERS_EMAILID','','31','1',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('265','_PAYMENT_MONEYBOOKERS_PWD','','31','2',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('266','_PAYMENT_MONEYBOOKERS_MERCHANTID','','31','3',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('267','_PAYMENT_MONEYBOOKERS_TMP_STATUS_ID','0','31','4',NULL,'2014-10-16 20:37:49','xtc_get_order_status_name','xtc_cfg_pull_down_order_statuses(');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('268','_PAYMENT_MONEYBOOKERS_PROCESSED_STATUS_ID','0','31','5',NULL,'2014-10-16 20:37:49','xtc_get_order_status_name','xtc_cfg_pull_down_order_statuses(');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('269','_PAYMENT_MONEYBOOKERS_PENDING_STATUS_ID','0','31','6',NULL,'2014-10-16 20:37:49','xtc_get_order_status_name','xtc_cfg_pull_down_order_statuses(');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('270','_PAYMENT_MONEYBOOKERS_CANCELED_STATUS_ID','0','31','7',NULL,'2014-10-16 20:37:49','xtc_get_order_status_name','xtc_cfg_pull_down_order_statuses(');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('271','POPUP_SHIPPING_LINK_PARAMETERS','','40','10','2014-10-28 20:16:22','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('272','POPUP_SHIPPING_LINK_CLASS','contentbox','40','11','2014-10-28 20:16:22','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('273','POPUP_CONTENT_LINK_PARAMETERS','','40','20','2014-10-28 20:16:22','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('274','POPUP_CONTENT_LINK_CLASS','contentbox','40','21','2014-10-28 20:16:22','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('275','POPUP_PRODUCT_LINK_PARAMETERS','','40','30','2014-10-28 20:16:22','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('276','POPUP_PRODUCT_LINK_CLASS','contentbox','40','31','2014-10-28 20:16:22','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('277','POPUP_COUPON_HELP_LINK_PARAMETERS','','40','40','2014-10-28 20:16:22','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('278','POPUP_COUPON_HELP_LINK_CLASS','contentbox','40','41','2014-10-28 20:16:22','2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('279','POPUP_PRODUCT_PRINT_SIZE','width=640, height=600','40','60',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('280','POPUP_PRINT_ORDER_SIZE','width=640, height=600','40','70',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('281','PRICE_IS_BRUTTO','true','1000','10','2014-10-18 11:09:49','2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('282','USE_ADMIN_TOP_MENU','true','1000','20',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('283','USE_ADMIN_LANG_TABS','true','1000','21',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('284','MAX_DISPLAY_ORDER_RESULTS','30','1000','30',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('285','USE_ADMIN_THUMBS_IN_LIST','true','1000','32',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('286','USE_ADMIN_THUMBS_IN_LIST_STYLE','max-width:40px;max-height:40px;','1000','33',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('287','MAX_DISPLAY_LIST_PRODUCTS','50','1000','51',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('288','MAX_DISPLAY_LIST_CUSTOMERS','100','1000','52',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('289','MAX_ROW_LISTS_ATTR_OPTIONS','10','1000','53',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('290','MAX_ROW_LISTS_ATTR_VALUES','50','1000','54',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('291','WHOS_ONLINE_TIME_LAST_CLICK','900','1000','60',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('292','WHOS_ONLINE_IP_WHOIS_SERVICE','http://www.utrace.de/?query=','1000','62',NULL,'2014-10-16 20:37:49',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('293','CONFIRM_SAVE_ENTRY','true','1000','70',NULL,'2014-10-16 20:37:49',NULL,'xtc_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('294','MODULE_EXPORT_INSTALLED','','6','0',NULL,'2014-10-16 22:45:47',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('295','HAENDLERBUND_KEY','','0',NULL,NULL,'0000-00-00 00:00:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('296','HAENDLERBUND_IMPRESSUM_HBON','','0',NULL,NULL,'0000-00-00 00:00:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('297','HAENDLERBUND_AGB_HBON','','0',NULL,NULL,'0000-00-00 00:00:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('298','HAENDLERBUND_WIDERRUF_HBON','','0',NULL,NULL,'0000-00-00 00:00:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('299','HAENDLERBUND_RUECKGABE_HBON','','0',NULL,NULL,'0000-00-00 00:00:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('300','HAENDLERBUND_VERSANDINFO_HBON','','0',NULL,NULL,'0000-00-00 00:00:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('301','HAENDLERBUND_DATENSCHUTZ_HBON','','0',NULL,NULL,'0000-00-00 00:00:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('302','HAENDLERBUND_BATTERIEGESETZ_HBON','','0',NULL,NULL,'0000-00-00 00:00:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('303','HAENDLERBUND_IMPRESSUM','','0',NULL,NULL,'0000-00-00 00:00:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('304','HAENDLERBUND_AGB','','0',NULL,NULL,'0000-00-00 00:00:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('305','HAENDLERBUND_WIDERRUF','','0',NULL,NULL,'0000-00-00 00:00:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('306','HAENDLERBUND_RUECKGABE','','0',NULL,NULL,'0000-00-00 00:00:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('307','HAENDLERBUND_VERSANDINFO','','0',NULL,NULL,'0000-00-00 00:00:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('308','HAENDLERBUND_DATENSCHUTZ','','0',NULL,NULL,'0000-00-00 00:00:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('309','HAENDLERBUND_BATTERIEGESETZ','','0',NULL,NULL,'0000-00-00 00:00:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('569','MODULE_PAYMENT_PAYPAL_IPN_CURRENCY','Only EUR','6','6',NULL,'2014-11-01 17:07:45',NULL,'xtc_cfg_select_option(array(\'Selected Currency\',\'Only USD\',\'Only CAD\',\'Only EUR\',\'Only GBP\',\'Only JPY\',\'Only CHF\'), ');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('566','MODULE_PAYMENT_PAYPAL_IPN_STATUS','True','6','3',NULL,'2014-11-01 17:07:45',NULL,'xtc_cfg_select_option(array(\'True\', \'False\'), ');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('567','MODULE_PAYMENT_PAYPAL_IPN_ALLOWED','','6','0',NULL,'2014-11-01 17:07:45',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('568','MODULE_PAYMENT_PAYPAL_IPN_ID','info@fensterdichtungen.org','6','4',NULL,'2014-11-01 17:07:45',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('561','PAYPAL_API_CO_BACK','','111125','22',NULL,'2014-11-01 17:05:51','','');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('562','PAYPAL_API_CO_BORD','','111125','23',NULL,'2014-11-01 17:05:51','','');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('563','PAYPAL_ERROR_DEBUG','false','111125','24',NULL,'2014-11-01 17:05:51','','xtc_cfg_select_option(array(\"true\", \"false\"),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('564','PAYPAL_INVOICE','','111125','25',NULL,'2014-11-01 17:05:51','','');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('565','PAYPAL_API_KEY','109,111,100,105,102,105,101,100,95,67,97,114,116,95,69,67,77','6','5',NULL,'2014-11-01 17:05:51','','');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('560','PAYPAL_API_IMAGE','','111125','21',NULL,'2014-11-01 17:05:51','','');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('558','PAYPAL_EXPRESS_ADDRESS_OVERRIDE','true','111125','18',NULL,'2014-11-01 17:05:51','','xtc_cfg_select_option(array(\"true\", \"false\"),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('559','PAYPAL_API_VERSION','84.0','111125','20',NULL,'2014-11-01 17:05:51','','');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('557','PAYPAL_EXPRESS_ADDRESS_CHANGE','true','111125','17',NULL,'2014-11-01 17:05:51','','xtc_cfg_select_option(array(\"true\", \"false\"),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('556','PAYPAL_COUNTRY_MODE','de','111125','16',NULL,'2014-11-01 17:05:51','','xtc_cfg_select_option(array(\"de\", \"uk\"),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('554','PAYPAL_ORDER_STATUS_PENDING_ID','12','111125','11',NULL,'2014-11-01 17:05:51','xtc_get_order_status_name','xtc_cfg_pull_down_order_statuses(');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('555','PAYPAL_ORDER_STATUS_REJECTED_ID','13','111125','12',NULL,'2014-11-01 17:05:51','xtc_get_order_status_name','xtc_cfg_pull_down_order_statuses(');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('553','PAYPAL_ORDER_STATUS_SUCCESS_ID','11','111125','10',NULL,'2014-11-01 17:05:51','xtc_get_order_status_name','xtc_cfg_pull_down_order_statuses(');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('452','MODULE_PAYMENT_EUTRANSFER_ACCNAM','47260121','6','1',NULL,'2014-10-18 12:55:55',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('450','MODULE_PAYMENT_EUTRANSFER_BANKNAM','Vollsbank Paderborn ','6','1',NULL,'2014-10-18 12:55:55',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('451','MODULE_PAYMENT_EUTRANSFER_BRANCH','Fensterdichtungen.org  Hardy Zich','6','1',NULL,'2014-10-18 12:55:55',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('448','MODULE_PAYMENT_EUSTANDARDTRANSFER_ALLOWED','','6','0',NULL,'2014-10-18 12:55:55',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('449','MODULE_PAYMENT_EUTRANSFER_STATUS','True','6','3',NULL,'2014-10-18 12:55:55',NULL,'xtc_cfg_select_option(array(\'True\', \'False\'), ');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('589','MODULE_PAYMENT_PN_SOFORTUEBERWEISUNG_ALLOWED','','6','0',NULL,'2014-11-01 18:18:10',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('590','MODULE_PAYMENT_PN_SOFORTUEBERWEISUNG_USER_ID','99779','6','4',NULL,'2014-11-01 18:18:10',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('591','MODULE_PAYMENT_PN_SOFORTUEBERWEISUNG_PROJECT_ID','207490','6','4',NULL,'2014-11-01 18:18:10',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('592','MODULE_PAYMENT_PN_SOFORTUEBERWEISUNG_PROJECT_PASSWORD','Ni$G4E','6','4',NULL,'2014-11-01 18:18:10',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('593','MODULE_PAYMENT_PN_SOFORTUEBERWEISUNG_PROJECT_NOTIF_PASSWORD','Ni$G4E','6','4',NULL,'2014-11-01 18:18:10',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('594','MODULE_PAYMENT_PN_SOFORTUEBERWEISUNG_HASH_ALGORITHM','sha512','6','4',NULL,'2014-11-01 18:18:10',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('595','MODULE_PAYMENT_PN_SOFORTUEBERWEISUNG_SORT_ORDER','1','6','20',NULL,'2014-11-01 18:18:10',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('596','MODULE_PAYMENT_PN_SOFORTUEBERWEISUNG_ZONE','5','6','2',NULL,'2014-11-01 18:18:10','xtc_get_zone_class_title','xtc_cfg_pull_down_zone_classes(');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('597','MODULE_PAYMENT_PN_SOFORTUEBERWEISUNG_ORDER_STATUS_ID','1','6','10',NULL,'2014-11-01 18:18:10','xtc_get_order_status_name','xtc_cfg_pull_down_order_statuses(');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('598','MODULE_PAYMENT_PN_SOFORTUEBERWEISUNG_TMP_STATUS_ID','1','6','8',NULL,'2014-11-01 18:18:10','xtc_get_order_status_name','xtc_cfg_pull_down_order_statuses(');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('599','MODULE_PAYMENT_PN_SOFORTUEBERWEISUNG_UNC_STATUS_ID','1','6','9',NULL,'2014-11-01 18:18:10','xtc_get_order_status_name','xtc_cfg_pull_down_order_statuses(');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('600','MODULE_PAYMENT_PN_SOFORTUEBERWEISUNG_RECEIVED_STATUS_ID','1','6','11',NULL,'2014-11-01 18:18:10','xtc_get_order_status_name','xtc_cfg_pull_down_order_statuses(');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('601','MODULE_PAYMENT_PN_SOFORTUEBERWEISUNG_LOSS_STATUS_ID','1','6','12',NULL,'2014-11-01 18:18:10','xtc_get_order_status_name','xtc_cfg_pull_down_order_statuses(');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('602','MODULE_PAYMENT_PN_SOFORTUEBERWEISUNG_REASON_1','Nr. {{order_id}} Kd-Nr. {{customer_id}}','6','4',NULL,'2014-11-01 18:18:10',NULL,'xtc_cfg_select_option(array(\'Nr. {{order_id}} Kd-Nr. {{customer_id}}\',\'-TRANSACTION-\'), ');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('587','MODULE_PAYMENT_PN_SOFORTUEBERWEISUNG_STATUS','False','6','3',NULL,'2014-11-01 18:18:10',NULL,'xtc_cfg_select_option(array(\'True\', \'False\'), ');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('588','MODULE_PAYMENT_PN_SOFORTUEBERWEISUNG_KS_STATUS','True','6','3',NULL,'2014-11-01 18:18:10',NULL,'xtc_cfg_select_option(array(\'True\', \'False\'), ');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('387','MODULE_SHIPPING_AP_STATUS','True','6','0',NULL,'2014-10-18 12:14:00',NULL,'xtc_cfg_select_option(array(\'True\', \'False\'), ');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('388','MODULE_SHIPPING_AP_HANDLING','0','6','0',NULL,'2014-10-18 12:14:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('389','MODULE_SHIPPING_AP_TAX_CLASS','0','6','0',NULL,'2014-10-18 12:14:00','xtc_get_tax_class_title','xtc_cfg_pull_down_tax_classes(');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('390','MODULE_SHIPPING_AP_ZONE','0','6','0',NULL,'2014-10-18 12:14:00','xtc_get_zone_class_title','xtc_cfg_pull_down_zone_classes(');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('391','MODULE_SHIPPING_AP_SORT_ORDER','1','6','0',NULL,'2014-10-18 12:14:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('392','MODULE_SHIPPING_AP_ALLOWED','AT','6','0',NULL,'2014-10-18 12:14:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('393','MODULE_SHIPPING_AP_COUNTRIES_1','DE,IT,SM','6','0',NULL,'2014-10-18 12:14:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('394','MODULE_SHIPPING_AP_COST_1','1:8,90,2:17.80,3:21.25,4:16.70,5:18.15,6:19.60,7:21.05,8:22.50,9:23.95,10:25.40,11:26.85,12:28.30,13:29.75,14:31.20,15:32.65,16:34.10,17:35.55,18:37.00,19:38.45,20:39.90','6','0',NULL,'2014-10-18 12:14:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('395','MODULE_SHIPPING_AP_COUNTRIES_2','AD,BE,DK,FO,GL,FI,FR,GR,GB,IE,LI,LU,MC,NL,PT,SE,CH,SK,SI,ES,CZ,HU,VA','6','0',NULL,'2014-10-18 12:14:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('396','MODULE_SHIPPING_AP_COST_2','1:13.08,2:15.26,3:17.44,4:19.62,5:21.80,6:23.98,7:26.16,8:28.34,9:30.52,10:32.70,11:34.88,12:37.06,13:39.24,14:41.42,15:43.60,16:45.78,17:47.96,18:50.14,19:52.32,20:54.50','6','0',NULL,'2014-10-18 12:14:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('397','MODULE_SHIPPING_AP_COUNTRIES_3','EG,AL,DZ,AM,AZ,BA,BG,EE,GE,GI,IS,IL,YU,HR,LV,LB,LY,LT,MT,MA,MK,MD,NO,PL,RO,RU,SY,TN,TR,UA,CY','6','0',NULL,'2014-10-18 12:14:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('398','MODULE_SHIPPING_AP_COST_3','1:14.53,2:18.16,3:21.79,4:25.42,5:29.05,6:32.68,7:36.31,8:39.94,9:43.57,10:47.20,11:50.83,12:54.46,13:58.09,14:61.72,15:65.35,16:68.98,17:72.61,18:76.24,19:79.87,20:83.50','6','0',NULL,'2014-10-18 12:14:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('399','MODULE_SHIPPING_AP_COUNTRIES_4','ET,BH,BJ,BF,CI,DJ,ER,GM,GH,GU,GN,GW,IQ,IR,YE,JO,CM,CA,CV,KZ,QA,KG,KW,LR,ML,MH,MR,FM,NE,NG,MP,OM,PR,SA,SN,SL,SO,SD,TJ,TG,TD,TM,UZ,AE,US,UM,CF','6','0',NULL,'2014-10-18 12:14:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('400','MODULE_SHIPPING_AP_COST_4','1:17.44,2:23.98,3:30.52,4:37.06,5:43.60,6:50.14,7:56.68,8:63.22,9:69.76,10:76.30,11:82.84,12:89.38,13:95.92,14:102.46,15:109.00,16:115.54,17:122.08,18:128.62,19:135.16,20:141.70','6','0',NULL,'2014-10-18 12:14:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('401','MODULE_SHIPPING_AP_COUNTRIES_5','AF,AO,AI,AG,GQ,AR,BS,BD,BB,BZ,BM,BT,BO,BW,BR,BN,BI,KY,CL,CN,CR,DM,DO,EC,SV,FK,GF,GA,GD,GP,GT,GY,HT,HN,HK,IN,ID,TP,JM,JP,KH,KE,CO,KM,CG,KP,KR,CU,LA,LS','6','0',NULL,'2014-10-18 12:14:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('402','MODULE_SHIPPING_AP_COST_5','1:19.62,2:28.34,3:37.06,4:45.78,5:54.50,6:63.22,7:71.94,8:80.66,9:89.38,10:98.10,11:106.82,12:115.54,13:124.26,14:132.98,15:141.70,16:150.42,17:159.14,18:167.86,19:176.58,20:185.30','6','0',NULL,'2014-10-18 12:14:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('403','MODULE_SHIPPING_AP_COUNTRIES_6','MO,MG,MW,MY,MV,MQ,MU,MX,MN,MS,MZ,MM,NA,NP,NI,AN,AW,PK,PA,PY,PE,PH,RE,RW,ZM,ST,SC,ZW,SG,LK,KN,LC,PM,VC,ZA,SR,SZ,TZ,TH,TT,TC,UG,UY,VE,VN,VG','6','0',NULL,'2014-10-18 12:14:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('404','MODULE_SHIPPING_AP_COST_6','1:19.62,2:28.34,3:37.06,4:45.78,5:54.50,6:63.22,7:71.94,8:80.66,9:89.38,10:98.10,11:106.82,12:115.54,13:124.26,14:132.98,15:141.70,16:150.42,17:159.14,18:167.86,19:176.58,20:185.30','6','0',NULL,'2014-10-18 12:14:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('405','MODULE_SHIPPING_AP_COUNTRIES_7','AU,CK,FJ,PF,KI,NR,NC,NZ,PG,PN,SB,TO,TV,VU,WF,WS','6','0',NULL,'2014-10-18 12:14:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('406','MODULE_SHIPPING_AP_COST_7','1:23.98,2:37.06,3:50.14,4:63.22,5:76.30,6:89.38,7:102.46,8:115.54,9:128.62,10:141.70,11:154.78,12:167.86,13:180.94,14:194.02,15:207.10,16:220.18,17:233.26,18:246.34,19:259.42,20:272.50','6','0',NULL,'2014-10-18 12:14:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('407','MODULE_SHIPPING_AP_COUNTRIES_8','AT','6','0',NULL,'2014-10-18 12:14:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('408','MODULE_SHIPPING_AP_COST_8','2:8,9,4:17.,8:25.45,12:6.90,20:9.08,31.5:12.72','6','0',NULL,'2014-10-18 12:14:00',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('604','MODULE_PAYMENT_PN_SOFORTUEBERWEISUNG_IMAGE','Infographic','6','6',NULL,'2014-11-01 18:18:10',NULL,'xtc_cfg_select_option(array(\'Infographic\',\'Logo & Text\',\'Logo\'), ');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('603','MODULE_PAYMENT_PN_SOFORTUEBERWEISUNG_TEXT_REASON_2','Spezial - Fensterdichtungen für alle Fenstertarten','6','4',NULL,'2014-11-01 18:18:10',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('584','MODULE_PAYMENT_PAYPAL_IPN_NOTIFY','','6','20',NULL,'2014-11-01 17:07:45',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('585','MODULE_PAYMENT_PAYPAL_IPN_CBT','','6','21',NULL,'2014-11-01 17:07:45',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('586','MODULE_PAYMENT_PAYPAL_IPN_SBID','sandbox@yourbusiness.com','6','4',NULL,'2014-11-01 17:07:45',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('581','MODULE_PAYMENT_PAYPAL_IPN_CO_SITE','','6','17',NULL,'2014-11-01 17:07:45',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('582','MODULE_PAYMENT_PAYPAL_IPN_RETURN','','6','18',NULL,'2014-11-01 17:07:45',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('583','MODULE_PAYMENT_PAYPAL_IPN_CANCEL','','6','19',NULL,'2014-11-01 17:07:45',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('578','MODULE_PAYMENT_PAYPAL_IPN_IMAGE','','6','14',NULL,'2014-11-01 17:07:45',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('579','MODULE_PAYMENT_PAYPAL_IPN_CO_BACK','','6','15',NULL,'2014-11-01 17:07:45',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('580','MODULE_PAYMENT_PAYPAL_IPN_CO_BORD','','6','16',NULL,'2014-11-01 17:07:45',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('576','MODULE_PAYMENT_PAYPAL_IPN_USE_ACCOUNT','True','6','12',NULL,'2014-11-01 17:07:45',NULL,'xtc_cfg_select_option(array(\'True\', \'False\'), ');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('577','MODULE_PAYMENT_PAYPAL_IPN_USE_SANDBOX','False','6','13',NULL,'2014-11-01 17:07:45',NULL,'xtc_cfg_select_option(array(\'True\', \'False\'), ');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('575','MODULE_PAYMENT_PAYPAL_IPN_USE_EMAIL','True','6','11',NULL,'2014-11-01 17:07:45',NULL,'xtc_cfg_select_option(array(\'True\', \'False\'), ');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('573','MODULE_PAYMENT_PAYPAL_IPN_TMP_STATUS_ID','1','6','8',NULL,'2014-11-01 17:07:45','xtc_get_order_status_name','xtc_cfg_pull_down_order_statuses(');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('574','MODULE_PAYMENT_PAYPAL_IPN_USE_CHECKOUT','True','6','10',NULL,'2014-11-01 17:07:45',NULL,'xtc_cfg_select_option(array(\'True\', \'False\'), ');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('570','MODULE_PAYMENT_PAYPAL_IPN_SORT_ORDER','0','6','0',NULL,'2014-11-01 17:07:45',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('571','MODULE_PAYMENT_PAYPAL_IPN_ZONE','5','6','2',NULL,'2014-11-01 17:07:45','xtc_get_zone_class_title','xtc_cfg_pull_down_zone_classes(');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('572','MODULE_PAYMENT_PAYPAL_IPN_ORDER_STATUS_ID','0','6','0',NULL,'2014-11-01 17:07:45','xtc_get_order_status_name','xtc_cfg_pull_down_order_statuses(');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('463','MODULE_ORDER_TOTAL_SHIPPING_TAX_CLASS','0','6','7',NULL,'2014-10-18 13:02:08','xtc_get_tax_class_title','xtc_cfg_pull_down_tax_classes(');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('453','MODULE_PAYMENT_EUTRANSFER_ACCNUM','419351600','6','1',NULL,'2014-10-18 12:55:55',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('454','MODULE_PAYMENT_EUTRANSFER_ACCIBAN','DE32472601210419351600','6','1',NULL,'2014-10-18 12:55:55',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('455','MODULE_PAYMENT_EUTRANSFER_BANKBIC','DGPBDE3MXXX','6','1',NULL,'2014-10-18 12:55:55',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('456','MODULE_PAYMENT_EUTRANSFER_SORT_ORDER','1','6','0',NULL,'2014-10-18 12:55:55',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('545','PAYPAL_MODE','live','111125','1',NULL,'2014-11-01 17:05:51','','xtc_cfg_select_option(array(\"live\", \"sandbox\"),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('509','MODULE_SHIPPING_TABLE_STATUS','True','6','0',NULL,'2014-10-18 13:39:17',NULL,'xtc_cfg_select_option(array(\'True\', \'False\'), ');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('510','MODULE_SHIPPING_TABLE_ALLOWED','','6','0',NULL,'2014-10-18 13:39:17',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('511','MODULE_SHIPPING_TABLE_COST','20:3.90,159.99:6.90,160.00:0.00','6','0',NULL,'2014-10-18 13:39:17',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('512','MODULE_SHIPPING_TABLE_MODE','price','6','0',NULL,'2014-10-18 13:39:17',NULL,'xtc_cfg_select_option(array(\'weight\', \'price\'), ');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('513','MODULE_SHIPPING_TABLE_HANDLING','0','6','0',NULL,'2014-10-18 13:39:17',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('514','MODULE_SHIPPING_TABLE_TAX_CLASS','0','6','0',NULL,'2014-10-18 13:39:17','xtc_get_tax_class_title','xtc_cfg_pull_down_tax_classes(');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('515','MODULE_SHIPPING_TABLE_ZONE','0','6','0',NULL,'2014-10-18 13:39:17','xtc_get_zone_class_title','xtc_cfg_pull_down_zone_classes(');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('516','MODULE_SHIPPING_TABLE_SORT_ORDER','0','6','0',NULL,'2014-10-18 13:39:17',NULL,NULL);
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('551','PAYPAL_API_SANDBOX_SIGNATURE','','111125','7',NULL,'2014-11-01 17:05:51','','');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('552','PAYPAL_ORDER_STATUS_TMP_ID','10','111125','9',NULL,'2014-11-01 17:05:51','xtc_get_order_status_name','xtc_cfg_pull_down_order_statuses(');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('550','PAYPAL_API_SANDBOX_PWD','','111125','6',NULL,'2014-11-01 17:05:51','','');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('546','PAYPAL_API_USER','','111125','2',NULL,'2014-11-01 17:05:51','','');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('547','PAYPAL_API_PWD','','111125','3',NULL,'2014-11-01 17:05:51','','');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('548','PAYPAL_API_SIGNATURE','','111125','4',NULL,'2014-11-01 17:05:51','','');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('549','PAYPAL_API_SANDBOX_USER','','111125','5',NULL,'2014-11-01 17:05:51','','');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('541','MODULE_PAYMENT_PAYPAL_STATUS','False','6','3',NULL,'2014-11-01 17:05:51','','xtc_cfg_select_option(array(\'True\', \'False\'),');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('542','MODULE_PAYMENT_PAYPAL_SORT_ORDER','0','6','0',NULL,'2014-11-01 17:05:51','','');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('543','MODULE_PAYMENT_PAYPAL_ALLOWED','','6','0',NULL,'2014-11-01 17:05:51','','');
INSERT INTO `configuration` (`configuration_id`, `configuration_key`, `configuration_value`, `configuration_group_id`, `sort_order`, `last_modified`, `date_added`, `use_function`, `set_function`) VALUES ('544','MODULE_PAYMENT_PAYPAL_ZONE','0','6','2',NULL,'2014-11-01 17:05:51','xtc_get_zone_class_title','xtc_cfg_pull_down_zone_classes(');
/*!40000 ALTER TABLE `configuration` ENABLE KEYS */;

DROP TABLE IF EXISTS `configuration_group`;
CREATE TABLE `configuration_group` (
  `configuration_group_id` int(11) NOT NULL AUTO_INCREMENT,
  `configuration_group_title` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `configuration_group_description` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `sort_order` int(5) DEFAULT NULL,
  `visible` int(1) DEFAULT '1',
  PRIMARY KEY (`configuration_group_id`)
) ENGINE=MyISAM AUTO_INCREMENT=111126 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `configuration_group` DISABLE KEYS */;
INSERT INTO `configuration_group` (`configuration_group_id`, `configuration_group_title`, `configuration_group_description`, `sort_order`, `visible`) VALUES ('1','My Store','General information about my store','1','1');
INSERT INTO `configuration_group` (`configuration_group_id`, `configuration_group_title`, `configuration_group_description`, `sort_order`, `visible`) VALUES ('2','Minimum Values','The minimum values for functions / data','2','1');
INSERT INTO `configuration_group` (`configuration_group_id`, `configuration_group_title`, `configuration_group_description`, `sort_order`, `visible`) VALUES ('3','Maximum Values','The maximum values for functions / data','3','1');
INSERT INTO `configuration_group` (`configuration_group_id`, `configuration_group_title`, `configuration_group_description`, `sort_order`, `visible`) VALUES ('4','Images','Image parameters','4','1');
INSERT INTO `configuration_group` (`configuration_group_id`, `configuration_group_title`, `configuration_group_description`, `sort_order`, `visible`) VALUES ('5','Customer Details','Customer account configuration','5','1');
INSERT INTO `configuration_group` (`configuration_group_id`, `configuration_group_title`, `configuration_group_description`, `sort_order`, `visible`) VALUES ('6','Module Options','Hidden from configuration','6','0');
INSERT INTO `configuration_group` (`configuration_group_id`, `configuration_group_title`, `configuration_group_description`, `sort_order`, `visible`) VALUES ('7','Shipping/Packaging','Shipping options available at my store','7','1');
INSERT INTO `configuration_group` (`configuration_group_id`, `configuration_group_title`, `configuration_group_description`, `sort_order`, `visible`) VALUES ('8','Product Listing','Product Listing configuration options','8','1');
INSERT INTO `configuration_group` (`configuration_group_id`, `configuration_group_title`, `configuration_group_description`, `sort_order`, `visible`) VALUES ('9','Stock','Stock configuration options','9','1');
INSERT INTO `configuration_group` (`configuration_group_id`, `configuration_group_title`, `configuration_group_description`, `sort_order`, `visible`) VALUES ('10','Logging','Logging configuration options','10','1');
INSERT INTO `configuration_group` (`configuration_group_id`, `configuration_group_title`, `configuration_group_description`, `sort_order`, `visible`) VALUES ('11','Cache','Caching configuration options','11','1');
INSERT INTO `configuration_group` (`configuration_group_id`, `configuration_group_title`, `configuration_group_description`, `sort_order`, `visible`) VALUES ('12','E-Mail Options','General setting for E-Mail transport and HTML E-Mails','12','1');
INSERT INTO `configuration_group` (`configuration_group_id`, `configuration_group_title`, `configuration_group_description`, `sort_order`, `visible`) VALUES ('13','Download','Downloadable products options','13','1');
INSERT INTO `configuration_group` (`configuration_group_id`, `configuration_group_title`, `configuration_group_description`, `sort_order`, `visible`) VALUES ('14','GZip Compression','GZip compression options','14','1');
INSERT INTO `configuration_group` (`configuration_group_id`, `configuration_group_title`, `configuration_group_description`, `sort_order`, `visible`) VALUES ('15','Sessions','Session options','15','1');
INSERT INTO `configuration_group` (`configuration_group_id`, `configuration_group_title`, `configuration_group_description`, `sort_order`, `visible`) VALUES ('16','Meta-Tags/Search engines','Meta-tags/Search engines','16','1');
INSERT INTO `configuration_group` (`configuration_group_id`, `configuration_group_title`, `configuration_group_description`, `sort_order`, `visible`) VALUES ('17','Additional Modules','Additional Modules','17','1');
INSERT INTO `configuration_group` (`configuration_group_id`, `configuration_group_title`, `configuration_group_description`, `sort_order`, `visible`) VALUES ('18','Vat ID','Vat ID','18','1');
INSERT INTO `configuration_group` (`configuration_group_id`, `configuration_group_title`, `configuration_group_description`, `sort_order`, `visible`) VALUES ('19','Google Conversion','Google Conversion-Tracking','19','1');
INSERT INTO `configuration_group` (`configuration_group_id`, `configuration_group_title`, `configuration_group_description`, `sort_order`, `visible`) VALUES ('20','Import/Export','Import/Export','20','1');
INSERT INTO `configuration_group` (`configuration_group_id`, `configuration_group_title`, `configuration_group_description`, `sort_order`, `visible`) VALUES ('21','Afterbuy','Afterbuy.de','21','1');
INSERT INTO `configuration_group` (`configuration_group_id`, `configuration_group_title`, `configuration_group_description`, `sort_order`, `visible`) VALUES ('22','Search Options','Additional Options for search function','22','1');
INSERT INTO `configuration_group` (`configuration_group_id`, `configuration_group_title`, `configuration_group_description`, `sort_order`, `visible`) VALUES ('23','Econda Tracking','Econda Tracking System','23','1');
INSERT INTO `configuration_group` (`configuration_group_id`, `configuration_group_title`, `configuration_group_description`, `sort_order`, `visible`) VALUES ('24','PIWIK &amp; Google Analytics Tracking','Settings for PIWIK &amp; Google Analytics Tracking','24','1');
INSERT INTO `configuration_group` (`configuration_group_id`, `configuration_group_title`, `configuration_group_description`, `sort_order`, `visible`) VALUES ('31','Moneybookers','Moneybookers System','31','1');
INSERT INTO `configuration_group` (`configuration_group_id`, `configuration_group_title`, `configuration_group_description`, `sort_order`, `visible`) VALUES ('40','Popup Window Configuration','Popup Window Parameters','40','1');
INSERT INTO `configuration_group` (`configuration_group_id`, `configuration_group_title`, `configuration_group_description`, `sort_order`, `visible`) VALUES ('1000','Adminarea Options','Adminarea Configuration','1000','1');
INSERT INTO `configuration_group` (`configuration_group_id`, `configuration_group_title`, `configuration_group_description`, `sort_order`, `visible`) VALUES ('111125','PayPal','PayPal','25','1');
/*!40000 ALTER TABLE `configuration_group` ENABLE KEYS */;

DROP TABLE IF EXISTS `content_manager`;
CREATE TABLE `content_manager` (
  `content_id` int(11) NOT NULL AUTO_INCREMENT,
  `categories_id` int(11) NOT NULL DEFAULT '0',
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `group_ids` text COLLATE latin1_german1_ci,
  `languages_id` int(11) NOT NULL DEFAULT '0',
  `content_title` text COLLATE latin1_german1_ci NOT NULL,
  `content_heading` text COLLATE latin1_german1_ci NOT NULL,
  `content_text` text COLLATE latin1_german1_ci NOT NULL,
  `sort_order` int(4) NOT NULL DEFAULT '0',
  `file_flag` int(1) NOT NULL DEFAULT '0',
  `content_file` varchar(64) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `content_status` int(1) NOT NULL DEFAULT '0',
  `content_group` int(11) NOT NULL,
  `content_delete` int(1) NOT NULL DEFAULT '1',
  `content_meta_title` text COLLATE latin1_german1_ci,
  `content_meta_description` text COLLATE latin1_german1_ci,
  `content_meta_keywords` text COLLATE latin1_german1_ci,
  PRIMARY KEY (`content_id`),
  FULLTEXT KEY `content_meta_title` (`content_meta_title`,`content_meta_description`,`content_meta_keywords`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `content_manager` DISABLE KEYS */;
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('1','0','0','','1','Shipping &amp; Returns','Shipping &amp; Returns','Put here your Shipping &amp; Returns information.','0','1','','1','1','0','','','');
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('2','0','0','','1','Privacy Notice','Privacy Notice','Put here your Privacy Notice information.','0','1','','1','2','0','','','');
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('3','0','0','','1','Conditions of Use','Conditions of Use','Conditions of Use<br />Put here your Conditions of Use information.<br /><br /><ol><li>Geltungsbereich</li><li>Vertragspartner</li><li>Angebot und Vertragsschluss</li><li>Widerrufsrecht, Widerrufsbelehrung, Widerrufsfolgen</li><li>Preise und Versandkosten</li><li>Lieferung</li><li>Zahlung</li><li>Eigentumsvorbehalt</li><li>Gew&auml;hrleistung</li></ol>Weitere Informationen','0','1','','1','3','0','','','');
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('4','0','0','','1','Imprint','Imprint','Put here your Company information.<br /><br />DemoShop GmbH<br />Gesch&auml;ftsf&uuml;hrer: Max Muster und Fritz Beispiel<br /><br />Max Muster Stra&szlig;e 21-23<br />D-0815 Musterhausen<br />E-Mail: max.muster@muster.de<br /><br />HRB 123456<br />Amtsgericht Musterhausen<br />UStid-Nr. DE 000 111 222','0','1','','1','4','0','','','');
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('5','0','0','','1','Index','Welcome','{$greeting}<br /><br />Dies ist die Standardinstallation der <strong><span style=\"color:#B0347E;\">mod</span><span style=\"color:#6D6D6D;\">ified eCommerce Shopsoftware</span></strong>. Alle dargestellten Produkte dienen zur Demonstration der Funktionsweise. Wenn Sie Produkte bestellen, so werden diese weder ausgeliefert, noch in Rechnung gestellt. <br /><br />Sollten Sie daran interessiert sein das Programm, welches die Grundlage f&uuml;r diesen Shop bildet, einzusetzen, so besuchen Sie bitte die Webseite der <a href=\"http://www.modified-shop.org\" target=\"_blank\"><u><strong><span style=\"color:#B0347E;\">mod</span><span style=\"color:#6D6D6D;\">ified eCommerce Shopsoftware</span></strong></u></a>.<br /><br />Der hier dargestellte Text kann im Adminbereich unter <b>Content Manager</b> - Eintrag Index bearbeitet werden.','0','1','','0','5','0','','','');
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('6','0','0','','2','Liefer- und Versandkosten','Liefer- und Versandkosten','<p><strong><span style=\"font-family: Verdana;\"><span style=\"font-size: small;\">Liefer- und Versandkosten</span></span></strong><span style=\"font-family: Verdana;\"><span style=\"font-size: small;\"><br />\r\n<br />\r\n<br />\r\n</span></span><strong><span style=\"font-family: Verdana;\"><span style=\"font-size: small;\">Deutschland:</span></span></strong></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: small;\">Bestellungen unter 500 Gramm berechnen wir 3,90 &euro; als Briefsendung<br />\r\n<br />\r\n<br />\r\nBei allen Sendungen bis 2 KG. ( ca. 50 lfm. Dichtungen ) betragen die Versandkosten 6,90 &euro; ( versichertes Paket )<br />\r\n</span></span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: small;\"><br />\r\nAusnahme: f&uuml;r Versand auf deutsche Inseln, die nicht auf dem Landweg erreichbar sind,<br />\r\nberechnen wir einen Inselzuschlag f&uuml;r Warensendungen 15,00 EURO. <br />\r\n<br />\r\n<br />\r\nDer Versand erfolgt nur nach Zahlungseingang innerhalb von 2 - 3 Werktagen.<br />\r\n<br />\r\n&nbsp;<br />\r\n<br />\r\nVersand nur nach Vorkasse (PayPal, Sofort&uuml;berweisung bzw. Bank&uuml;berweisung m&ouml;glich ).<br />\r\nWir versenden national sowie in die EU mit DHL<br />\r\nPackstationen werden bis einer Paketgr&ouml;&szlig;e von 600 x 300 x 150 mm beliefert<br />\r\n&nbsp;<br />\r\n<br />\r\n<strong>Versandkosten Ausland:</strong><br />\r\n<br />\r\nVersand als P&auml;ckchen mit DHL bis 1 KG nicht versichert ( 1 Rolle 25 lfm. ). EU - L&auml;nder 8,90 EURO.<br />\r\n<br />\r\nVersand als Paket mit DHL &uuml;ber 2 KG. ( 2 Rollen 25 lfm. ) EU - L&auml;nder 17,90 EURO.<br />\r\n<br />\r\nVersand als Paket per Nachnahme ist nicht m&ouml;glich.<br />\r\n<br />\r\nVersand in die Schweiz je nach Gewicht mindestens 22,00 &euro; - 55,00 &euro;<br />\r\n<br />\r\n<br />\r\n<br />\r\nPaketversand ab 2 KG ( ab 2 Rollen 50 lfm. ).<br />\r\n<br />\r\nVersand nach &Ouml;sterreich bzw. EU - L&auml;nder, Vorkasse: 17.90 EURO<br />\r\nVersand nach Schweiz je nach Gewicht und Aufwand, mindestens 32,00 EURO<br />\r\n&nbsp;<br />\r\n<br />\r\n<strong>Versand per Spedition</strong><br />\r\n<br />\r\nVersand nach &Ouml;sterreich, Vorkasse: 99,00 EUR<br />\r\nVersand nach Schweiz, Vorkasse: 129,00 EUR<br />\r\n&nbsp;<br />\r\n<br />\r\nZoll- &amp; Einfuhrgeb&uuml;hren f&uuml;r Schweizer Kunden<br />\r\nDie Lieferung erfolgt exkl. Mehrwertsteuer. Zus&auml;tzlich zu den berechneten Versandkosten fallen hier i.d.R. weitere Kosten im Rahmen der Einfuhr an. Dabei handelt es sich meist um die nationale Umsatzsteuer sowie anfallende Einfuhrz&ouml;lle.<br />\r\n<br />\r\n&nbsp;<br />\r\n<br />\r\nLieferung</span></span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: small;\"><br />\r\nPakete &uuml;ber 2 KG. werden ebenfalls als versichertes Paket durch DHL versendet.<br />\r\n<br />\r\n&nbsp;<br />\r\n<br />\r\nAbholung.<br />\r\nSie k&ouml;nnen auch direkt bei uns Ihre Ware selbst abholen. Bitte setzen Sie sich bei Selbstabholung vorab mit uns in Verbindung, sodass wir Ihre bestellte Ware bereitstellen k&ouml;nnen.<br />\r\nBitte beachten Sie, dass Artikel, welche urspr&uuml;nglich f&uuml;r den Speditionsversand vorgesehen waren nur auf Transportmittel mit zugelassener Ladefl&auml;che verladen werden d&uuml;rfen. Sollte der Transport dennoch durchgef&uuml;hrt werden, verst&ouml;&szlig;t dies gegen die Vorschriften der Stra&szlig;enverkehrsordnung und geschieht auf eigene Gefahr. Falls Sie also beabsichtigen, Speditionsware mit Ihrem PKW abzuholen, m&uuml;ssen wir Sie leider dar&uuml;ber in Kenntnis setzen, dass wir Ihnen bei der Beladung Ihres Fahrzeuges nicht behilflich sein d&uuml;rfen, da wir sonst f&uuml;r Sch&auml;den, die durch den unsachgem&auml;&szlig;en Verladevorgang sowie Transport verursacht werden k&ouml;nnten, haftbar gemacht werden. Vielen Dank f&uuml;r Ihr Verst&auml;ndnis.<br />\r\n<br />\r\n</span></span></p>\r\n<p>&nbsp;</p>','0','1','','1','1','0','','','');
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('7','0','0','','2','Privatsphäre und Datenschutz','Privatsphäre und Datenschutz','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: small;\"><br />\r\n</span></span><span style=\"font-size: small;\"><span style=\"font-size: medium;\">Wir verwenden Ihre Bestandsdaten ausschlie&szlig;lich zur Abwicklung Ihrer Bestellung. Alle Kundendaten werden<br />\r\nunter Beachtung der einschl&auml;gigen Vorschriften der Bundesdatenschutzgesetze (BDSG) und des Teledienstdatenschutzgesetzes</span></span></p>\r\n<p><span style=\"font-size: small;\"><span style=\"font-size: medium;\"><br />\r\n(TDDSG) von uns gespeichert und verarbeitet. <br />\r\nSie haben jederzeit ein Recht auf kostenlose Auskunft, Berichtigung, Sperrung und L&ouml;schung Ihrer gespeicherten Daten.<br />\r\nBitte wenden Sie sich an oder senden Sie uns Ihr Verlangen per Post oder Fax. <br />\r\n<br />\r\nWir geben Ihre personenbezogenen Daten einschlie&szlig;lich Ihrer Haus-Adresse und E-Mail-Adresse nicht ohne<br />\r\nIhre ausdr&uuml;ckliche und jederzeit widerrufliche Einwilligung an Dritte weiter. Ausgenommen hiervon sind unsere<br />\r\nDienstleistungspartner, die zur Bestellabwicklung die &Uuml;bermittlung von Daten ben&ouml;tigen (z.B. das mit der Lieferung<br />\r\nbeauftragte Versandunternehmen und das mit der Zahlungsabwicklung beauftragte Kreditinstitut).<br />\r\n<br />\r\nIn diesen F&auml;llenbeschr&auml;nkt sich der Umfang der &uuml;bermittelten Daten jedoch nur auf das erforderliche Minimum. <br />\r\nIn diesem Shop werden in den Cookies Informationen &uuml;ber Ihre Kundendaten lediglich auf Ihren Wunsch hin gespeichert,<br />\r\ndie dann bei Ihren n&auml;chsten Besuchen aufgerufen werden k&ouml;nnen. Die in einem Cookie abgelegten Daten er&uuml;brigen Ihnen<br />\r\ndas wiederholte Ausf&uuml;llen der Formulare und k&ouml;nnen f&uuml;r die Warenkorbfunktion genutzt werden. Sie k&ouml;nnen in Ihrem<br />\r\nBrowser Programm die Annahme von Cookies dieser Seite verwalten und diese gegebenenfalls sperren.</span></span><span style=\"font-family: Verdana;\"><span style=\"font-size: small;\"><br />\r\n</span></span></p>','0','1','','1','2','0','','','');
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('8','0','0','','2','Unsere AGB','Allgemeine Geschäftsbedingungen','<p><strong><br />\r\n</strong><span style=\"font-family: Verdana;\"><span style=\"font-size: small;\">&sect; 1 Allgemeines, Geltungsbereich<br />\r\n<br />\r\nDie folgenden Allgemeinen Gesch&auml;ftsbedingungen (AGB) regeln das Vertragsverh&auml;ltnis zwischen www. fensterdichtungen.org<br />\r\nund den Verbrauchern und Unternehmern, die das Internetangebot von fensterdichtungen.org nutzen (im Folgenden &quot;K&auml;ufer&quot; <br />\r\ngenannt). Die AGB betreffen die Nutzung der Website www.fensterdichtungen.org sowie alle zu dieser Domain geh&ouml;renden<br />\r\nSubdomains. Ma&szlig;geblich ist jeweils die zum Zeitpunkt des Vertragsschlusses g&uuml;ltige Fassung. Die Vertragssprache ist<br />\r\nDeutsch.<br />\r\n<br />\r\nVerbraucher im Sinne dieser Gesch&auml;ftsbedingungen sind nat&uuml;rliche Personen, die mit www.fensterdichtungen.org in<br />\r\nGesch&auml;ftsbeziehung treten, ohne dass dies ihrer gewerblichen oder selbst&auml;ndigen beruflichen T&auml;tigkeit zugerechnet<br />\r\nwerden kann. <br />\r\nUnternehmer im Sinne dieser Gesch&auml;ftsbedingungen sind nat&uuml;rliche und juristische Personen oder rechtsf&auml;hige<br />\r\nPersonengesellschaften, die in Aus&uuml;bung ihrer gewerblichen oder selbst&auml;ndigen beruflichen T&auml;tigkeit mit <br />\r\nfensterdichtungen.org in eine Gesch&auml;ftsbeziehung treten.<br />\r\n<br />\r\n&sect; 2 Vertragsschluss<br />\r\n<br />\r\nDie Angebote von fensterdichtungen.org im Internet stellen eine unverbindliche Aufforderung an den K&auml;ufer dar, bei<br />\r\nwww. fensterdichtungen.org Waren zu bestellen.<br />\r\nDurch die Bestellung des gew&uuml;nschten Kaufgegenstands im Internet gibt der K&auml;ufer ein verbindliches Angebot auf<br />\r\nAbschluss eines Kaufvertrages ab.<br />\r\nFensterdichtungen.org ist berechtigt, dieses Angebot innerhalb von 1 Tag unter Zusendung einer Auftragsbest&auml;tigung<br />\r\nanzunehmen. Die Auftragsbest&auml;tigung wird &uuml;bermittelt durch E-Mail. Nach fruchtlosem Ablauf der in Satz 1 genannten <br />\r\nFrist gilt das Angebot als abgelehnt.<br />\r\n<br />\r\n<br />\r\n&sect; 3 Zahlung, F&auml;lligkeit, Zahlungsverzug<br />\r\n<br />\r\nDie Bezahlung der Waren erfolgt per Vorkasse und Nachnahme per Kreditkarte. Die Bezahlung per Nachnahme ist nur bei<br />\r\nVersand innerhalb Deutschlands m&ouml;glich. Wir behalten uns das Recht vor, im Einzelfall bestimmte Zahlungsarten zu <br />\r\nakzeptieren oder auszuschlie&szlig;en.<br />\r\n<br />\r\nBei Zahlung per Vorkasse verpflichtet sich der K&auml;ufer, den Kaufpreis nach Vertragsschluss unverz&uuml;glich zu zahlen.<br />\r\nBei Zahlung per Nachnahme verpflichtet sich der K&auml;ufer, den Kaufpreis bei Lieferung der Ware zu zahlen. Bei Zahlung<br />\r\nauf Rechnung verpflichtet sich der K&auml;ufer, den Rechnungsbetrag innerhalb von 3 Tagen nach Erhalt der Ware zu begleichen.<br />\r\nBei Zahlung per Bankeinzug erfolgt die Abbuchung innerhalb einer Woche nach Vertragsschluss. Bei Zahlung per Kreditkarte<br />\r\nerfolgt die Abbuchung nach Versendung der Ware.<br />\r\n<br />\r\n<br />\r\nBefindet sich der K&auml;ufer im Zahlungsverzug, hat er w&auml;hrenddessen jede Fahrl&auml;ssigkeit zu vertreten. Er haftet wegen<br />\r\nder Leistung auch f&uuml;r Zufall, es sei denn, dass der Schaden auch bei rechtzeitiger Leistung eingetreten sein w&uuml;rde.<br />\r\nDer Kaufpreis ist w&auml;hrend des Verzugs zu verzinsen. Der Verzugszinssatz betr&auml;gt f&uuml;r das Jahr f&uuml;nf Prozentpunkte &uuml;ber<br />\r\ndem Basiszinssatz. Bei Rechtsgesch&auml;ften, an denen ein Verbraucher nicht beteiligt ist, betr&auml;gt der Zinssatz acht<br />\r\nProzentpunkte &uuml;ber dem Basiszinssatz.<br />\r\n<br />\r\nDie Geltendmachung eines weiteren Schadens ist nicht ausgeschlossen.&nbsp;&nbsp; &nbsp;<br />\r\n<br />\r\n&sect; 4 Lieferung<br />\r\n<br />\r\nDie Lieferung erfolgt durch Sendung des Kaufgegenstands an die vom K&auml;ufer mitgeteilte Adresse.<br />\r\nSoweit Lieferung gegen Vorkasse vereinbart ist, betr&auml;gt die Lieferfrist&nbsp; 2 -3 Werktage nach Erhalt des Kaufpreises.<br />\r\nAnsonsten betr&auml;gt die Lieferfrist 3 - 7 Werktage nach Versand der Auftragsbest&auml;tigung.<br />\r\n<br />\r\nDie Kosten f&uuml;r den Versand des Kaufgegenstands betragen EUR (_6,90____) und sind vom K&auml;ufer zu tragen. <br />\r\nF&uuml;r Auslandslieferungen wird, soweit nichts anderes angegeben ist, der Preis f&uuml;r Verpackung und Versand gesondert nach<br />\r\nGewicht berechnet. Wenn der K&auml;ufer eine spezielle Art der Versendung w&uuml;nscht, bei der h&ouml;here Kosten anfallen, so hat er<br />\r\nauch diese Mehrkosten zu tragen.<br />\r\nErwirbt der K&auml;ufer den Kaufgegenstand f&uuml;r seine gewerbliche oder berufliche T&auml;tigkeit, geht die Gefahr des zuf&auml;lligen<br />\r\nUntergangs und der zuf&auml;lligen Verschlechterung des Kaufgegenstands auf ihn &uuml;ber, sobald fensterdichtungen.org den<br />\r\nKaufgegenstand dem Spediteur, dem Frachtf&uuml;hrer oder der sonst zur Ausf&uuml;hrung der Versendung bestimmten Person oder<br />\r\nAnstalt ausgeliefert hat.<br />\r\n<br />\r\n<br />\r\n<br />\r\n&sect; 5 Eigentumsvorbehalt<br />\r\n<br />\r\nDer Kaufgegenstand bleibt bis zur vollst&auml;ndigen Bezahlung Eigentum von fensterdichtungen.org Vor Eigentums&uuml;bertragung<br />\r\nist eine Verpf&auml;ndung, Sicherungs&uuml;bereignung, Verarbeitung oder Umgestaltung ohne ausdr&uuml;ckliche Einwilligung von fensterdichtungen.org nicht zul&auml;ssig.&nbsp;&nbsp;&nbsp; &nbsp;<br />\r\n<br />\r\n<br />\r\n&sect; 6 Preise<br />\r\n<br />\r\nDer im jeweiligen Angebot angegebene Preis f&uuml;r den Kaufgegenstand versteht sich als Endpreis einschlie&szlig;lich eventuell<br />\r\nanfallender Mehrwertsteuer und weiterer Preisbestandteile. Der Preis umfasst nicht die Liefer- und Versandkosten.<br />\r\n<br />\r\n<br />\r\n&sect; 7 R&uuml;cktritt<br />\r\n<br />\r\nFensterdichtungen.org ist berechtigt, vom Vertrag auch hinsichtlich eines noch offenen Teils der Lieferung oder <br />\r\nLeistung zur&uuml;ckzutreten, wenn falsche Angaben &uuml;ber die Kreditw&uuml;rdigkeit des K&auml;ufers gemacht worden oder objektive<br />\r\n&nbsp;<br />\r\nGr&uuml;nde hinsichtlich der Zahlungsunf&auml;higkeit des K&auml;ufers entstanden sind, bspw. die Er&ouml;ffnung eines Insolvenzverfahrens<br />\r\n&uuml;ber das Verm&ouml;gen des K&auml;ufers oder die Abweisung eines solchen Verfahrens mangels kostendeckenden Verm&ouml;gens. Dem K&auml;ufer<br />\r\nwird vor R&uuml;cktritt die M&ouml;glichkeit einger&auml;umt, eine Vorauszahlung zu leisten oder eine taugliche Sicherheit zu erbringen.<br />\r\nUnbeschadet etwaiger Schadenersatzanspr&uuml;che sind im Falle des Teilr&uuml;cktritts bereits erbrachte Teilleistungen<br />\r\nvertragsgem&auml;&szlig; abzurechnen und zu bezahlen.<br />\r\n<br />\r\n<br />\r\n&sect; 8 Gew&auml;hrleistung&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;<br />\r\n<br />\r\nGew&auml;hrleistung gegen&uuml;ber Verbrauchern <br />\r\na) Fensterdichtungen.org tr&auml;gt Gew&auml;hr daf&uuml;r, dass der Kaufgegenstand bei &Uuml;bergabe mangelfrei ist. Zeigt sich innerhalb<br />\r\nvon sechs Monaten seit &Uuml;bergabe des Kaufgegenstands ein Sachmangel, so wird vermutet, dass dieser bereits bei &Uuml;bergabe<br />\r\nmangelhaft war, es sei denn, diese Vermutung ist mit der Art des Kaufgegenstands oder des Mangels unvereinbar. Zeigt<br />\r\nsich der Sachmangel erst nach Ablauf von sechs Monaten, muss der K&auml;ufer beweisen, dass der Sachmangel bereits bei<br />\r\n&Uuml;bergabe des Kaufgegenstands vorlag. <br />\r\nb) Ist der Kaufgegenstand bei &Uuml;bergabe mangelhaft, hat der K&auml;ufer die Wahl, ob die Nacherf&uuml;llung durch Nachbesserung<br />\r\noder Ersatzlieferung erfolgen soll. Fensterdichtungen.org ist berechtigt, die Art der gew&auml;hlten Nacherf&uuml;llung zu verweigern, wenn sie nur mit unverh&auml;ltnism&auml;&szlig;igen Kosten m&ouml;glich ist und die andere Art der Nacherf&uuml;llung ohne erhebliche Nachteile f&uuml;r den K&auml;ufer bleibt. <br />\r\nc) Schl&auml;gt die Nacherf&uuml;llung fehl, kann der K&auml;ufer grunds&auml;tzlich nach seiner Wahl Herabsetzung des Kaufpreises (Minderung)<br />\r\noder R&uuml;ckg&auml;ngigmachung des Vertrags (R&uuml;cktritt) sowie Schadensersatz verlangen. Bei nur geringf&uuml;gigen M&auml;ngeln steht dem<br />\r\nK&auml;ufer kein R&uuml;cktrittsrecht zu.<br />\r\n<br />\r\nGew&auml;hrleistung gegen&uuml;ber Unternehmern <br />\r\na) Ist der Kauf f&uuml;r fensterdichtungen.org und den K&auml;ufer ein Handelsgesch&auml;ft, hat der K&auml;ufer die gelieferte Ware<br />\r\nunverz&uuml;glich auf Qualit&auml;ts- und Mengenabweichung zu untersuchen und Fensterdichtungen.org erkennbare M&auml;ngel innerhalb<br />\r\neiner Frist von einer Woche ab Empfang der Ware schriftlich anzuzeigen; andernfalls ist die Geltendmachung des<br />\r\nGew&auml;hrleistungsanspruchs ausgeschlossen. Verdeckte M&auml;ngel sind fensterdichtungen.org innerhalb einer Frist von<br />\r\neiner Woche ab Entdeckung schriftlich anzuzeigen.<br />\r\nZur Fristwahrung gen&uuml;gt die rechtzeitige Absendung. Den K&auml;ufer trifftin diesem Fall die volle Beweislast f&uuml;r<br />\r\ns&auml;mtliche Anspruchsvoraussetzungen, insbesondere f&uuml;r den Mangel selbst, f&uuml;r denZeitpunkt der Feststellung des Mangels<br />\r\nund f&uuml;r die Rechtzeitigkeit der M&auml;ngelr&uuml;ge. <br />\r\n<br />\r\nb) Bei M&auml;ngeln leistet&nbsp; www. fensterdichtungen.org nach eigener Wahl Gew&auml;hr durch Nachbesserung oder Ersatzlieferung.<br />\r\nDie Anspr&uuml;che des K&auml;ufers wegen M&auml;ngeln verj&auml;hren in einem Jahr.<br />\r\nLiefert www.fensterdichtungen.org zum Zwecke der Nacherf&uuml;llung einen mangelfreien Kaufgegenstand, kann<br />\r\nfensterdichtungen.org vom K&auml;ufer R&uuml;ckgew&auml;hr des mangelhaften Kaufgegenstands verlangen.<br />\r\nSch&auml;den, die durch Unsachgem&auml;&szlig;e oder vertragswidrige Ma&szlig;nahmen des K&auml;ufers bei Aufstellung, Anschluss, Bedienung<br />\r\noder Lagerung hervorgerufen werden, begr&uuml;nden keinen Anspruch gegen fensterdichtungen.org.<br />\r\n<br />\r\n<br />\r\n&sect; 9 Haftungsbeschr&auml;nkung<br />\r\n<br />\r\nF&uuml;r andere als durch Verletzung von Leben, K&ouml;rper und Gesundheit entstehende Sch&auml;den haftet fensterdichtungen.org nur,<br />\r\nsoweit diese Sch&auml;den auf vors&auml;tzlichem oder grob fahrl&auml;ssigem Handeln oder auf schuldhafter Verletzung einer<br />\r\nwesentlichen Vertragspflicht durch fensterdichtungen.org oder deren Erf&uuml;llungsgehilfen beruhen. Vertragswesentlich <br />\r\nist eine Pflicht, deren Erf&uuml;llung die ordnungsgem&auml;&szlig;e Durchf&uuml;hrung des Vertrages &uuml;berhaupt erst erm&ouml;glicht und auf deren<br />\r\nEinhaltung der K&auml;ufer regelm&auml;&szlig;ig vertrauen darf. Eine dar&uuml;ber hinausgehende Haftung auf Schadensersatz ist ausgeschlossen. Anspr&uuml;che aus einer von fensterdichtungen.org gegebenen Garantie f&uuml;r die Beschaffenheit des Kaufgegenstands und dem Produkthaftungsgesetz bleiben hiervon unber&uuml;hrt.<br />\r\nNach dem jetzigen Stand der Technik kann die Datenkommunikation &uuml;ber das Internet nicht fehlerfrei und/oder jederzeit<br />\r\nverf&uuml;gbar gew&auml;hrleistet werden. Wir haften daher nicht f&uuml;r die jederzeitige Verf&uuml;gbarkeit unseres Internetshops.<br />\r\n<br />\r\n<br />\r\n&sect; 10 Rechtswahl, Gerichtsstand<br />\r\n<br />\r\nAlle Streitigkeiten aus diesem Rechtsverh&auml;ltnis unterliegen dem Recht der Bunderrepublick Deutschland Bei Verbrauchern<br />\r\ngilt diese Rechtswahl nur insoweit, als nicht der gew&auml;hrte Schutz durch zwingende Bestimmungen des Rechts des Staates,<br />\r\nin dem der Verbraucher seinen gew&ouml;hnlichen Aufenthalt hat, entzogen wird. Die Geltung von UN-Kaufrecht ist <br />\r\nausgeschlossen.<br />\r\n<br />\r\nIst der K&auml;ufer Kaufmann, juristische Person des &ouml;ffentlichen Rechts oder &ouml;ffentlich-rechtliches Sonderverm&ouml;gen ist<br />\r\nausschlie&szlig;licher Gerichtsstand f&uuml;r alle Streitigkeiten aus diesem Vertrag der Gesch&auml;ftssitz von www. fensterdichtungen.org<br />\r\nDasselbe gilt, wenn der K&auml;ufer keinen allgemeinen Gerichtsstand in der BRD hat oder der Wohnsitz oder gew&ouml;hnlichen Aufenthalt<br />\r\nim Zeitpunkt der Klageerhebung nicht bekannt sind.<br />\r\n<br />\r\n<br />\r\n<br />\r\n&sect; 11 Salvatorische Klausel<br />\r\n<br />\r\nSollte eine Bestimmung dieser AGB ung&uuml;ltig oder undurchsetzbar sein oder werden, so bleiben die &uuml;brigen Bestimmungen<br />\r\n&nbsp;dieser AGB hiervon unber&uuml;hrt, es sei denn, dass durch den Wegfall einzelner Klauseln eine Vertragspartei so unzumutbar<br />\r\n&nbsp;benachteiligt w&uuml;rde, dass ihr ein Festhalten am Vertrag nicht mehr zugemutet werden kann. <br />\r\n<br />\r\nEnde der Allgemeinen Gesch&auml;ftsbedingungen&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;<br />\r\n</span></span><strong><br />\r\n</strong></p>','0','1','','1','3','0','','','');
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('9','0','0','','2','Impressum','Impressum','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: small;\"><br />\r\n</span></span></p>\r\n<table cellspacing=\"0\" cellpadding=\"0\" width=\"100%\" border=\"0\">\r\n    <tbody>\r\n        <tr style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: 11.1111116409302px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18.3333339691162px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\">\r\n            <td style=\"font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: 11px; line-height: 1.5;\" class=\"main\"><span style=\"font-family: Verdana;\"><span style=\"font-size: small;\"><span style=\"font-weight: bold;\">www.fensterdichtungen.org Shop<br />\r\n            <br />\r\n            Stareno GmbH<br />\r\n            Hohldrift 17<br />\r\n            D 33181 Bad W&uuml;nnenberg<br />\r\n            <br />\r\n            Tel. 02957 - 9849318<br />\r\n            Fax 02957 1591<br />\r\n            Mail info@fensterdichtungen.org<br />\r\n            <br />\r\n            Umsatzsteuernummer DE 183 387 281<br />\r\n            HRB 3819 Amtsgericht Paderborn<br />\r\n            Gesch&auml;tsf&uuml;hrer Hardy Zich<br />\r\n            <br />\r\n            Kontoverbindung<br />\r\n            BLZ&nbsp; &nbsp; &nbsp; 47260121<br />\r\n            Ko. Nr. 419351600<br />\r\n            Volksbank Paderborn<br />\r\n            <br />\r\n            IBAN DE32472601210419351600<br />\r\n            BIC DGPBDE3MXXX<br />\r\n            </span></span></span><span style=\"font-weight: bold;\"><br />\r\n            <br />\r\n            <br />\r\n            </span>\r\n            <table cellspacing=\"0\" cellpadding=\"0\" width=\"571\" border=\"0\" style=\"width: 428.25pt; margin-left: 9.85pt; border-collapse: collapse;\" class=\"MsoNormalTable\">\r\n                <tbody>\r\n                    <tr>\r\n                        <td style=\"border-style: none solid; border-left-color: rgb(218, 220, 220); border-left-width: 1pt; border-right-color: rgb(218, 220, 220); border-right-width: 2.25pt; padding: 0cm 8.75pt; background: white;\">&nbsp;</td>\r\n                    </tr>\r\n                    <tr>\r\n                        <td style=\"border-style: none solid; border-left-color: rgb(218, 220, 220); border-left-width: 1pt; border-right-color: rgb(218, 220, 220); border-right-width: 2.25pt; padding: 0cm 8.75pt; background: white;\">&nbsp;</td>\r\n                    </tr>\r\n                </tbody>\r\n            </table>\r\n            <span style=\"font-weight: bold;\"><br />\r\n            </span>Haftungshinweis:<br />\r\n            Trotz sorgf&auml;ltiger inhaltlicher Kontrolle &uuml;bernehmen wir keine Haftung f&uuml;r die Inhalte externer Links. F&uuml;r den Inhalt der verlinkten Seiten sind ausschlie&szlig;lich deren Betreiber verantwortlich.<span class=\"Apple-converted-space\">&nbsp;</span><br />\r\n            Schutzverletzung, Namensrecht:<br />\r\n            Im Falle von Namensrecht-/Domainstreitigkeiten bzw. Abmahnungen gegen geltendes Gesetz bitten wir Sie, zur Vermeidung unn&ouml;tiger Rechtsstreite und Kosten, uns bereits im Vorfeld zu kontaktieren. Die Kostennote einer anwaltlichen Abmahnung ohne vorhergehende Kontaktaufnahme wird im Sinne der Schadensminderungspflicht als unbegr&uuml;ndet zur&uuml;ckgewiesen. Unberechtigte Abmahnungen und/ oder Unterlassungserkl&auml;rungen werden direkt mit einer negativen Feststellungsklage beantwortet.<span class=\"Apple-converted-space\">&nbsp;</span><br />\r\n            <span style=\"font-weight: bold;\"><br />\r\n            </span></td>\r\n        </tr>\r\n        <tr style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: 11.1111116409302px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18.3333339691162px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\">\r\n        </tr>\r\n    </tbody>\r\n</table>\r\n<p>&nbsp;</p>','0','1','','1','4','0','','','');
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('10','0','0','','2','Index','Herzlich willkommen,','<p style=\"text-align: left;\"><span style=\"font-size: medium;\">S<img width=\"360\" height=\"333\" align=\"right\" src=\"/images/hardy/einzelindexbild%20(2).jpg\" alt=\"\" />ie m&ouml;chten Ihre Fensterdichtung erneuern?</span></p>\r\n<p style=\"text-align: left;\"><span style=\"font-size: medium;\"> Fensterdichtungen f&uuml;r Kunststoff bzw.Holzfenster, oder auch Haust&uuml;rdichtungen sind seit 25 Jahren Jahren unser Thema.</span></p>\r\n<p style=\"text-align: left;\"><span style=\"font-size: medium;\">Auf Grund dieser Erfahrung, haben wir unsere eigene Spezialdichtung aus Silikon f&uuml;r Kunststofffenster entwickelt.<br />\r\nAnwendung finden diese Fensterdichtungen beim Nachr&uuml;sten von &auml;lteren Fenstersytemen, wo zum Beispiel der Hersteller nicht mehr bekannt ist, oder die Originale Fensterdichtung nicht mehr ausreichend abdichten kann</span></p>\r\n<p style=\"text-align: left;\"><span style=\"font-size: medium;\">Oft haben sich &uuml;ber die Jahre die Fenster verzogen bzw. lassen sich die Beschl&auml;ge nicht mehr optimal einstellen, so dass die Funktion des Fensters v&ouml;llig gew&auml;hrleistet ist.<br />\r\n<br />\r\nSelbstverst&auml;dlich steht Ihnen auch bei uns eine Vielzahl anderer Fenster und T&uuml;rdichtungen f&uuml;r Holz und Kunststoffelemente in unserem Shop zur Verf&uuml;gung.<br />\r\n<br />\r\nWeiter Fensterdichtungen aus unserem Lieferprogramm von weit &uuml;ber 4000 Dichtungen aller Art, finden sie in unserem Dichtungskatalog. Hierzu sollten sie auf das Bild&nbsp; &quot; <a target=\"_blank\" href=\"Dichtungskatalog.pdf\" title=\"Katalog Fensterdichtungen\"><font color=\"#0000ff\">Dichtungskatalog ansehen</font></a> &quot; klicken, hier wird dann der Katalog als <a target=\"_blank\" href=\"Dichtungskatalog.pdf\" title=\"Katalog Fensterdichtungen\"><font color=\"#0000ff\">PDF</font></a> - Datei ge&ouml;ffnet.<br />\r\n<br />\r\n<strong>Machen sie sich schlau !</strong><br />\r\n.<br />\r\nDetails zur Pflege von Fensterdichtungen und einiges mehr &uuml;ber Dichtungen, k&ouml;nnen sie links in der Leiste Informationen entnehmen. Dort erhalten sie auch Hinweise zur Dichtungsmontage, wie sie Ihre Fensterdichtung selbst bestimmen k&ouml;nnen und vieles mehr.<br />\r\n<br />\r\nSollten sie Fragen zu Fensterdichtungen haben, dann erreichen sie uns telefonisch unter folgender Rufnummer 02957 - 9849318 oder sie senden uns eine Mail unter: info@fensterdichtungen.org&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <br />\r\n<br />\r\nWenn es bei der Bestimmung Ihrer Fensterdichtung schnell und unkompliziert sein soll, dann k&ouml;nnen uns auch ein Foto vom Querschnitt Ihrer Fensterdichtung per Mail senden, oder sie schicken uns ein kleines St&uuml;ck von ca. 1 cm Ihrer ben&ouml;tigten Fensterdichtung mit der Post. die Anschrifrt finden sie im Impreeum. &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <br />\r\n</span><span style=\"font-family: Verdana;\"><span style=\"font-size: small;\"><br />\r\n</span></span></p>','0','1','','1','5','0','Fensterdichtungen, Fensterdichtung Holzfenster,Türdichtung','Fensterdichtungen, Fensterdichtungen kaufen, Fensterdichungen Holzfenster, Fensterdichtungen erneuern, Fensterdichtung austauschen,Türdichtung','Fensterdichtungen austauschen, Fensterdichtung austauschen, Fensterdichtung erneuern, Fensterdichtungen erneuern');
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('11','0','0','','1','Coupons','Coupons FAQ','<table cellSpacing=\"0\" cellPadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td class=\"main\"><strong>Buy Gift Vouchers/Coupons </strong></td></tr>\r\n<tr>\r\n<td class=\"main\">If the shop provided gift vouchers or coupons, You can buy them alike all other products. As soon as You have bought and payed the coupon, the shop system will activate Your coupon. You will then see the coupon amount in Your shopping cart. Then You can send the coupon via e-mail by clicking the link \"Send Coupon\". </td></tr></tbody></table>\r\n<table cellSpacing=\"0\" cellPadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td class=\"main\"><strong>How to dispatch Coupons </strong></td></tr>\r\n<tr>\r\n<td class=\"main\">To dispatch a coupon, please click the link \"Send Coupon\" in Your shopping cart. To send the coupon to the correct person, we need the following details: Surname and realname of the recipient and a valid e-mail adress of the recipient, and the desired coupon amount (You can also use only parts of Your balance). Please provide also a short message for the recipient. Please check those information again before You click the \"Send Coupon\" button. You can change all information at any time before clicking the \"Send Coupon\" button. </td></tr></tbody></table>\r\n<table cellSpacing=\"0\" cellPadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td class=\"main\"><strong>How to use Coupons to buy products. </strong></td></tr>\r\n<tr>\r\n<td class=\"main\">As soon as You have a balance, You can use it to pay for Your orders. During the checkout process, You can redeem Your coupon. In case Your balance is less than the value of goods You ordered, You would have to choose Your preferred method of payment for the difference amount. In case Your balance is more than the value of goods You ordered, the remaining amount of Your balance will be saved for Your next order. </td></tr></tbody></table>\r\n<table cellSpacing=\"0\" cellPadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td class=\"main\"><strong>How to redeem Coupons. </strong></td></tr>\r\n<tr>\r\n<td class=\"main\">In case You have received a coupun via e-mail, You can: <br />1. Click on the link provided in the e-mail. If You do not have an account in this shop already, please create a personal account. <br />2. After having added a product to Your shopping cart, You can enter Your coupon code.</td></tr></tbody></table>\r\n<table cellSpacing=\"0\" cellPadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td class=\"main\"><strong>Problems?</strong></td></tr>\r\n<tr>\r\n<td class=\"main\">If You have trouble or problems in using Your coupons, please check back with us via our e-mail: you@yourdomain.com. Please describe the encountered problem as detailed as possible! We need the following information to process Your request quickly: Your user id, the coupon code, error messages the shop system returned to You, and the name of the web browser You are using (e.g. \"Internet Explorer 6\" or \"Firefox 1.5\"). </td></tr></tbody></table>','0','1','','0','6','1','','','');
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('12','0','0','','2','Gutscheine','Gutscheine - Fragen und Antworten','<table cellSpacing=\"0\" cellPadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td class=\"main\"><strong>Gutscheine kaufen </strong></td></tr>\r\n<tr>\r\n<td class=\"main\">Gutscheine k&ouml;nnen, falls sie im Shop angeboten werden, wie normale Artikel gekauft werden. Sobald Sie einen Gutschein gekauft haben und dieser nach erfolgreicher Zahlung freigeschaltet wurde, erscheint der Betrag unter Ihrem Warenkorb. Nun k�nnen Sie �ber den Link \" Gutschein versenden \" den gew�nschten Betrag per E-Mail versenden.</td></tr></tbody></table>\r\n<table cellSpacing=\"0\" cellPadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td class=\"main\"><strong>Wie man Gutscheine versendet</strong></td></tr>\r\n<tr>\r\n<td class=\"main\">Um einen Gutschein zu versenden, klicken Sie bitte auf den Link \"Gutschein versenden\" in Ihrem Einkaufskorb. Um einen Gutschein zu versenden, ben�tigen wir folgende Angaben von Ihnen: Vor- und Nachname des Empf�ngers. Eine g�ltige E-Mail Adresse des Empf�ngers. Den gew�nschten Betrag (Sie k�nnen auch Teilbetr�ge Ihres Guthabens versenden). Eine kurze Nachricht an den Empf�nger. Bitte �berpr�fen Sie Ihre Angaben noch einmal vor dem Versenden. Sie haben vor dem Versenden jederzeit die M�glichkeit Ihre Angaben zu korrigieren.</td></tr></tbody></table>\r\n<table cellSpacing=\"0\" cellPadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td class=\"main\"><strong>Mit Gutscheinen einkaufen.</strong></td></tr>\r\n<tr>\r\n<td class=\"main\">Sobald Sie �ber ein Guthaben verf�gen, k�nnen Sie dieses zum Bezahlen Ihrer Bestellung verwenden. W�hrend des Bestellvorganges haben Sie die M�glichkeit Ihr Guthaben einzul�sen. Falls das Guthaben unter dem Warenwert liegt m�ssen Sie Ihre bevorzugte Zahlungsweise f�r den Differenzbetrag w�hlen. �bersteigt Ihr Guthaben den Warenwert, steht Ihnen das Restguthaben selbstverst�ndlich f�r Ihre n�chste Bestellung zur Verf�gung.</td></tr></tbody></table>\r\n<table cellSpacing=\"0\" cellPadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td class=\"main\"><strong>Gutscheine verbuchen. </strong></td></tr>\r\n<tr>\r\n<td class=\"main\">Wenn Sie einen Gutschein per E-Mail erhalten haben, k�nnen Sie den Betrag wie folgt verbuchen: <br />1. Klicken Sie auf den in der E-Mail angegebenen Link. Falls Sie noch nicht �ber ein pers�nliches Kundenkonto verf�gen, haben Sie die M�glichkeit ein Konto zu er�ffnen. <br />2. Nachdem Sie ein Produkt in den Warenkorb gelegt haben, k�nnen Sie dort Ihren Gutscheincode eingeben.</td></tr></tbody></table>\r\n<table cellSpacing=\"0\" cellPadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td class=\"main\"><strong>Falls es zu Problemen kommen sollte:</strong></td></tr>\r\n<tr>\r\n<td class=\"main\">Falls es wider Erwarten zu Problemen mit einem Gutschein kommen sollte, kontaktieren Sie uns bitte per E-Mail: you@yourdomain.com. Bitte beschreiben Sie m�glichst genau das Problem, wichtige Angaben sind unter anderem: Ihre Kundennummer, der Gutscheincode, Fehlermeldungen des Systems sowie der von Ihnen benutzte Browser (z.B. \"Internet Explorer 6\" oder \"Firefox 1.5\"). </td></tr></tbody></table>','0','1','','0','6','1','','','');
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('13','0','0','','2','Kontakt - Mail senden','Fragen ? Hier können sie uns eine Mail senden','<p>Ihre Kontaktinformationen</p>','0','1','','1','7','0','','','');
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('14','0','0','','1','Contact','Contact','Please enter your contact information.','0','1','','1','7','0','','','');
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('15','0','0','','1','Sitemap','','','0','0','sitemap.php','1','8','0','','','');
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('16','0','0','','2','Sitemap','','','0','0','sitemap.php','0','8','0','','','');
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('17','0','0','','1','Right of revocation','Right of revocation','<p><strong>Right of revocation<br /></strong><br />Add your right of revocation here.</p>','0','1','','1','9','0','','','');
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('18','0','0','','2','Widerrufsrecht','','<p><span style=\"font-family: Verdana;\"><br />\r\n</span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"> </span></span></p>\r\n<p><span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">Widerrufsrecht -</span><br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">Widerrufsbelehrung f&uuml;r Verbraucher</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">Sofern es sich bei dem Kunden um einen Verbraucher handelt (Gem&auml;&szlig; &sect; 13 BGB ist Verbraucher jede nat&uuml;rliche Person, </span><span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">die ein Rechtsgesch&auml;ft zu Zwecken abschlie&szlig;t, die &uuml;berwiegend weder ihrer gewerblichen noch ihrer selbst&auml;ndigen</span><span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">beruflichen T&auml;tigkeit zugerechnet werden k&ouml;nnen.), gilt f&uuml;r diesen folgendes Widerrufsrecht</span><br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">Widerrufsrecht</span><br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">Sie haben das Recht, binnen vierzehn Tagen ohne Angabe von Gr&uuml;nden diesen Vertrag zu widerrufen.</span><br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">Die Widerrufsfrist betr&auml;gt vierzehn Tage ab dem Tag, an dem Sie oder ein von Ihnen benannter Dritter, der nicht</span><span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\"> der Bef&ouml;rderer ist, die letzte Ware in Besitz genommen haben bzw. hat.</span><br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">Um Ihr Widerrufsrecht auszu&uuml;ben, m&uuml;ssen Sie uns Stareno GmbH&nbsp; Hohldrift 17&nbsp; 33181 Bad W&uuml;nnenberg,</span><span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">Tel: +49(0)2957 /&nbsp; 9849318 Fax: +49 (0)2957 / 1591</span></span></span><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\"> E-Mail: info@fensterdichtungen.org</span></span></span><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">mittels einer eindeutigen </span><span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">Erkl&auml;rung (z.B. ein mit der Postversandter Brief, Telefax oder E-Mail) &uuml;ber Ihren Entschluss, diesen Vertrag zu</span><span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\"> widerrufen, informieren. Sie k&ouml;nnen daf&uuml;r das beigef&uuml;gte Muster-Widerrufsformular verwenden, das jedoch nicht</span><br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">vorgeschrieben ist.</span></span></span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">Zur Wahrung der Widerrufsfrist reicht es aus, dass Sie die Mitteilung &uuml;ber die Aus&uuml;bung des Widerrufsrechts vor</span><span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\"> Ablauf der Widerrufsfrist absenden.</span><br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n</span></span><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">Folgen des Widerrufs</span></span></span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">Wenn Sie diesen Vertrag widerrufen, haben wir Ihnen alle Zahlungen, die wir von Ihnen erhalten haben, einschlie&szlig;lich</span> <span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">der Lieferkosten (mit Ausnahme der zus&auml;tzlichen Kosten, die sich daraus ergeben, dass Sie eine andere Art der Lieferung</span> <span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">als die von uns angebotene, g&uuml;nstigste Standardlieferung gew&auml;hlt haben), unverz&uuml;glich und sp&auml;testens binnen vierzehn</span><span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\"> Tagen ab dem Tag zur&uuml;ckzuzahlen, an dem die Mitteilung &uuml;ber Ihren Widerruf dieses Vertrags bei uns eingegangen ist.</span></span></span></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">F&uuml;r diese R&uuml;ckzahlung verwenden wir dasselbe Zahlungsmittel, das Sie bei der urspr&uuml;nglichen Transaktion eingesetzt</span><span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\"> haben, es sei denn, mit Ihnen wurde ausdr&uuml;cklich etwas anderes vereinbart; in keinem Fall werden Ihnen wegen dieser</span><span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\"> R&uuml;ckzahlung Entgelte berechnet. Wir k&ouml;nnen die R&uuml;ckzahlung verweigern, bis wir die Waren wieder zur&uuml;ckerhalten haben<span class=\"Apple-converted-space\">&nbsp;</span></span><span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\"> oder bis Sie den Nachweis erbracht haben, dass Sie die Waren zur&uuml;ckgesandt haben, je nachdem, welches der fr&uuml;here<span class=\"Apple-converted-space\">&nbsp;&nbsp;</span></span><span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">Zeitpunkt ist.</span></span></span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">Sie haben die Waren unverz&uuml;glich und in jedem Fall sp&auml;testens binnen vierzehn Tagen ab dem Tag, an dem Sie uns &uuml;ber</span></span></span> <span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">den Widerruf dieses Vertrags unterrichten, an uns zur&uuml;ckzusenden oder zu &uuml;bergeben. Die Frist ist gewahrt, wenn Sie</span><span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\"> die Waren vor Ablauf der Frist von vierzehn Tagen absenden.</span></span></span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">Wir tragen die Kosten der R&uuml;cksendung der Waren.</span><span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\"> Sie m&uuml;ssen f&uuml;r einen etwaigen Wertverlust der Waren nur aufkommen, wenn dieser Wertverlust auf einen zur Pr&uuml;fung der</span><span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\"> Beschaffenheit, Eigenschaften und Funktionsweise der Waren nicht notwendigen Umgang mit ihnen zur&uuml;ckzuf&uuml;hren ist.</span></span></span></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">Ausschluss des Widerrufsrechts<span class=\"Apple-converted-space\">&nbsp;</span></span><br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n</span></span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">Das Widerrufsrecht besteht gem&auml;&szlig; &sect; 312g Absatz 2 Nr. 1 BGB nicht bei Vertr&auml;gen zur Lieferung von Waren, die nicht</span></span></span> <span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">vorgefertigt sind und f&uuml;r deren Herstellung eine individuelle Auswahl oder Bestimmung durch den Verbraucher ma&szlig;geblich</span> <span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">ist oder die eindeutig auf die pers&ouml;nlichen Bed&uuml;rfnisse des Verbrauchers zugeschnitten sind.</span><br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">Wenn Sie den Vertrag widerrufen wollen, dann f&uuml;llen Sie bitte dieses Formular aus und senden Sie es zur&uuml;ck.)</span><br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">Stareno GmbH,</span><br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">Hohldrift 17</span><br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">33181 Bad W&uuml;nnenberg</span><br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">Tel. 02957 &ndash; 9849318</span><br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">Fax 02957 &ndash; 1591</span><br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; display: inline ! important; float: none; background-color: rgb(255, 255, 255);\">Mail:&nbsp; info@fensterdichtungen.org</span></span></span></p>','0','1','','1','9','0','','','');
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('19','0','0','','1','Revocation form','Revocation form','<p><strong>Revocation form<br /></strong><br />Add your revocation form here.</p>','0','1','','1','10','0','','','');
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('20','0','0','','2','Muster-Widerrufsformular','Muster-Widerrufsformular','<p><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\"><strong>Muster-Widerrufsformular<br />\r\n</strong><br />\r\n<span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; float: none; display: inline !important; background-color: rgb(255, 255, 255);\">Hiermit widerrufe(n) ich/wir (*) den von mir/uns (*) abgeschlossenen Vertrag &uuml;ber den Kauf der folgenden<span class=\"Apple-converted-space\">&nbsp;</span></span><br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; float: none; display: inline !important; background-color: rgb(255, 255, 255);\">Waren (*) / die Erbringung der folgenden Dienstleistung (*)</span><br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; float: none; display: inline !important; background-color: rgb(255, 255, 255);\">_______________________________________________</span><br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; float: none; display: inline !important; background-color: rgb(255, 255, 255);\">_______________________________________________</span><br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; float: none; display: inline !important; background-color: rgb(255, 255, 255);\">Bestellt am ___________________ (*)/erhalten am _______________________(*)</span><br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; float: none; display: inline !important; background-color: rgb(255, 255, 255);\">Name des/der Verbraucher(s) ______________________________________</span><br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; float: none; display: inline !important; background-color: rgb(255, 255, 255);\">Anschrift des/der Verbraucher(s)</span><br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; float: none; display: inline !important; background-color: rgb(255, 255, 255);\">_________________________________</span><br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; float: none; display: inline !important; background-color: rgb(255, 255, 255);\">_________________________________</span><br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; float: none; display: inline !important; background-color: rgb(255, 255, 255);\">_________________________________</span><br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n</span></span><span style=\"font-family: Verdana;\"><span style=\"font-size: small;\"> <br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<span style=\"font-size: medium;\"><span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; float: none; display: inline !important; background-color: rgb(255, 255, 255);\">_________&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; _____________________________________________________</span><br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; float: none; display: inline !important; background-color: rgb(255, 255, 255);\">Datum&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Unterschrift des/der Verbraucher(s) (nur bei Mitteilung auf Papier)</span><br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; float: none; display: inline !important; background-color: rgb(255, 255, 255);\">_____________________________________________________________________________________</span><br style=\"color: rgb(0, 0, 0); font-family: Tahoma, Geneva, Kalimati, sans-serif; font-size: small; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6666679382324px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255);\" />\r\n<span style=\"color: rgb(0, 0, 0); font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 21.6667px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; float: none; display: inline !important; background-color: rgb(255, 255, 255);\">(*) Unzutreffendes streichen</span></span></span></span></p>','0','1','','1','10','0','','','');
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('21','0','0','','1','Shipping time','Shipping time','<p><strong>Shipping time<br /></strong><br />Add your shipping time informations here.</p>','0','1','','1','11','0','','','');
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('22','0','0','','2','Lieferzeit','Lieferzeit','<p><span style=\"font-size: medium;\"><strong>Lieferzeit<br />\r\n</strong></span><br />\r\n<span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Nach Zahlungseingang wird die Ware innerhalb 1 - 4 Werktage versendet. Ist die Ware nicht verf&uuml;gbar,</span></span><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">wird der K&auml;ufer umgehend bz&uuml;glich der neuen Lieferzeit informiert.</span></span></p>','0','1','','1','11','0','','','');
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('23','0','0','','2','Dichtungsmontage','','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><strong>Dichtungsmontage - Eigenschaften und Verarbeitung</strong><br />\r\n<br />\r\nEIGENSCHAFTEN unserer Fensterdichtungen</span></span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><br />\r\n- sehr gut alterungs- witterungs- UV - und Ozonbest&auml;ndig<br />\r\n- sehr hohe Flexibilit&auml;t, daher ausgezeichnetes R&uuml;ckstellverm&ouml;gen&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <br />\r\n&nbsp; sowie kaum Schlie&szlig;druck&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <br />\r\n- h&ouml;here Stabilit&auml;t durch die Verbindung von Dichtk&ouml;rper mit Nutabdecklippe <br />\r\n- Silikonkautschuk reagiert neutral,ist untrennbar und nicht leitend<br />\r\n- die Silikondichtungen eignen sich f&uuml;r Temperaturen zwischen - 50 <br />\r\n&nbsp; &nbsp;und + 200 Grad<br />\r\n<br />\r\nAustausch der Fensterdichtungen <br />\r\n<br />\r\nVor dem Einbau der neuen Fensterdichtungen die vorhandene Fensterdichtung restlos<br />\r\nentfernen.Danach die Menge der ben&ouml;tigten Fensterdichtungen f&uuml;r das Fenster messen<br />\r\nund ca. 1cm l&auml;nger als ben&ouml;tigt&nbsp; lassen mit einer Handels&uuml;blichen Haushaltsschere <br />\r\nabschneiden. Der Grund hierf&uuml;r ist der, dass die Fensterdichtungen aufgrund der <br />\r\nWitterungseinfl&uuml;sse von kalt und warm in der Nut wandern.<br />\r\n<br />\r\nFangen sie oben in der Mitte mit der Montage der neuen Dichtung an. Wenn sie am <br />\r\nAusgangspunkt wiederangekommen sind, schneiden sie 1 cm mehr ab. Diesen cm vermitteln<br />\r\nsie auf das gesamte Fenster.Wird die Dichtung hierbei zu wellig, dann k&ouml;nnen sie noch <br />\r\n5 mm der Dichtung abschneiden.<br />\r\nDies w&auml;re ein Zeichen, dass die Dichtung gut verlegt ist. Eventuell kann man wenn <br />\r\nnotwendig, den Sto&szlig; und die Ecken noch zus&auml;tzlich verkleben.<br />\r\n<br />\r\nUm die Fensterdichtung in den Eckbereichen besser umlegen zu k&ouml;nnen, ist es ratsam <br />\r\neinen Keil von ca.10 - 15 mm der Breite aus der Dichtung zu schneiden. Bitte nur den <br />\r\nDichtungsfu&szlig; ( Dreieck )und nicht in die Dichtfl&auml;che schneiden.<br />\r\n<br />\r\nSie haben aber auch die M&ouml;glichkeit, die Dichtungen einzeln zu verarbeiten. Hierzu <br />\r\nwerden vier Dichtungprofile ben&ouml;tigt, bestehend aus zwei waagerechten und zwei<br />\r\nsenkrechten Teilen. Die Eckbereiche k&ouml;nnen stumpf ( voreinander ) oder auf Gehrung <br />\r\ngeschnitten werden. Welche Variante sie w&auml;hlen, sollten sie selbst vor Ort entscheiden.<br />\r\n&nbsp;<br />\r\nZudem sollte unbedingt darauf geachtet werden, dass die Dichtung bei der Montage nicht<br />\r\nlanggezogen wird, da diese sich anschlie&szlig;end wieder zusammenzieht und dadurch ein Spalt<br />\r\nan der Schnittstelle entstehen k&ouml;nnte.<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <br />\r\nIst die neue Dichtung nun umlaufend eingelegt, wird die neue Dichtung in der Nut mit dem<br />\r\nDaumen vermittelt und umlaufend auf festen Sitz &uuml;berpr&uuml;ft. Die Dichtung ist nicht <br />\r\nverschweissbar,kann aber mit unserem im Shop angebotenem Dichtungskleber verklebt werden.<br />\r\nUm das Einziehen der Dichtungen zu erleichtern, kann der Dichtungsfu&szlig; oder die Dichtungs-<br />\r\nnut d&uuml;nn mit handels&uuml;blichem Sp&uuml;lmittel eingerieben werden. Bitte den Beschlag und das<br />\r\nEck und Scherenlager am Fenster mit Silikonspray oder WD-40 einspr&uuml;hen. Ihr Fenster wird<br />\r\nes Ihnen danken, es geht dann wieder wie geschmiert! Nicht vergessen,es ist ganz wichtig!! <br />\r\n<br />\r\nBei R&uuml;ckfragen stehen wir Ihnen gern unter der Telefon Nr.02957 &ndash; 9849318 zur Verf&uuml;gung</span></span></p>','0','0','','1','12','1','Fensterdichtung, Fensterdichtungen für Kunststoffenster,Fensterdichtung austaueschen, Fensterdichtung erneuern. Fensterdichtung Holzfenster','fensterdichtung erneuern, Fensterdichtungen auswechseln','Fensterdichtung erneuern, Fensterdichtungen, Fensterdichtung auswechseln,');
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('24','0','0','','2','Drei Wege zur neuen Fensterdichtung','','<p>&nbsp;</p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"> </span></span><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><strong>Drei Wege zu ihrer neuen Fensterdichtung - Es geht um Millimeter <br />\r\n</strong><br />\r\nWarum ist es eigentlich so schwer, passende Fensterdichtungen f&uuml;r Kunststofffenster zu finden?&nbsp; <br />\r\n<br />\r\nKunststofffenster haben in Deutschland einen Marktanteil von ca. 65 %. Diese Fensterprofile werden seit den 60 er Jahren von ca. 15 verschiedenen Systemanbietern wie z.B. Sch&uuml;co, Rehau oder Veka hergestellt. Diese Firmen verkaufen ihre Profile an so genannte Verarbeiter ( Tischler oder Fensterbauer ) und daraus werden dann die Fenster hergestellt.<br />\r\n<br />\r\nJeder Hersteller verarbeitet sein eigenes System und damit auch verschiedene Profile, mit jeweils anderen Dichtungen.Durch st&auml;ndige Weiterentwicklung entstehen somit sehr viele verschiedene Fensterdichtungen. Daher ist es sehr schwierig, die passenden Dichtungen f&uuml;r &auml;ltere Fenster zu bekommen. Ein neues Fenster k&ouml;nnen sie sofort bekommen, aber bei einer neuen Dichtung wird es sehr schwierig.&nbsp;&nbsp;&nbsp; <br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <br />\r\nDie Dichtung ist ein sehr wichtiger Bestandteil im Fenster, werden aber sicherlich nicht so wahr genommen. Ein Fenster ohne Dichtung kann ebenso wenig funktionieren, wie ein Fenster ohne Glas.<br />\r\nIst das Glas defekt, wird es sofort gewechselt. Sind die Fensterdichtungen defekt, merkt man dieses nur im Winter, oder wenn es st&uuml;rmt. Was tun? Ab in den Baumarkt, selbstklebende Dichtung dazwischen ( kommt ja immer im Fernsehen und spart ne menge Energie ) und fertig!! Man sollte aber bedenken, dass es im Zusammenschluss zwischen Fensterfl&uuml;gel und Rahmen bei der Funktion um Millimeter geht.</span></span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">  </span></span><span style=\"font-size: medium;\"> </span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><strong>Selbstklebende Fensterdichtungen f&uuml;r Kunststofffenster ?</strong><br />\r\n&nbsp;<br />\r\nIst die Selbsklebendende Dichtung zu dick gew&auml;hlt, f&uuml;hrt dieses zu Spannungen zwischen Fensterfl&uuml;gel und Rahmen. Diese Spannungen werden von den Fensterbeschl&auml;gen aufgenommen und k&ouml;nnen zu Besch&auml;digungen des Beschlages f&uuml;hren. Deshalb sind SK - Fensterdichtungen keine L&ouml;sung auf Dauer sondern nur kurzfristig eine billige Variante.Eine Berechtigung haben diese Dichtungen nur bei ganz alten Holzfenstern,wo keine Nut zur Aufnahme einer Dichtung vorhanden ist. &nbsp;&nbsp;&nbsp;&nbsp; <br />\r\n<strong>Fenster abdichten spart Energie und schont Ihren Geldbeutel !&nbsp;&nbsp;&nbsp; </strong><br />\r\n<br />\r\nUndichte Fenster k&ouml;nnen wahre Energier&auml;uber sein. Bis zu 30 % der j&auml;hrlichen Heizkosten k&ouml;nnen Verbraucher sparen, wenn sie Ihre undichten Fenster abdichten. Durch eine Spaltbreite von nur 1mm auf einer L&auml;nge von einem Meter, vermindert sich die Raumtemperatur um 1&deg; Celsius.<br />\r\nWenn sie die durchschnittliche Raumtemperatur dadurch um 1&deg; Celsius erh&ouml;hen m&uuml;ssen, kostet dieses 6 % mehr an Energiekosten. Lassen sie keinen Cent durch die Fenster - Ritzen. Bis zu 19 % Heizenergie entweichen durch Zugluft, wenn die Fenster nicht dicht sind. Neue Dichtungen sparen bei einer 80 - Quadratmeter - Wohnung im Jahr 122 Euro.</span></span><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><br />\r\n<br />\r\n<strong>Drei Wege zu Ihren neuen Dichung&nbsp; </strong><br />\r\n<br />\r\nWie schon mehrfach erw&auml;hnt, geht es um bei Fensterdichtungen um Millimeter. Die Profilgeometrie unserer Spezialdichtung ist so gew&auml;hlt, dass diese bei fast allen Kunststofffenstern mit Anschlag - dichtung angewendet werden k&ouml;nnen.<br />\r\n&nbsp;<br />\r\nUnsere Silikon - &nbsp;Dichtungen sind alle vom Aufbau gleich, jedoch sind die Fussbreiten zur Aufnahme in der Dichtungsnut am Fenster unterschiedlich. Der Abdichtungsbereich ist bewu&szlig;t immer etwa 2 - 4 mm h&ouml;her, als bei einer Standard - Fensterdichtung gew&auml;hlt. </span></span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><br />\r\nSollte sich ein Fenster vom Beschlag her nicht mehr ausreichend justieren lassen, sind dies oft die Millimeter, die zu einem dichten Fenster f&uuml;hren und die fehlende Differenz ausgleichen.&nbsp;&nbsp;&nbsp; <br />\r\n<br />\r\n<br />\r\nDie Fu&szlig;breiten und die Stegbreiten ( Nutbreite am Fenster ) wo die Dichtungen eingebaut werden, sind der Entscheidende Punkt, ob die Dichtung f&uuml;r Ihr Profil geeignet ist.<br />\r\n<br />\r\nDie Fu&szlig;breite beim Profil K01 betr&auml;gt 3,5 mm ( Stegbreite 2 mm ) und ist f&uuml;r folgende Systeme geeignet:&nbsp; Aluplast -K&ouml;mmerling - Salamander - Thyssen - Trocal <br />\r\n<br />\r\nDie Fu&szlig;breite beim Profil G01 betr&auml;gt 5,5 mm ( Stegbreite 4,0 mm ) und ist f&uuml;r folgende System geeignet: Gealan - Heroal - KBE - Sch&uuml;co - Veka<br />\r\n<br />\r\nDie Fu&szlig;breite beim Profil MO1 betr&auml;gt 4,5 mm ( Stegbrete 3,5 mm ) und ist unter anderen auch f&uuml;r das System K&ouml;mmerling geeignet.<br />\r\n<br />\r\n<br />\r\nWEG 1 :<br />\r\n<br />\r\nSie kennen ihr Fensterprofil bzw. haben die Fu&szlig;breite ihrer Dichtung selbst ermittelt.<br />\r\nSie k&ouml;nnen nun die Dichtung in unserem Shop bestellen und bekommen die neuen<br />\r\nDichtungen 2-3 Werktage nach Zahlungseingang per DHL geliefert.<br />\r\nGleiches gilt auch f&uuml;r Nachbestellungen<br />\r\n<br />\r\nWEG2 :<br />\r\n<br />\r\nSie schicken uns ein St&uuml;ck Ihrer Fensterdichtung mit der&nbsp;Post, machen einen Stempelabdruck Ihrer Dichtung und schicken uns diesen&nbsp;</span></span><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">per Mail oder Fax.Wir setzen uns dann mit Ihnen in Verbindung und kl&auml;ren die genauen&nbsp;Details.<br />\r\n<br />\r\nWEG3 :<br />\r\n<br />\r\nSie setzen sich mit uns in Verbindung und wir schicken Ihnen jeweils ein St&uuml;ck unserer<br />\r\nDichtungen. Sie probieren die Dichtungen an Ihren Fenstern aus und geben<br />\r\nuns Nachricht welche Dichtung Sie ben&ouml;tigen.<br />\r\n<br />\r\n<br />\r\nUnsere Anschrift lautet:&nbsp;&nbsp; <br />\r\n<br />\r\nStareno GmbH<br />\r\nz. Hd. Herrn Hardy Zich<br />\r\nHohldrift 17<br />\r\nD - 33181 Bad W&uuml;nnenberg<br />\r\n<br />\r\nTel.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 02957 -&nbsp; 9849318<br />\r\nFax&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 02957 -&nbsp; 1591<br />\r\nMail&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; info@fensterdichtungen.org <br />\r\n<br />\r\n<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;</span></span></p>','0','0','','1','13','1','Fensterdichtung, Fensterdichtungen für Kunststoffenster,Fensterdichtung austaueschen, Fensterdichtung erneuern. Fensterdichtung Holzfenster','fensterdichtung erneuern, Fensterdichtungen auswechseln,Fensterdichtung austauschen','Fensterdichtung erneuern, Fensterdichtungen für Kunststofffenster, Fensterdichtung auswechseln,');
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('25','0','0','','2','Dichtungsvergleich','','<p><strong><span style=\"font-size: medium;\">Dichtungsvergleich !</span><br />\r\n</strong></p>\r\n<p><span style=\"font-size: medium;\"> </span></p>\r\n<p><span style=\"font-family: Verdana;\">Hier sehen sie einen Dichtungsverleich einer Standard - Fensterdichtung,&nbsp; im Vergleich zu unserer</span></p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"font-size: medium;\"> </span></p>\r\n<p><span style=\"font-family: Verdana;\"> Spezial - Fensterdichtungen aus Silikon.<br />\r\n</span></p>\r\n<p>&nbsp;</p>\r\n<p><strong><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\">Vorteile die &uuml;berzeugen.</span></span></strong></p>\r\n<p><strong>&nbsp;</strong></p>\r\n<p><img width=\"900\" height=\"1126\" align=\"middle\" src=\"http://www.fensterdichtungen.org/images/content/vergleich2.jpg\" alt=\"\" /></p>\r\n<p>&nbsp;</p>','0','0','','0','14','1','Fensterdichtung Silikon, Fensterdichtungen Silikon','','Fensterdichtung Silikon, Fensterdichtungen Silikon');
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('26','0','0','','2','Dichtung erneuern','','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Fenster abdichten - Fensterdichtung erneuern<br />\r\n</span></span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><br />\r\n<img width=\"850\" height=\"623\" align=\"absmiddle\" alt=\"Fenster abdichten\" src=\"http://www.fensterdichtungen.org/images/content/fluegeldichtung_einbau_850.jpg\" /></span></span></p>','0','0','','1','15','1','Fensterdichtung erneuern, Fenster undicht','fensterdichtung erneuern, Fensterdichtungen auswechseln,Fensterdichtung austauschen','Fenster abdichten, Fensterdichtung erneuern');
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('27','0','0','','2','Eigenschaften Fensterdichtungen','','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Eigenschaften von Fensterdichtungen<br />\r\n<br />\r\nGrunds&auml;tzlich ist die Funktionsweise eines Fensters abh&auml;ngig von der Qualit&auml;t der<br />\r\nFensterdichtungen.In der Vergangenheit wurden die Dichtungen aus APTK / EPDM<br />\r\n( synthetisches Gummi) hergestellt.<br />\r\n<br />\r\nDie Eigenschaften dieses Materials resultierten aus einer Beimischung von Ru&szlig;partikeln<br />\r\nbei der Herstellung von Fensterdichtungen. Dies hatte zur Folge, da&szlig; diese schwarzen<br />\r\nDichtungen h&auml;ufig br&uuml;chig wurden, die Form sich stark ver&auml;nderte und somit als<br />\r\nFensterdichtung nicht mehr funktionierten.<br />\r\n<br />\r\nSchwarze Streifen im Lappen beim Reinigen der Fenster sind so zu erkl&auml;ren. Diese Fenster -<br />\r\ndichtungen aus APTK / EPDM sind ein Elastomer, also chemisch ausreagiert und k&ouml;nnen<br />\r\nstofflich nicht recycelt werden.<br />\r\n<br />\r\nHeute werden Fensterdichtungen aus thermoplastischer Elastomere - TPE - genannt <br />\r\nhergestellt.Diese k&ouml;nnen verschwei&szlig;t, stofflich recycelt werden und haben eine hohe<br />\r\nLebensdauer in Form und Funktion.<br />\r\n<br />\r\nFensterdichtungen aus Silikon werden aus Kostengr&uuml;nden ( k&ouml;nnen zu dem nicht verschwei&szlig;t<br />\r\nwerden ) selten bei der Herstellung von Fenstern verwendet.Silikondichtungen sind best&auml;ndig<br />\r\ngegen Witterungseinfl&uuml;sse wie starke Sonneneinstrahlung, Ozon, Licht, atmosph&auml;rische<br />\r\nVerschmutzung und Alterung.<br />\r\n&nbsp;<br />\r\nSie bleiben auf Dauer elastisch, farbecht und dimensionsstabil. Au&szlig;erdem halten sie beim<br />\r\nZusammendr&uuml;cken oder Verbiegen ihre Form und dichten damit alle Oberfl&auml;chen optimal ab.<br />\r\nFensterdichtungen aus Silikon sind wartungsfrei, haben eine hervorragende Temperatur - <br />\r\nbest&auml;ndigkeit und ein sehr hohe Lebensdauer. Daher eignen sich Dichtungen aus Silikon<br />\r\nhervorragend zum Nachr&uuml;sten defekter Fensterdichtungen.</span></span></p>','0','0','','1','16','1','Fensterdichtungen, Fensterdichtung','fensterdichtung erneuern, Fensterdichtungen auswechseln,Fensterdichtung austauschen','Fensterdichtung erneuern, Fensterdichtungen für Kunststofffenster, Fensterdichtung auswechseln,');
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('32','0','0','','2','Fensterdichtungen kaufen','','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><strong>Fensterdichtungen kaufen, aber welche Dichtung passt bei meinen Kunststofffenstern ?</strong><br />\r\n<br />\r\nGrunds&auml;tzlich ist es so, dass es auf Grund der verschiedenen Fenstersysteme der Hersteller<br />\r\nunterschiedliche Fensterdichtungen innerhalb der Systeme gibt. Oftmals unterscheiden sich<br />\r\ndiese nur in den Dichtungsformen.Dieses zu erkennen, ist nicht so einfach und manchmal ein<br />\r\ngro&szlig;es Problem.<br />\r\n<br />\r\nWichtig zur Bestimmung der richtigen Dichtung ist erst einmal der Dichtungsfu&szlig;, welcher<br />\r\nin die Dichtungsnut( Aufnahme ) des Fensters gedr&uuml;ckt wird. Hier kommt es in erster Linie<br />\r\nauf die Stegbreite in mm ( die Nutbreite am Fenster in der die Dichtung geklemmt ist ) der <br />\r\nDichtung an.Ist die Nut am Fenster 3 mm, dann darf der Steg der neuen Dichtung maximal<br />\r\n3 mm haben.Hier w&auml;re dann der Dichtungsfu&szlig; ( meistens ein Keil ) in etwa 4,5 mm.<br />\r\n<br />\r\nSitzt die Fensterdichtung fest ( so das diese sich nur mit etwas Druck aus der Aufnahme<br />\r\nziehen l&auml;sst ) in der Nut,ist schon viel erreicht. Als n&auml;chstes gilt es zu kl&auml;ren, welche<br />\r\nSpaltbreite meine neue Dichtung abdichten muss.<br />\r\n<br />\r\nHier unterscheiden sich die Fensterdichtungen in der Aufbauh&ouml;he voneinander. Es werden<br />\r\nvon Fall zu Fall unterschiedliche Anforderungen an den neuen Fensterdichtungen gestellt.<br />\r\nOft lassen sich bei &auml;lteren Fenstern die Beschl&auml;ge nicht mehr justieren und die Original<br />\r\nFensterdichtungen k&ouml;nnen die ben&ouml;tigte Spaltluft am Fenster nicht mehr abdichten.<br />\r\n<br />\r\nHierf&uuml;r wurden unsere Spezialdichtungen aus dem Werkstoff Silikon mit einem sehr hohen<br />\r\nSpaltausgleich bis zu 9 mm entwickelt. Haben sich die alten Fensterdichtungen &uuml;ber die<br />\r\nJahre nurwenig abgnutzt, kann der Dichtungsspalt mit einer Standarddichtung abgedichtet <br />\r\nwerden.</span></span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><br />\r\nHier k&ouml;nnen unser Dichtungen aus TPE verwendet werden. Zudem sollten sie darauf achten,<br />\r\ndass beim schlie&szlig;en des Fensterfl&uuml;gels der Schlie&szlig;druck nicht zu schwer geht. Dies ist<br />\r\nein Zeichen, dass die Dichtung zu dick ist. Ein leichtes sp&uuml;rbares andr&uuml;cken der Dichtung <br />\r\nan dem Fensterrahmen ist gew&uuml;nscht und v&ouml;llig normal.<br />\r\n<br />\r\nFazit:<br />\r\n<br />\r\nDie vor genannte Vorgehensweise zur Bestimmung Ihre neuen Fensterdichtungen gilt f&uuml;r alle<br />\r\nFenstertypen. Egal ob Aluminium, Kunststoff oder Holz -Alu Fenster. Unabh&auml;ngig von den<br />\r\nverschiedenen Dichtungsformen und Dichtungsh&ouml;hen ist es immer das Ziel, die undichten <br />\r\nFenster wieder &quot; dicht &quot;zu bekommen.</span></span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><br />\r\nHier hei&szlig;t es einfach nur &quot; probieren &quot; welche Fensterdichtung f&uuml;r ihr Fenster am besten<br />\r\npasst. Es ist also nicht so, dass eine Fensterdichtung nur f&uuml;r einen Fenstertypgeeignet ist. &nbsp;</span></span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Vielmehr lassen sich Fensterdichtungen untereinander und auch mit verschieden Systemen kombinieren.</span></span><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><br />\r\n<br />\r\n<strong>Mehr Einzelheiten bez&uuml;glich Fensterdichtungen f&uuml;r Holzfenster, finden sie auf unserer <br />\r\nSeite unter Informationen in der Rubrik -&nbsp; Holzfensterdichtung Info</strong><br />\r\n</span></span></p>','0','0','','1','21','1','Fensterdichtung kaufen, Fenster Kunststofffenster kaufen, Dichtung kaufen','Fensterdichtung kaufen, Dichtung kaufen','Fensterdichtung kaufen, fensterdichtungen kaufen');
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('29','0','0','','2','Fensterdichtungen pflegen','','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><strong>Fensterdichtungen pflegen erh&ouml;ht die Lebensdauer um ein Vielfaches !</strong><br />\r\n<br />\r\nUm die st&auml;ndige Dichtigkeit und D&auml;mmwirkung von Fensterdichtungen zu<br />\r\ngew&auml;hren, ist das st&auml;ndige Sauberhalten und die dazu geh&ouml;rende Pflege sehr<br />\r\nwichtig. Dieses erh&ouml;ht die Lebensdauer und die Funktionsweise der <br />\r\nFensterdichtungen um das Drei - bis Vierfache.<br />\r\n<br />\r\nGrunds&auml;tzlich beginnt die Pflege mit dem dauerhaften Tockenhalten der <br />\r\nOberfl&auml;chen der Dichtungen,es sollte darauf geachtet werden, dass die<br />\r\nGummis nicht durch Kondens oder Regenwasserbefeuchtet sind. Dies gilt<br />\r\nganz besonders in der Heizperiode.Wenn n&ouml;tig, sollten die Dichtungen<br />\r\nmit einem Lappen trocken gewischt werden,auch wird die Gefahr von m&ouml;glicher<br />\r\nSchimmelbildung vermindert.<br />\r\n<br />\r\nUm die Gummis in ihrer Elastizit&auml;t und Funktion zu unterst&uuml;tzen, sollten<br />\r\ndie Oberfl&auml;chen mit einen Fett oder Talkumstift bzw. Silikonspray behandelt<br />\r\nwerden. Dieses ist vor allem in der Wintersaison zwingend erforderlich. <br />\r\nIm Sommer kann kann ein Talkumpulver verwendet,dass die Feuchtigkeit bindet<br />\r\nund das Kleben der Fensterdichtungen am Fensterrahmen verhindert.</span></span></p>','0','0','','1','18','1','Pflege Fenstersichtung, Fensterdichtungen pflegen','Fensterdichtungen pflegen,Fensterdichtungen','Pflege Fensterdichtung, Fensterdichtungen pflegen');
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('30','0','0','','2','Fensterdichtung austauschen','','<p><span style=\"font-size: medium;\"><span style=\"font-weight: bold;\">Fensterdichtungen austauschen, Fensterdichtung erneuern !<br />\r\n</span><br />\r\nFensterdichtungen sollte man sp&auml;testens nach 15 Jahren wechseln, da sich<br />\r\nDichtungen oft unbemerkt abnutzen und erheblich an Wirkung verlieren. Dieses<br />\r\nmacht sich beim Putzen der Fenster durch schwarze R&uuml;ckst&auml;nde ( Zusatz von<br />\r\nRu&szlig;partikeln in der Rezeptur bei &auml;lteren Fensterdichtungen ) im Lappen bemerkbar.<br />\r\nGanz extrem und unverkennbar ist es dann, wenn die Fensterdichtungen hart und<br />\r\nzerbr&ouml;ckelt sind. <br />\r\n<br />\r\nSp&auml;testens dann haben die Dichtungen ihren Dienst eingestellt und m&uuml;ssen sofort<br />\r\nerneuert werden.Die Folgen die sich hieraus ergeben, sind nicht nur mit viel h&ouml;heren<br />\r\nHeizkosten verbunden,sondern auch mit einem unbehaglichen und nicht gesunden <br />\r\nWohngef&uuml;hl durch Zugluft. Obwohl die Zimmertemperatur&nbsp; 22 &deg; betr&auml;gt , hat es immer<br />\r\nden Anschein,als wenn es zieht und nicht richtig warm in den R&auml;umen ist.<br />\r\n<br />\r\nFensterdichtungen wechseln ist mit etwas Geduld von jedermann durchf&uuml;hrbar. <br />\r\nFragen sie uns, wir stehen Ihnen gern bei der Beschaffung von Fensterdichtungen<br />\r\naller Art zur Verf&uuml;gung. Gern geben wir Ihnen auch Tipps und Anregungen beim Tausch<br />\r\nIhrer neuen Fensterdichtungen.&nbsp; </span></p>','0','0','','1','19','1','Fensterdichtung austauschen, Fensterdichtung erneuern. Fensterdichtungen erneuern','Fensterdichtung austauschen, Dichtung Kunststofffenster erneuern, Fensterichtungen austauschen','Fensterdichtungen austauschen, Fensterdichtung austauschen, Fensterdichtung erneuern, Fensterdichtungen erneuern');
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('33','0','0','','2','Undichte Fenster prüfen','','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><strong>Undichte Fenster pr&uuml;fen<br />\r\n</strong><br />\r\nAm h&auml;ufigsten werden undichte Fenster als Ursache von zu hohen Heizkosten<br />\r\nund den damit verbundenem W&auml;rmeverlust ausgemacht. - Doch wie stelle ich fest,<br />\r\nob meine Fenster noch dicht sind?</span></span><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><br />\r\nSchon sichtbar werden undichte Fenster dadurch, dass man mit der Flamme eines<br />\r\nbrennenden Feuerzeuges entlang des Fensterfl&uuml;gels und Rahmen der Fensters geht. <br />\r\n<br />\r\nEs ist dann zu sehen, ob die Flamme vom Luftzug zum Raum hin und her bewegt werden.<br />\r\nIst dies der Fall, sind die Fenster undicht und es sollten neue Fensterdichtungen<br />\r\neingezogen werden.Gleichzeitig kann man so auch die Anschlussfugen der Wand zum <br />\r\nFenster und der Fensterbank kontrollieren. Hier reicht es oft das alte Silikon zu<br />\r\nentfernen und wieder neu zu versiegeln. <br />\r\n<br />\r\nBitte bedenken sie, dass&nbsp; <br />\r\n<br />\r\nFensterdichtungen Verschlei&szlig;steile sind. Sie werden t&auml;glich, &uuml;ber viele Jahre hinweg,<br />\r\nhohen thermischen und mechanischen Belastungen ausgesetzt. Sie erm&uuml;den im Laufe der<br />\r\nZeit.Je nach Beanspruchung sollten diese &quot;alten&quot;&nbsp; Fensterdichtungen nach sp&auml;testen <br />\r\n15 Jahren ausgewechselt werden.</span></span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><br />\r\nDer Austausch einer defekten Dichtung hilft Ihnen nicht nur die Energiekosten deutlich<br />\r\nzu senken, sondern sch&uuml;tzt auch zus&auml;tzlich gegen L&auml;rm,Schmutz und Bl&uuml;tenpollen.<br />\r\n</span></span></p>','0','0','','1','22','1','Fenster undicht, Dichtung austauschen, Dichtung Kunststofffenster','fensterdichtung erneuern, Fensterdichtungen auswechseln','Fensterdichtungen austauschen, Fensterdichtung austauschen, Fensterdichtung erneuern, Fensterdichtungen erneuern');
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('35','0','0','','2','Vorteil unserer Silikon Fensterdichtung','','<p><strong><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\">Vorteile unserer Spezial &ndash; Fensterdichtungen aus Silikon<br />\r\n</span></span></strong><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\"><strong> </strong><br />\r\nEs fehlen oft nur Millimeter !<br />\r\n<br />\r\nEigens f&uuml;r dieses Problem, haben wir unsere Spezialdichtungen aus hochwertigem<br />\r\nSilikon entwickelt. Keine Dichtung von der Stange, sondern speziell f&uuml;r die<br />\r\nProblematik beim Nachr&uuml;sten der Fensterdichtungen bei &auml;lteren Kunststofffenstern.<br />\r\nDie Profilgeometrie wurde so gew&auml;hlt, dass unsere Silikon - Fensterdichtungen<br />\r\nbei fast allen f&uuml;hrenden Systemgebern von Kunststofffenstern in Europa, als Fl&uuml;gel<br />\r\noder Rahmendichtung verwendet werden k&ouml;nnen.<br />\r\n<br />\r\nEin ausgezeichnetes R&uuml;ckstellverm&ouml;gen, bis 9 mm Verstellbereich,geringer<br />\r\nSchlie&szlig;druck.Die die Ausf&uuml;hrung als Hohlkammerprofil, f&uuml;r einem verbesserten <br />\r\nSchallschutz sind enorme Vorteile gegen&uuml;ber den Standard Fensterdichtungen aus EPDM<br />\r\n&quot;ohne Mehrkosten&quot;. In dem Bereich Informationen, k&ouml;nnen sie unter dem<br />\r\nThema&quot; Drei Wege zu Ihrer Dichtung&quot; ersehen, welche Dichtung sie ben&ouml;tigen. <br />\r\n<br />\r\nAllgemeines &uuml;ber Silikondichtungen<br />\r\n<br />\r\nSilikondichtungen werden unter anderem zum Abdichten von Holzt&uuml;ren und Fenstern<br />\r\nverwendet.Aus Kostengr&uuml;nden finden diese Dichtungen bei der Herstellung von <br />\r\nBauelementen bei der Industrie kaum Beachtung. Zum Einsatz kommen hier oft <br />\r\nGummidichtungen aus verschiedenen Werkstoffen, wie zum Beispiel EPDM oder ATPK.<br />\r\nIm Laufe der Zeit werden Gummidichtungen aufgrund von Sonneneinstrahlung,<br />\r\nAlterserscheinungen oder Umwelteinfl&uuml;ssen hart und br&uuml;chig.<br />\r\n<br />\r\nDie Eigenschaften einer Fensterdichtungen gehen damit verloren. Das die Wahl des<br />\r\nMaterials unserer Spezial &ndash; Fensterdichtungen auf Silikonkautschuk f&auml;llt hat gute<br />\r\nGr&uuml;nde. Silikondichtungen sind best&auml;ndig gegen Witterungseinfl&uuml;sse, wie starke <br />\r\nSonneneinstrahlung,Ozon, Licht, atmosph&auml;rische Verschmutzung und Alterung. Sie <br />\r\nbleiben auf Dauer elastisch, farbecht und dimensionsstabil.<br />\r\n<br />\r\nAu&szlig;erdem bleiben sie beim Zusammendr&uuml;cken oder Verbiegen erhalten und dichten damit<br />\r\nalle Oberfl&auml;chen optimal ab. Sie sind wartungsfrei und haben eine extrem lange<br />\r\nLebensdauer. Ein weiterer Pluspunkt f&uuml;r die Wahl der Silikondichtungenist die <br />\r\nStandhaftigkeit, auch bei extremen Temperaturen.<br />\r\n<br />\r\nIn einem Bereich von 250&deg;C bis -60&deg;C werden sie weder rissig, noch verh&auml;rten sie sich.<br />\r\nKunststoff- oder Gummidichtungen hingegen verh&auml;rten bei niedrigen Temperaturen. <br />\r\nSilikondichtungen kleben auch nicht zusammen,sondern behalten ihre positiven <br />\r\nEigenschafte und ihre Konsistenz.<br />\r\n<br />\r\nSie behalten also ihre Elastizit&auml;t und erreichen dadurch den gewollten Schutz vor<br />\r\nL&auml;rm, Staubund Wasser.Sie sorgen gleichzeitig f&uuml;r die Abd&auml;mmung gegen W&auml;rmeverlust<br />\r\nund sparen somit aktiv einen Teil der anfallenden Heizkosten.<br />\r\n<br />\r\nFensterdichtungen zwischen Fensterfl&uuml;gel und Rahmen sollen die Kondensation<br />\r\nverhindern, denn Kondenswasserkann eine Ursache f&uuml;r Schimmelpilz</span></span><span style=\"font-family: Verdana;\">.</span></p>','0','0','','1','24','1','Fensterdichtung Silikon, Fensterdichtung Silikon','','Silkon Fensterdichtung, Fensterdichtung Silikon. Fensterdichtungen Silikon');
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('36','0','0','','2','Zugluft','','<p><strong><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Zugluft stoppen!</span></span></strong><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><br />\r\n<br />\r\nEs wird viel &uuml;ber ernergiesparende Verglasung und hochd&auml;mmende W&auml;nde gesprochen.<br />\r\n<br />\r\nIn so mancher Wohnung ist aber der Luftzug durch undichte Fenster von vergleichbarer<br />\r\n<br />\r\nBedeutung.<br />\r\n<br />\r\nWas hilft? - Zugluft&nbsp; stoppen, Fenster abdichten und zudem noch Energie sparen.&nbsp; <br />\r\n<br />\r\nEin zu starker Luftstrom bedeutet, das wir auch bei 21 Grad Raumtemperatur frieren.<br />\r\n<br />\r\nDie gilt besonders bei kalter und feuchter Luft.<br />\r\n<br />\r\n</span></span><span style=\"font-size: medium; font-family: Verdana;\">Lassen sie keinen Cent durch die Fenster - Ritzen. Bis zu 19 % Heizenergie entweichen</span></p>\r\n<p><span style=\"font-size: medium; font-family: Verdana;\"> durch Zugluft, wenn die Fenster nicht dicht sind. Neue Dichtungen sparen bei einer 80 </span></p>\r\n<p><span style=\"font-size: medium; font-family: Verdana;\">Quadratmeter - Wohnung im Jahr 122 Euro.</span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><br />\r\n<br />\r\n</span></span></p>','0','0','','1','25','1','Zugluft, Fenster abdichten, Fenster undicht,undichte Fenster','Zugluft, Zugluft stoppen, Fenster undicht, Fenster abdichten','Zugluft, Zugluft stoppen, Fenster undicht, Fenster abdichten');
INSERT INTO `content_manager` (`content_id`, `categories_id`, `parent_id`, `group_ids`, `languages_id`, `content_title`, `content_heading`, `content_text`, `sort_order`, `file_flag`, `content_file`, `content_status`, `content_group`, `content_delete`, `content_meta_title`, `content_meta_description`, `content_meta_keywords`) VALUES ('37','0','0','','2','Holzfensterdichtung kaufen','','<p><span style=\"font-size: medium;\"><span style=\"font-weight: bold;\">Holzfensterdichtungen nachr&uuml;sten, einfr&auml;sen bzw. austauschen !</span><br />\r\n<br />\r\nFensterdichtungen beeinflussen ma&szlig;geblich die Leistungseigenschaften eines Fensters, wie<br />\r\nzum Beispiel die Schlagregendichtheit, die Luftdurchl&auml;ssigkeit,den Schall- W&auml;rmeschutz sowie<br />\r\ndie Bedienung eines Fensters. Dieses ist im Hinblick auf steigende Anforderungen der neuen<br />\r\nW&auml;rmeschutzverordnung nicht zu verkennen.<br />\r\n<br />\r\nDieses gilt ganz besonders f&uuml;r Holzfenster, welche bis in den fr&uuml;hen 60 er Jahren noch v&ouml;llig <br />\r\nohne Fensterdichtungen gefertigt wurden. Hier konnte man undichte Holzfenster nur mit den<br />\r\naus der Werbung bekannten Klebedichtungen abdichten. Heute wird bei diesem Typ von<br />\r\nHolzfenstern eine neue Nut in den Rahmen gefr&auml;st um das Fenster wieder dicht zu bekommen.<br />\r\nZum Nachr&uuml;sten werden Spezial -  Dichtungen aus Silikon verwendet, dieses kann aber nur durch<br />\r\neinen Fachbetrieb ausgef&uuml;hrt werden.<br />\r\n<br />\r\nBei Holzfenstern ab den 80 er Jahren wurden dann Holzfenster mit bis zu drei Nuten hergestellt.<br />\r\nHier wurden dann Fl&uuml;gelfalz bzw. Stulp oder Anschlagdichtungen zum abdichten verwendet. Bei <br />\r\ndiesen Holzfenstern ist das auswechseln von Holzfensterdichtungen kein Problem, so dass dieses <br />\r\nf&uuml;r jeden Hobbyhandwerker m&ouml;glich sein sollte.<br />\r\n<br />\r\nFolgendes ist bei der Bestimmung von neuen Holzfensterdichtungen zu beachten:<br />\r\n&nbsp;<br />\r\n1.&nbsp;&nbsp;&nbsp; Die Nuttiefe ( dort wo die Holzfensterdichtung eingef&uuml;hrt ist ) ca. 7 &ndash; 9 mm<br />\r\n2.&nbsp;&nbsp;&nbsp; Die Nutbreite ( die Breite der Fr&auml;sung der Dichtungsaufnahme ) 2,5 &ndash; 5,5 mm<br />\r\n3.&nbsp;&nbsp;&nbsp; Die Falzh&ouml;he ( Ma&szlig; der Dichtungsauflage am Fenster ) 10, 12, 15 oder 18 mm <br />\r\n<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <br />\r\nBeim Einbau ist darauf zu achten,dass die Holzfensterdichtung in den Ecken und an den<br />\r\nDichtungsst&ouml;&szlig;en spaltfrei ausgef&uuml;hrt wird. Der Dichtungssto&szlig; sollte sich oben befinden und die<br />\r\nFensterdichtung sollte beim Einbau nicht gestaucht, oder &uuml;berdehnt werden. Die Anschlagluft bei<br />\r\nHolzfenstern betr&auml;gt in der Regel 5mm, so dass die Holzfensterdichtung eine Dichtungsh&ouml;he von<br />\r\nca. 7 - 8 mm haben sollte. <br />\r\n&nbsp;<br />\r\nDiese Darstellung soll nur als kleine Information verstanden werden. Gern stehen wir Ihnen mit<br />\r\nRat und Tat beim Nachr&uuml;sten von Holzfensterdichtungen, bzw. Dichtungen aller Art zur Seite.</span><font size=\"3\"><span style=\"font-family: Verdana;\"><br />\r\n</span></font></p>','0','0','','1','26','1','Fensterdichtung Holzfenster kaufen, Fensterdichtungen Holzfenster','Fensterdichtung Holzfenster austauschen,Dichtung Holzfenster nachrüsten, Fensterdichtungen Holzfenster','Holzfensterdichtungen nachrüsten, Fensterdichtung Holzfenster,Holzfensterdichtung erneuern,Fensterdichtungen Holzfenster, Fensterdichtung Holzfenster');
/*!40000 ALTER TABLE `content_manager` ENABLE KEYS */;

DROP TABLE IF EXISTS `counter`;
CREATE TABLE `counter` (
  `startdate` char(8) COLLATE latin1_german1_ci DEFAULT NULL,
  `counter` int(12) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `counter` DISABLE KEYS */;
/*!40000 ALTER TABLE `counter` ENABLE KEYS */;

DROP TABLE IF EXISTS `counter_history`;
CREATE TABLE `counter_history` (
  `month` char(8) COLLATE latin1_german1_ci DEFAULT NULL,
  `counter` int(12) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `counter_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `counter_history` ENABLE KEYS */;

DROP TABLE IF EXISTS `countries`;
CREATE TABLE `countries` (
  `countries_id` int(11) NOT NULL AUTO_INCREMENT,
  `countries_name` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `countries_iso_code_2` char(2) COLLATE latin1_german1_ci NOT NULL,
  `countries_iso_code_3` char(3) COLLATE latin1_german1_ci NOT NULL,
  `address_format_id` int(11) NOT NULL,
  `status` int(1) DEFAULT '1',
  PRIMARY KEY (`countries_id`),
  KEY `IDX_COUNTRIES_NAME` (`countries_name`)
) ENGINE=MyISAM AUTO_INCREMENT=242 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('1','Afghanistan','AF','AFG','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('2','Albania','AL','ALB','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('3','Algeria','DZ','DZA','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('4','American Samoa','AS','ASM','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('5','Andorra','AD','AND','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('6','Angola','AO','AGO','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('7','Anguilla','AI','AIA','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('8','Antarctica','AQ','ATA','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('9','Antigua and Barbuda','AG','ATG','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('10','Argentina','AR','ARG','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('11','Armenia','AM','ARM','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('12','Aruba','AW','ABW','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('13','Australia','AU','AUD','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('14','Austria','AT','AUT','5','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('15','Azerbaijan','AZ','AZE','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('16','Bahamas','BS','BHS','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('17','Bahrain','BH','BHR','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('18','Bangladesh','BD','BGD','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('19','Barbados','BB','BRB','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('20','Belarus','BY','BLR','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('21','Belgium','BE','BEL','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('22','Belize','BZ','BLZ','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('23','Benin','BJ','BEN','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('24','Bermuda','BM','BMU','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('25','Bhutan','BT','BTN','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('26','Bolivia','BO','BOL','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('27','Bosnia and Herzegowina','BA','BIH','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('28','Botswana','BW','BWA','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('29','Bouvet Island','BV','BVT','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('30','Brazil','BR','BRA','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('31','British Indian Ocean Territory','IO','IOT','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('32','Brunei Darussalam','BN','BRN','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('33','Bulgaria','BG','BGR','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('34','Burkina Faso','BF','BFA','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('35','Burundi','BI','BDI','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('36','Cambodia','KH','KHM','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('37','Cameroon','CM','CMR','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('38','Canada','CA','CAN','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('39','Cape Verde','CV','CPV','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('40','Cayman Islands','KY','CYM','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('41','Central African Republic','CF','CAF','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('42','Chad','TD','TCD','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('43','Chile','CL','CHL','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('44','China','CN','CHN','7','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('45','Christmas Island','CX','CXR','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('46','Cocos (Keeling) Islands','CC','CCK','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('47','Colombia','CO','COL','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('48','Comoros','KM','COM','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('49','Congo','CG','COG','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('50','Cook Islands','CK','COK','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('51','Costa Rica','CR','CRI','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('52','Cote D\'Ivoire','CI','CIV','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('53','Croatia','HR','HRV','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('54','Cuba','CU','CUB','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('55','Cyprus','CY','CYP','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('56','Czech Republic','CZ','CZE','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('57','Denmark','DK','DNK','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('58','Djibouti','DJ','DJI','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('59','Dominica','DM','DMA','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('60','Dominican Republic','DO','DOM','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('61','East Timor','TP','TMP','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('62','Ecuador','EC','ECU','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('63','Egypt','EG','EGY','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('64','El Salvador','SV','SLV','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('65','Equatorial Guinea','GQ','GNQ','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('66','Eritrea','ER','ERI','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('67','Estonia','EE','EST','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('68','Ethiopia','ET','ETH','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('69','Falkland Islands (Malvinas)','FK','FLK','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('70','Faroe Islands','FO','FRO','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('71','Fiji','FJ','FJI','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('72','Finland','FI','FIN','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('73','France','FR','FRA','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('74','France, Metropolitan','FX','FXX','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('75','French Guiana','GF','GUF','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('76','French Polynesia','PF','PYF','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('77','French Southern Territories','TF','ATF','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('78','Gabon','GA','GAB','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('79','Gambia','GM','GMB','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('80','Georgia','GE','GEO','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('81','Germany','DE','DEU','5','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('82','Ghana','GH','GHA','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('83','Gibraltar','GI','GIB','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('84','Greece','GR','GRC','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('85','Greenland','GL','GRL','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('86','Grenada','GD','GRD','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('87','Guadeloupe','GP','GLP','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('88','Guam','GU','GUM','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('89','Guatemala','GT','GTM','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('90','Guinea','GN','GIN','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('91','Guinea-bissau','GW','GNB','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('92','Guyana','GY','GUY','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('93','Haiti','HT','HTI','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('94','Heard and Mc Donald Islands','HM','HMD','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('95','Honduras','HN','HND','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('96','Hong Kong','HK','HKG','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('97','Hungary','HU','HUN','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('98','Iceland','IS','ISL','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('99','India','IN','IND','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('100','Indonesia','ID','IDN','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('101','Iran (Islamic Republic of)','IR','IRN','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('102','Iraq','IQ','IRQ','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('103','Ireland','IE','IRL','6','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('104','Israel','IL','ISR','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('105','Italy','IT','ITA','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('106','Jamaica','JM','JAM','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('107','Japan','JP','JPN','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('108','Jordan','JO','JOR','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('109','Kazakhstan','KZ','KAZ','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('110','Kenya','KE','KEN','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('111','Kiribati','KI','KIR','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('112','Korea, Democratic People\'s Republic of','KP','PRK','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('113','Korea, Republic of','KR','KOR','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('114','Kuwait','KW','KWT','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('115','Kyrgyzstan','KG','KGZ','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('116','Lao People\'s Democratic Republic','LA','LAO','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('117','Latvia','LV','LVA','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('118','Lebanon','LB','LBN','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('119','Lesotho','LS','LSO','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('120','Liberia','LR','LBR','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('121','Libyan Arab Jamahiriya','LY','LBY','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('122','Liechtenstein','LI','LIE','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('123','Lithuania','LT','LTU','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('124','Luxembourg','LU','LUX','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('125','Macau','MO','MAC','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('126','Macedonia, The Former Yugoslav Republic of','MK','MKD','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('127','Madagascar','MG','MDG','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('128','Malawi','MW','MWI','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('129','Malaysia','MY','MYS','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('130','Maldives','MV','MDV','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('131','Mali','ML','MLI','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('132','Malta','MT','MLT','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('133','Marshall Islands','MH','MHL','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('134','Martinique','MQ','MTQ','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('135','Mauritania','MR','MRT','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('136','Mauritius','MU','MUS','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('137','Mayotte','YT','MYT','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('138','Mexico','MX','MEX','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('139','Micronesia, Federated States of','FM','FSM','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('140','Moldova, Republic of','MD','MDA','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('141','Monaco','MC','MCO','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('142','Mongolia','MN','MNG','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('143','Montserrat','MS','MSR','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('144','Morocco','MA','MAR','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('145','Mozambique','MZ','MOZ','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('146','Myanmar','MM','MMR','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('147','Namibia','NA','NAM','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('148','Nauru','NR','NRU','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('149','Nepal','NP','NPL','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('150','Netherlands','NL','NLD','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('151','Netherlands Antilles','AN','ANT','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('152','New Caledonia','NC','NCL','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('153','New Zealand','NZ','NZL','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('154','Nicaragua','NI','NIC','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('155','Niger','NE','NER','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('156','Nigeria','NG','NGA','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('157','Niue','NU','NIU','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('158','Norfolk Island','NF','NFK','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('159','Northern Mariana Islands','MP','MNP','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('160','Norway','NO','NOR','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('161','Oman','OM','OMN','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('162','Pakistan','PK','PAK','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('163','Palau','PW','PLW','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('164','Panama','PA','PAN','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('165','Papua New Guinea','PG','PNG','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('166','Paraguay','PY','PRY','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('167','Peru','PE','PER','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('168','Philippines','PH','PHL','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('169','Pitcairn','PN','PCN','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('170','Poland','PL','POL','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('171','Portugal','PT','PRT','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('172','Puerto Rico','PR','PRI','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('173','Qatar','QA','QAT','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('174','Reunion','RE','REU','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('175','Romania','RO','ROM','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('176','Russian Federation','RU','RUS','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('177','Rwanda','RW','RWA','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('178','Saint Kitts and Nevis','KN','KNA','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('179','Saint Lucia','LC','LCA','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('180','Saint Vincent and the Grenadines','VC','VCT','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('181','Samoa','WS','WSM','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('182','San Marino','SM','SMR','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('183','Sao Tome and Principe','ST','STP','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('184','Saudi Arabia','SA','SAU','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('185','Senegal','SN','SEN','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('186','Seychelles','SC','SYC','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('187','Sierra Leone','SL','SLE','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('188','Singapore','SG','SGP','4','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('189','Slovakia (Slovak Republic)','SK','SVK','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('190','Slovenia','SI','SVN','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('191','Solomon Islands','SB','SLB','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('192','Somalia','SO','SOM','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('193','South Africa','ZA','ZAF','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('194','South Georgia and the South Sandwich Islands','GS','SGS','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('195','Spain','ES','ESP','3','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('196','Sri Lanka','LK','LKA','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('197','St. Helena','SH','SHN','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('198','St. Pierre and Miquelon','PM','SPM','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('199','Sudan','SD','SDN','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('200','Suriname','SR','SUR','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('201','Svalbard and Jan Mayen Islands','SJ','SJM','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('202','Swaziland','SZ','SWZ','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('203','Sweden','SE','SWE','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('204','Switzerland','CH','CHE','5','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('205','Syrian Arab Republic','SY','SYR','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('206','Taiwan','TW','TWN','6','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('207','Tajikistan','TJ','TJK','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('208','Tanzania, United Republic of','TZ','TZA','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('209','Thailand','TH','THA','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('210','Togo','TG','TGO','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('211','Tokelau','TK','TKL','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('212','Tonga','TO','TON','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('213','Trinidad and Tobago','TT','TTO','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('214','Tunisia','TN','TUN','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('215','Turkey','TR','TUR','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('216','Turkmenistan','TM','TKM','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('217','Turks and Caicos Islands','TC','TCA','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('218','Tuvalu','TV','TUV','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('219','Uganda','UG','UGA','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('220','Ukraine','UA','UKR','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('221','United Arab Emirates','AE','ARE','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('222','United Kingdom','GB','GBR','8','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('223','United States','US','USA','2','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('224','United States Minor Outlying Islands','UM','UMI','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('225','Uruguay','UY','URY','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('226','Uzbekistan','UZ','UZB','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('227','Vanuatu','VU','VUT','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('228','Vatican City State (Holy See)','VA','VAT','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('229','Venezuela','VE','VEN','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('230','Viet Nam','VN','VNM','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('231','Virgin Islands (British)','VG','VGB','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('232','Virgin Islands (U.S.)','VI','VIR','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('233','Wallis and Futuna Islands','WF','WLF','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('234','Western Sahara','EH','ESH','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('235','Yemen','YE','YEM','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('237','Zaire','ZR','ZAR','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('238','Zambia','ZM','ZMB','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('239','Zimbabwe','ZW','ZWE','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('240','Serbia','RS','SRB','1','1');
INSERT INTO `countries` (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `status`) VALUES ('241','Montenegro','ME','MNE','1','1');
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;

DROP TABLE IF EXISTS `coupon_email_track`;
CREATE TABLE `coupon_email_track` (
  `unique_id` int(11) NOT NULL AUTO_INCREMENT,
  `coupon_id` int(11) NOT NULL DEFAULT '0',
  `customer_id_sent` int(11) NOT NULL DEFAULT '0',
  `sent_firstname` varchar(32) COLLATE latin1_german1_ci DEFAULT NULL,
  `sent_lastname` varchar(32) COLLATE latin1_german1_ci DEFAULT NULL,
  `emailed_to` varchar(32) COLLATE latin1_german1_ci DEFAULT NULL,
  `date_sent` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`unique_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `coupon_email_track` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupon_email_track` ENABLE KEYS */;

DROP TABLE IF EXISTS `coupon_gv_customer`;
CREATE TABLE `coupon_gv_customer` (
  `customer_id` int(5) NOT NULL DEFAULT '0',
  `amount` decimal(8,4) NOT NULL DEFAULT '0.0000',
  PRIMARY KEY (`customer_id`),
  KEY `customer_id` (`customer_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `coupon_gv_customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupon_gv_customer` ENABLE KEYS */;

DROP TABLE IF EXISTS `coupon_gv_queue`;
CREATE TABLE `coupon_gv_queue` (
  `unique_id` int(5) NOT NULL AUTO_INCREMENT,
  `customer_id` int(5) NOT NULL DEFAULT '0',
  `order_id` int(5) NOT NULL DEFAULT '0',
  `amount` decimal(8,4) NOT NULL DEFAULT '0.0000',
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ipaddr` varchar(39) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `release_flag` char(1) COLLATE latin1_german1_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`unique_id`),
  KEY `uid` (`unique_id`,`customer_id`,`order_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `coupon_gv_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupon_gv_queue` ENABLE KEYS */;

DROP TABLE IF EXISTS `coupon_redeem_track`;
CREATE TABLE `coupon_redeem_track` (
  `unique_id` int(11) NOT NULL AUTO_INCREMENT,
  `coupon_id` int(11) NOT NULL DEFAULT '0',
  `customer_id` int(11) NOT NULL DEFAULT '0',
  `redeem_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `redeem_ip` varchar(39) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `order_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`unique_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `coupon_redeem_track` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupon_redeem_track` ENABLE KEYS */;

DROP TABLE IF EXISTS `coupons`;
CREATE TABLE `coupons` (
  `coupon_id` int(11) NOT NULL AUTO_INCREMENT,
  `coupon_type` char(1) COLLATE latin1_german1_ci NOT NULL DEFAULT 'F',
  `coupon_code` varchar(32) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `coupon_amount` decimal(8,4) NOT NULL DEFAULT '0.0000',
  `coupon_minimum_order` decimal(8,4) NOT NULL DEFAULT '0.0000',
  `coupon_start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `coupon_expire_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `uses_per_coupon` int(5) NOT NULL DEFAULT '1',
  `uses_per_user` int(5) NOT NULL DEFAULT '0',
  `restrict_to_products` varchar(255) COLLATE latin1_german1_ci DEFAULT NULL,
  `restrict_to_categories` varchar(255) COLLATE latin1_german1_ci DEFAULT NULL,
  `restrict_to_customers` text COLLATE latin1_german1_ci,
  `coupon_active` char(1) COLLATE latin1_german1_ci NOT NULL DEFAULT 'Y',
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`coupon_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;

DROP TABLE IF EXISTS `coupons_description`;
CREATE TABLE `coupons_description` (
  `coupon_id` int(11) NOT NULL DEFAULT '0',
  `language_id` tinyint(4) NOT NULL DEFAULT '1',
  `coupon_name` varchar(32) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `coupon_description` text COLLATE latin1_german1_ci,
  KEY `coupon_id` (`coupon_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `coupons_description` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupons_description` ENABLE KEYS */;

DROP TABLE IF EXISTS `currencies`;
CREATE TABLE `currencies` (
  `currencies_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `code` char(3) COLLATE latin1_german1_ci NOT NULL,
  `symbol_left` varchar(12) COLLATE latin1_german1_ci DEFAULT NULL,
  `symbol_right` varchar(12) COLLATE latin1_german1_ci DEFAULT NULL,
  `decimal_point` char(1) COLLATE latin1_german1_ci DEFAULT NULL,
  `thousands_point` char(1) COLLATE latin1_german1_ci DEFAULT NULL,
  `decimal_places` char(1) COLLATE latin1_german1_ci DEFAULT NULL,
  `value` float(13,8) DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  PRIMARY KEY (`currencies_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `currencies` DISABLE KEYS */;
INSERT INTO `currencies` (`currencies_id`, `title`, `code`, `symbol_left`, `symbol_right`, `decimal_point`, `thousands_point`, `decimal_places`, `value`, `last_updated`) VALUES ('1','Euro','EUR','','EUR',',','.','2','1.00000000','2014-10-16 20:37:49');
/*!40000 ALTER TABLE `currencies` ENABLE KEYS */;

DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers` (
  `customers_id` int(11) NOT NULL AUTO_INCREMENT,
  `customers_cid` varchar(32) COLLATE latin1_german1_ci DEFAULT NULL,
  `customers_vat_id` varchar(20) COLLATE latin1_german1_ci DEFAULT NULL,
  `customers_vat_id_status` int(2) NOT NULL DEFAULT '0',
  `customers_warning` varchar(32) COLLATE latin1_german1_ci DEFAULT NULL,
  `customers_status` int(5) NOT NULL DEFAULT '1',
  `customers_gender` char(1) COLLATE latin1_german1_ci NOT NULL,
  `customers_firstname` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `customers_lastname` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `customers_dob` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `customers_email_address` varchar(96) COLLATE latin1_german1_ci NOT NULL,
  `customers_default_address_id` int(11) NOT NULL,
  `customers_telephone` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `customers_fax` varchar(32) COLLATE latin1_german1_ci DEFAULT NULL,
  `customers_password` varchar(50) COLLATE latin1_german1_ci NOT NULL,
  `customers_newsletter` char(1) COLLATE latin1_german1_ci DEFAULT NULL,
  `customers_newsletter_mode` char(1) COLLATE latin1_german1_ci NOT NULL DEFAULT '0',
  `member_flag` char(1) COLLATE latin1_german1_ci NOT NULL DEFAULT '0',
  `delete_user` char(1) COLLATE latin1_german1_ci NOT NULL DEFAULT '1',
  `account_type` int(1) NOT NULL DEFAULT '0',
  `password_request_key` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `payment_unallowed` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `shipping_unallowed` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `refferers_id` varchar(32) COLLATE latin1_german1_ci NOT NULL DEFAULT '0',
  `customers_date_added` datetime DEFAULT '0000-00-00 00:00:00',
  `customers_last_modified` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`customers_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` (`customers_id`, `customers_cid`, `customers_vat_id`, `customers_vat_id_status`, `customers_warning`, `customers_status`, `customers_gender`, `customers_firstname`, `customers_lastname`, `customers_dob`, `customers_email_address`, `customers_default_address_id`, `customers_telephone`, `customers_fax`, `customers_password`, `customers_newsletter`, `customers_newsletter_mode`, `member_flag`, `delete_user`, `account_type`, `password_request_key`, `payment_unallowed`, `shipping_unallowed`, `refferers_id`, `customers_date_added`, `customers_last_modified`) VALUES ('1','','','0',NULL,'0','m','Hardy','Zich','1992-11-17 00:00:00','info@fensterdichtungen.org','1','029579849318','','584314a86dbae8c6a786013b4ff572e2','','0','0','0','0','','','','0','0000-00-00 00:00:00','2014-11-01 17:03:52');
INSERT INTO `customers` (`customers_id`, `customers_cid`, `customers_vat_id`, `customers_vat_id_status`, `customers_warning`, `customers_status`, `customers_gender`, `customers_firstname`, `customers_lastname`, `customers_dob`, `customers_email_address`, `customers_default_address_id`, `customers_telephone`, `customers_fax`, `customers_password`, `customers_newsletter`, `customers_newsletter_mode`, `member_flag`, `delete_user`, `account_type`, `password_request_key`, `payment_unallowed`, `shipping_unallowed`, `refferers_id`, `customers_date_added`, `customers_last_modified`) VALUES ('3','','','0',NULL,'0','m','Hardy','Zich','1957-09-25 00:00:00','hzich@t-online.de','3','029571714','','df16167b86c233e09a748d694d3c6f9b',NULL,'0','0','1','0','','','','0','2014-10-16 22:51:59','2014-10-16 22:51:59');
INSERT INTO `customers` (`customers_id`, `customers_cid`, `customers_vat_id`, `customers_vat_id_status`, `customers_warning`, `customers_status`, `customers_gender`, `customers_firstname`, `customers_lastname`, `customers_dob`, `customers_email_address`, `customers_default_address_id`, `customers_telephone`, `customers_fax`, `customers_password`, `customers_newsletter`, `customers_newsletter_mode`, `member_flag`, `delete_user`, `account_type`, `password_request_key`, `payment_unallowed`, `shipping_unallowed`, `refferers_id`, `customers_date_added`, `customers_last_modified`) VALUES ('4',NULL,'','0',NULL,'2','m','Bernhard','Dietzel','1960-05-04 00:00:00','BDietzel@t-online.de','4','03695825457','','2621c164e24fc157c391e2b0d8ef77cc','','0','0','1','0','','','','0','2014-11-01 17:41:43','2014-11-01 17:41:43');
INSERT INTO `customers` (`customers_id`, `customers_cid`, `customers_vat_id`, `customers_vat_id_status`, `customers_warning`, `customers_status`, `customers_gender`, `customers_firstname`, `customers_lastname`, `customers_dob`, `customers_email_address`, `customers_default_address_id`, `customers_telephone`, `customers_fax`, `customers_password`, `customers_newsletter`, `customers_newsletter_mode`, `member_flag`, `delete_user`, `account_type`, `password_request_key`, `payment_unallowed`, `shipping_unallowed`, `refferers_id`, `customers_date_added`, `customers_last_modified`) VALUES ('5',NULL,'','0',NULL,'2','m','Ulf','Jakubke','1969-07-15 00:00:00','ulf.jakubke@halja.de','5','03066307531','','6ef3b8282fe4fe2fc3c25f267fb12224','','0','0','1','0','','','','0','2014-11-02 19:47:44','2014-11-02 19:47:44');
INSERT INTO `customers` (`customers_id`, `customers_cid`, `customers_vat_id`, `customers_vat_id_status`, `customers_warning`, `customers_status`, `customers_gender`, `customers_firstname`, `customers_lastname`, `customers_dob`, `customers_email_address`, `customers_default_address_id`, `customers_telephone`, `customers_fax`, `customers_password`, `customers_newsletter`, `customers_newsletter_mode`, `member_flag`, `delete_user`, `account_type`, `password_request_key`, `payment_unallowed`, `shipping_unallowed`, `refferers_id`, `customers_date_added`, `customers_last_modified`) VALUES ('6',NULL,'','0',NULL,'2','m','Frank','Mladek','1970-01-28 00:00:00','fmladek@aol.com','6','03301-204432','','fa5d732b9e23f0b05e5db82ba401f8a8','','0','0','1','0','','','','0','2014-11-02 22:13:39','2014-11-02 22:13:39');
INSERT INTO `customers` (`customers_id`, `customers_cid`, `customers_vat_id`, `customers_vat_id_status`, `customers_warning`, `customers_status`, `customers_gender`, `customers_firstname`, `customers_lastname`, `customers_dob`, `customers_email_address`, `customers_default_address_id`, `customers_telephone`, `customers_fax`, `customers_password`, `customers_newsletter`, `customers_newsletter_mode`, `member_flag`, `delete_user`, `account_type`, `password_request_key`, `payment_unallowed`, `shipping_unallowed`, `refferers_id`, `customers_date_added`, `customers_last_modified`) VALUES ('7',NULL,'','0',NULL,'2','m','Hans-Ulrich','Tappe','1961-09-29 00:00:00','Ulli-Tappe@gmx.de','7','02641 / 3968222','','69a8659d78ee041b127aede188c916fc','','0','0','1','0','','','','0','2014-11-03 09:37:55','2014-11-03 09:37:55');
INSERT INTO `customers` (`customers_id`, `customers_cid`, `customers_vat_id`, `customers_vat_id_status`, `customers_warning`, `customers_status`, `customers_gender`, `customers_firstname`, `customers_lastname`, `customers_dob`, `customers_email_address`, `customers_default_address_id`, `customers_telephone`, `customers_fax`, `customers_password`, `customers_newsletter`, `customers_newsletter_mode`, `member_flag`, `delete_user`, `account_type`, `password_request_key`, `payment_unallowed`, `shipping_unallowed`, `refferers_id`, `customers_date_added`, `customers_last_modified`) VALUES ('8',NULL,'','0',NULL,'2','m','willi','kröner','1950-08-23 00:00:00','willi.kroener@gmx.de','8','07322 21698','','547c5b7a56c87a4b48c0763db84cf28d','','0','0','1','0','','','','0','2014-11-03 10:17:12','2014-11-03 10:17:12');
INSERT INTO `customers` (`customers_id`, `customers_cid`, `customers_vat_id`, `customers_vat_id_status`, `customers_warning`, `customers_status`, `customers_gender`, `customers_firstname`, `customers_lastname`, `customers_dob`, `customers_email_address`, `customers_default_address_id`, `customers_telephone`, `customers_fax`, `customers_password`, `customers_newsletter`, `customers_newsletter_mode`, `member_flag`, `delete_user`, `account_type`, `password_request_key`, `payment_unallowed`, `shipping_unallowed`, `refferers_id`, `customers_date_added`, `customers_last_modified`) VALUES ('9',NULL,'','0',NULL,'2','m','konrad','Bremer','1947-05-22 00:00:00','konrad.bremer@htp-tel.de','9','0511 401092','','810d93d8c2244038084c6edcccd3f115','1','0','0','1','0','','','','0','2014-11-03 12:02:39','2014-11-03 12:02:39');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;

DROP TABLE IF EXISTS `customers_basket`;
CREATE TABLE `customers_basket` (
  `customers_basket_id` int(11) NOT NULL AUTO_INCREMENT,
  `customers_id` int(11) NOT NULL,
  `products_id` tinytext COLLATE latin1_german1_ci NOT NULL,
  `customers_basket_quantity` int(2) NOT NULL,
  `final_price` decimal(15,4) NOT NULL,
  `customers_basket_date_added` char(8) COLLATE latin1_german1_ci DEFAULT NULL,
  PRIMARY KEY (`customers_basket_id`)
) ENGINE=MyISAM AUTO_INCREMENT=78 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `customers_basket` DISABLE KEYS */;
/*!40000 ALTER TABLE `customers_basket` ENABLE KEYS */;

DROP TABLE IF EXISTS `customers_basket_attributes`;
CREATE TABLE `customers_basket_attributes` (
  `customers_basket_attributes_id` int(11) NOT NULL AUTO_INCREMENT,
  `customers_id` int(11) NOT NULL,
  `products_id` tinytext COLLATE latin1_german1_ci NOT NULL,
  `products_options_id` int(11) NOT NULL,
  `products_options_value_id` int(11) NOT NULL,
  PRIMARY KEY (`customers_basket_attributes_id`)
) ENGINE=MyISAM AUTO_INCREMENT=93 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `customers_basket_attributes` DISABLE KEYS */;
/*!40000 ALTER TABLE `customers_basket_attributes` ENABLE KEYS */;

DROP TABLE IF EXISTS `customers_info`;
CREATE TABLE `customers_info` (
  `customers_info_id` int(11) NOT NULL,
  `customers_info_date_of_last_logon` datetime DEFAULT NULL,
  `customers_info_number_of_logons` int(5) DEFAULT NULL,
  `customers_info_date_account_created` datetime DEFAULT NULL,
  `customers_info_date_account_last_modified` datetime DEFAULT NULL,
  `global_product_notifications` int(1) DEFAULT '0',
  PRIMARY KEY (`customers_info_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `customers_info` DISABLE KEYS */;
INSERT INTO `customers_info` (`customers_info_id`, `customers_info_date_of_last_logon`, `customers_info_number_of_logons`, `customers_info_date_account_created`, `customers_info_date_account_last_modified`, `global_product_notifications`) VALUES ('1','2014-11-03 14:33:25','138','0000-00-00 00:00:00','2014-11-01 17:03:52','0');
INSERT INTO `customers_info` (`customers_info_id`, `customers_info_date_of_last_logon`, `customers_info_number_of_logons`, `customers_info_date_account_created`, `customers_info_date_account_last_modified`, `global_product_notifications`) VALUES ('3','2014-11-01 14:14:04','19','2014-10-16 22:51:59',NULL,'0');
INSERT INTO `customers_info` (`customers_info_id`, `customers_info_date_of_last_logon`, `customers_info_number_of_logons`, `customers_info_date_account_created`, `customers_info_date_account_last_modified`, `global_product_notifications`) VALUES ('4','2014-11-02 09:10:12','1','2014-11-01 17:41:43',NULL,'0');
INSERT INTO `customers_info` (`customers_info_id`, `customers_info_date_of_last_logon`, `customers_info_number_of_logons`, `customers_info_date_account_created`, `customers_info_date_account_last_modified`, `global_product_notifications`) VALUES ('5',NULL,'0','2014-11-02 19:47:44',NULL,'0');
INSERT INTO `customers_info` (`customers_info_id`, `customers_info_date_of_last_logon`, `customers_info_number_of_logons`, `customers_info_date_account_created`, `customers_info_date_account_last_modified`, `global_product_notifications`) VALUES ('6',NULL,'0','2014-11-02 22:13:39',NULL,'0');
INSERT INTO `customers_info` (`customers_info_id`, `customers_info_date_of_last_logon`, `customers_info_number_of_logons`, `customers_info_date_account_created`, `customers_info_date_account_last_modified`, `global_product_notifications`) VALUES ('7',NULL,'0','2014-11-03 09:37:55',NULL,'0');
INSERT INTO `customers_info` (`customers_info_id`, `customers_info_date_of_last_logon`, `customers_info_number_of_logons`, `customers_info_date_account_created`, `customers_info_date_account_last_modified`, `global_product_notifications`) VALUES ('8',NULL,'0','2014-11-03 10:17:12',NULL,'0');
INSERT INTO `customers_info` (`customers_info_id`, `customers_info_date_of_last_logon`, `customers_info_number_of_logons`, `customers_info_date_account_created`, `customers_info_date_account_last_modified`, `global_product_notifications`) VALUES ('9',NULL,'0','2014-11-03 12:02:39',NULL,'0');
/*!40000 ALTER TABLE `customers_info` ENABLE KEYS */;

DROP TABLE IF EXISTS `customers_ip`;
CREATE TABLE `customers_ip` (
  `customers_ip_id` int(11) NOT NULL AUTO_INCREMENT,
  `customers_id` int(11) NOT NULL DEFAULT '0',
  `customers_ip` varchar(39) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `customers_ip_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `customers_host` varchar(255) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `customers_advertiser` varchar(30) COLLATE latin1_german1_ci DEFAULT NULL,
  `customers_referer_url` varchar(255) COLLATE latin1_german1_ci DEFAULT NULL,
  PRIMARY KEY (`customers_ip_id`),
  KEY `customers_id` (`customers_id`)
) ENGINE=MyISAM AUTO_INCREMENT=167 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `customers_ip` DISABLE KEYS */;
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('1','1','91.63.253.24','2014-10-16 20:42:08','wandregal-online.de','','wandregal-online.de/_installer/install_finished.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('7','1','80.87.117.38','2014-10-17 08:49:39','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('6','1','2003:68:f69:6560:505:7ade:740d:b680','2014-10-16 23:16:36','','','wandregal-online.de/account.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('4','1','91.63.253.24','2014-10-16 22:41:26','wandregal-online.de','','wandregal-online.de/index.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('5','1','2003:68:f69:6560:505:7ade:740d:b680','2014-10-16 22:45:21','','','wandregal-online.de/account.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('8','3','2003:68:f42:a529:f1d5:215d:3bef:7bf8','2014-10-17 10:54:49','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('9','3','2003:68:f42:a529:f1d5:215d:3bef:7bf8','2014-10-17 10:56:43','wandregal-online.de','','wandregal-online.de/logoff.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('10','3','2003:68:f42:a529:f1d5:215d:3bef:7bf8','2014-10-17 10:59:07','wandregal-online.de','','wandregal-online.de/logoff.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('11','3','2003:68:f42:a529:f1d5:215d:3bef:7bf8','2014-10-17 11:43:22','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('12','1','2003:68:f42:a529:f1d5:215d:3bef:7bf8','2014-10-17 14:20:46','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('13','1','80.87.117.38','2014-10-17 14:36:57','wandregal-online.de','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('14','1','2003:68:f42:a529:f1d5:215d:3bef:7bf8','2014-10-17 16:47:15','','','wandregal-online.de/login.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('15','1','2003:68:f42:a529:3847:9241:f3f8:ac22','2014-10-18 10:39:19','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('16','3','2003:68:f42:a529:10b5:f205:151f:97e','2014-10-18 18:08:03','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('17','1','80.87.117.38','2014-10-20 16:59:47','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('18','3','2003:68:f42:a529:a1db:df45:67c4:a143','2014-10-20 19:17:16','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('19','1','2003:68:f42:a529:a1db:df45:67c4:a143','2014-10-20 19:21:42','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('20','1','93.196.251.75','2014-10-20 19:33:04','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('21','3','2003:68:f42:a529:a1db:df45:67c4:a143','2014-10-20 20:27:43','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('22','1','2003:68:f42:a529:d07b:3610:9895:9849','2014-10-20 22:54:01','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('23','1','2003:68:f42:a529:109:1386:e68c:dc32','2014-10-21 09:53:26','','','wandregal-online.de/index.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('24','1','2003:68:f42:a529:109:1386:e68c:dc32','2014-10-21 09:59:15','','','wandregal-online.de/index.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('25','1','2003:68:f42:a529:109:1386:e68c:dc32','2014-10-21 10:05:35','','','wandregal-online.de/index.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('26','1','2003:68:f42:a529:109:1386:e68c:dc32','2014-10-21 12:31:04','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('27','1','80.87.117.38','2014-10-21 12:49:11','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('28','1','2003:68:f42:a529:109:1386:e68c:dc32','2014-10-21 13:15:58','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('29','3','2003:68:f42:a529:109:1386:e68c:dc32','2014-10-21 13:38:26','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('30','1','2003:68:f42:a529:109:1386:e68c:dc32','2014-10-21 13:45:00','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('31','1','2003:68:f69:6575:7992:3036:2ad2:e4f3','2014-10-21 21:31:57','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('32','1','2003:68:f42:a529:61f8:b521:5421:7272','2014-10-22 16:08:00','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('33','3','2003:68:f42:a529:61f8:b521:5421:7272','2014-10-22 16:48:19','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('34','1','2003:68:f42:a529:61f8:b521:5421:7272','2014-10-22 17:14:59','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('35','1','2003:68:f42:a529:61f8:b521:5421:7272','2014-10-22 18:47:14','wandregal-online.de','','wandregal-online.de/logoff.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('36','1','2003:68:f42:a529:61f8:b521:5421:7272','2014-10-22 18:48:03','wandregal-online.de','','wandregal-online.de/logoff.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('37','1','2003:68:f69:6552:c980:84a2:c40e:5ee3','2014-10-22 18:48:42','wandregal-online.de','','wandregal-online.de/index.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('38','1','2003:68:f69:6552:c980:84a2:c40e:5ee3','2014-10-22 18:49:35','wandregal-online.de','','wandregal-online.de/logoff.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('39','1','2003:68:f42:a529:61f8:b521:5421:7272','2014-10-22 18:52:21','wandregal-online.de','','wandregal-online.de/logoff.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('40','1','2003:68:f42:a529:61f8:b521:5421:7272','2014-10-22 18:53:12','wandregal-online.de','','wandregal-online.de/logoff.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('41','1','2003:68:f42:a529:61f8:b521:5421:7272','2014-10-22 18:53:33','wandregal-online.de','','wandregal-online.de/logoff.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('42','1','2003:68:f42:a529:61f8:b521:5421:7272','2014-10-22 18:58:00','wandregal-online.de','','wandregal-online.de/logoff.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('43','1','2003:68:f42:a529:61f8:b521:5421:7272','2014-10-22 19:57:10','wandregal-online.de','','wandregal-online.de/logoff.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('44','1','2003:68:f69:6552:c980:84a2:c40e:5ee3','2014-10-22 20:17:33','wandregal-online.de','','wandregal-online.de/logoff.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('45','1','2003:68:f42:a529:61f8:b521:5421:7272','2014-10-22 20:18:59','wandregal-online.de','','wandregal-online.de/logoff.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('46','1','2003:68:f42:a529:61f8:b521:5421:7272','2014-10-22 20:20:39','wandregal-online.de','','wandregal-online.de/logoff.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('47','1','91.63.238.254','2014-10-22 20:50:05','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('48','3','2003:68:f42:a529:386c:8234:2093:62a1','2014-10-23 08:28:53','','','wandregal-online.de/login.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('49','3','2003:68:f42:a529:386c:8234:2093:62a1','2014-10-23 08:33:46','wandregal-online.de','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('50','3','2003:68:f42:a529:386c:8234:2093:62a1','2014-10-23 10:29:26','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('51','1','2003:68:f42:a529:c57:ab4f:1d6d:9bfb','2014-10-23 14:33:33','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('52','1','2003:68:f42:a529:7071:df40:921:b840','2014-10-24 10:19:40','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('53','1','2003:68:f42:a529:7071:df40:921:b840','2014-10-24 10:59:30','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('54','1','2003:68:f42:a529:7071:df40:921:b840','2014-10-24 11:07:04','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('55','1','2003:68:f42:a529:7071:df40:921:b840','2014-10-24 17:42:38','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('56','1','2003:68:f42:a529:7071:df40:921:b840','2014-10-24 20:25:38','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('57','1','80.133.109.176','2014-10-25 11:41:15','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('58','1','80.133.109.176','2014-10-25 11:50:17','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('59','1','80.133.109.176','2014-10-25 14:28:35','wandregal-online.de','','wandregal-online.de/logoff.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('60','1','80.133.109.176','2014-10-25 14:35:44','wandregal-online.de','','wandregal-online.de/shop_content.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('61','1','2003:68:f69:6554:21b4:3a88:2d7c:18f2','2014-10-25 17:45:12','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('62','1','2003:68:f69:6554:21b4:3a88:2d7c:18f2','2014-10-25 17:46:37','','','wandregal-online.de/index.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('63','1','2003:68:f42:a529:b43a:ff1f:cf64:2f76','2014-10-27 11:13:15','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('64','3','2003:68:f42:a529:b43a:ff1f:cf64:2f76','2014-10-27 11:44:40','wandregal-online.de','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('65','1','2003:68:f42:a529:b43a:ff1f:cf64:2f76','2014-10-27 11:45:53','','','wandregal-online.de/login.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('66','1','2003:68:f42:a529:b43a:ff1f:cf64:2f76','2014-10-27 12:40:19','','','wandregal-online.de/login.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('67','1','2003:68:f42:a529:7c26:648f:8153:d9d','2014-10-27 16:07:06','','','wandregal-online.de/login.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('68','1','80.87.117.38','2014-10-27 16:51:22','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('69','1','2003:68:f42:a529:7c26:648f:8153:d9d','2014-10-27 18:23:27','','','wandregal-online.de/login.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('70','1','2003:68:f42:a529:7c26:648f:8153:d9d','2014-10-27 18:43:20','','','wandregal-online.de/login.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('71','1','2003:68:f42:a529:7c26:648f:8153:d9d','2014-10-27 20:43:05','','','wandregal-online.de/login.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('72','3','2003:68:f42:a529:7c26:648f:8153:d9d','2014-10-27 20:46:05','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('73','1','2003:68:f42:a529:25a8:965d:de22:1e42','2014-10-28 08:33:53','','','wandregal-online.de/login.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('74','3','2003:68:f42:a529:25a8:965d:de22:1e42','2014-10-28 09:03:12','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('75','1','2003:68:f42:a529:25a8:965d:de22:1e42','2014-10-28 12:20:45','','','wandregal-online.de/login.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('76','1','80.133.97.215','2014-10-28 20:08:10','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('77','1','91.63.248.72','2014-10-29 07:54:11','wandregal-online.de','','wandregal-online.de/index.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('78','1','2003:68:f42:a529:f4ff:93cc:d539:d7f7','2014-10-29 12:03:18','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('79','1','2003:68:f42:a529:f4ff:93cc:d539:d7f7','2014-10-29 17:29:19','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('80','1','91.63.248.72','2014-10-29 19:56:23','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('81','1','91.63.237.131','2014-10-29 21:30:14','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('82','1','91.63.237.131','2014-10-29 22:35:44','wandregal-online.de','','wandregal-online.de/index.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('83','1','2003:68:f42:a529:7142:ce03:a87c:9bd','2014-10-30 11:50:28','','','wandregal-online.de/login.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('84','1','2003:68:f42:a529:7142:ce03:a87c:9bd','2014-10-30 16:07:54','wandregal-online.de','','wandregal-online.de/index.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('85','1','91.63.237.131','2014-10-30 19:08:46','wandregal-online.de','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('86','1','2003:68:f42:a529:7142:ce03:a87c:9bd','2014-10-30 20:29:48','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('87','1','2003:68:f69:6597:21d5:c7c7:4ddb:1fae','2014-10-30 21:56:07','','','wandregal-online.de/index.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('88','1','2003:68:f69:6597:21d5:c7c7:4ddb:1fae','2014-10-30 22:12:10','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('89','1','2003:68:f42:a529:4114:6d49:db3:f0ca','2014-10-31 09:20:47','','','wandregal-online.de/login.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('90','3','2003:68:f42:a529:4114:6d49:db3:f0ca','2014-10-31 09:27:26','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('91','1','2003:68:f42:a529:4114:6d49:db3:f0ca','2014-10-31 09:50:17','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('92','1','2003:68:f42:a529:4114:6d49:db3:f0ca','2014-10-31 14:11:53','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('93','3','2003:68:f42:a529:4114:6d49:db3:f0ca','2014-10-31 16:31:40','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('94','3','2003:68:f42:a529:c82c:7fa6:8f7f:9cbf','2014-11-01 09:03:51','','','wandregal-online.de/login.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('95','1','2003:68:f42:a529:c82c:7fa6:8f7f:9cbf','2014-11-01 09:50:56','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('96','1','2003:68:f42:a529:c82c:7fa6:8f7f:9cbf','2014-11-01 12:39:33','www.google.de','','www.google.de/url');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('97','3','2003:68:f42:a529:c82c:7fa6:8f7f:9cbf','2014-11-01 14:14:04','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('98','1','2003:68:f69:6592:544c:8a9f:b375:111a','2014-11-01 15:45:17','','','wandregal-online.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('99','1','2003:68:f69:6592:544c:8a9f:b375:111a','2014-11-01 17:01:04','','','fensterdichtungen.org/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('100','4','2003:5f:650d:66cf:51bc:8f08:3525:22a0','2014-11-01 17:41:43','','','fensterdichtungen.org/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('101','1','2003:68:f69:6592:d482:68e0:1840:1e8d','2014-11-01 18:12:51','www.google.de','','www.google.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('102','1','2003:68:f69:6592:39cf:48f6:9b99:165f','2014-11-01 18:36:28','','','fensterdichtungen.org/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('103','1','93.196.224.183','2014-11-01 18:56:09','fensterdichtungen.org','','fensterdichtungen.org/index.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('104','1','2003:68:f69:6592:500c:9873:8eee:8adc','2014-11-01 19:09:50','','','fensterdichtungen.org/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('105','1','2003:68:f69:6592:500c:9873:8eee:8adc','2014-11-01 19:22:57','webcache.googleusercontent.com','','webcache.googleusercontent.com/search');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('106','1','2003:68:f69:6592:500c:9873:8eee:8adc','2014-11-01 19:40:00','','','fensterdichtungen.org/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('107','1','2003:68:f69:6592:500c:9873:8eee:8adc','2014-11-01 20:34:44','','','fensterdichtungen.org/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('108','1','2003:68:f69:6592:500c:9873:8eee:8adc','2014-11-01 20:54:53','webcache.googleusercontent.com','','webcache.googleusercontent.com/search');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('109','1','80.187.109.68','2014-11-01 20:55:48','www.google.de','','www.google.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('110','1','2003:68:f69:6592:500c:9873:8eee:8adc','2014-11-01 21:13:43','','','fensterdichtungen.org/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('111','1','80.133.98.156','2014-11-01 21:19:42','','','fensterdichtungen.org/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('112','1','2003:68:f69:6502:500c:9873:8eee:8adc','2014-11-01 21:37:00','www.google.de','','www.google.de/url');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('113','1','2003:68:f69:6502:500c:9873:8eee:8adc','2014-11-01 21:41:19','','','fensterdichtungen.org/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('114','1','80.133.98.156','2014-11-01 21:54:42','','','fensterdichtungen.org/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('115','1','80.133.98.156','2014-11-01 22:52:34','','','fensterdichtungen.org/login.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('116','1','2003:68:f69:6502:500c:9873:8eee:8adc','2014-11-01 23:00:01','www.google.de','','www.google.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('117','1','80.133.98.156','2014-11-01 23:28:29','www.google.de','','www.google.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('118','4','2003:5f:650d:66cf:3881:e19e:12ed:b204','2014-11-02 09:10:12','','','fensterdichtungen.org/account_history_info.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('119','1','80.133.98.156','2014-11-02 15:40:53','','','fensterdichtungen.org/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('120','1','80.133.98.156','2014-11-02 15:43:36','fensterdichtungen.org','','fensterdichtungen.org/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('121','1','80.133.98.156','2014-11-02 15:45:26','fensterdichtungen.org','','fensterdichtungen.org/logoff.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('122','1','2003:68:f69:6502:b5ee:5536:8bfe:927a','2014-11-02 16:55:15','','','fensterdichtungen.org/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('123','1','2003:68:f69:6502:b5ee:5536:8bfe:927a','2014-11-02 16:57:58','www.google.de','','www.google.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('124','1','80.187.100.178','2014-11-02 18:18:23','','','fensterdichtungen.org/login.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('125','1','2003:68:f69:6502:b5ee:5536:8bfe:927a','2014-11-02 18:35:39','','','fensterdichtungen.org/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('126','1','80.133.98.156','2014-11-02 19:29:46','','','fensterdichtungen.org/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('127','5','85.178.134.35','2014-11-02 19:47:44','fensterdichtungen.org','','fensterdichtungen.org/product_info.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('128','1','80.133.98.156','2014-11-02 19:53:29','fensterdichtungen.org','','fensterdichtungen.org/logoff.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('129','1','80.133.98.156','2014-11-02 20:21:16','fensterdichtungen.org','','fensterdichtungen.org/logoff.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('130','1','2003:68:f69:6502:b5ee:5536:8bfe:927a','2014-11-02 20:49:56','','','fensterdichtungen.org/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('131','1','2003:68:f69:6525:b5ee:5536:8bfe:927a','2014-11-02 21:18:00','','','fensterdichtungen.org/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('132','6','88.72.206.64','2014-11-02 22:13:39','www.google.de','','www.google.de/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('133','1','2003:68:f69:6525:b5ee:5536:8bfe:927a','2014-11-02 23:03:16','','','fensterdichtungen.org/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('134','1','2003:68:f69:6525:b5ee:5536:8bfe:927a','2014-11-02 23:05:14','','','fensterdichtungen.org/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('135','1','91.63.249.115','2014-11-02 23:10:15','fensterdichtungen.org','','fensterdichtungen.org/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('136','1','91.63.249.115','2014-11-02 23:10:28','fensterdichtungen.org','','fensterdichtungen.org/logoff.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('137','1','91.63.249.115','2014-11-02 23:55:53','fensterdichtungen.org','','fensterdichtungen.org/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('138','1','2003:68:f69:6525:b58d:835b:472e:a466','2014-11-02 23:58:51','','','fensterdichtungen.org/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('139','1','2003:68:f42:a529:4d3d:2afc:58bd:4928','2014-11-03 07:29:52','','','fensterdichtungen.org/index.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('140','1','2003:68:f42:a529:4d3d:2afc:58bd:4928','2014-11-03 07:34:47','webcache.googleusercontent.com','','webcache.googleusercontent.com/search');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('141','1','2003:68:f42:a529:4d3d:2afc:58bd:4928','2014-11-03 07:40:21','','','fensterdichtungen.org/index.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('142','1','2003:68:f42:a529:4d3d:2afc:58bd:4928','2014-11-03 07:41:26','www.google.de','','www.google.de/url');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('143','1','80.87.117.38','2014-11-03 08:45:35','','','fensterdichtungen.org/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('144','1','80.87.117.38','2014-11-03 08:57:17','fensterdichtungen.org','','fensterdichtungen.org/logoff.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('145','1','80.87.117.38','2014-11-03 09:20:59','','','fensterdichtungen.org/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('146','1','80.154.98.131','2014-11-03 09:27:58','www.google.de','','www.google.de/url');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('147','7','91.67.102.199','2014-11-03 09:37:55','','','fensterdichtungen.org/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('148','1','2003:68:f42:a529:4d3d:2afc:58bd:4928','2014-11-03 09:43:26','','','fensterdichtungen.org/index.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('149','1','80.154.98.131','2014-11-03 10:15:01','www.google.de','','www.google.de/url');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('150','8','109.192.173.178','2014-11-03 10:17:12','www.google.de','','www.google.de/url');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('151','1','80.154.98.131','2014-11-03 10:46:18','','','fensterdichtungen.org/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('152','1','80.154.98.131','2014-11-03 11:00:06','','','fensterdichtungen.org/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('153','1','80.154.98.131','2014-11-03 11:15:35','fensterdichtungen.org','','fensterdichtungen.org/logoff.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('154','9','77.20.248.26','2014-11-03 12:02:39','','','fensterdichtungen.org/print_order.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('155','1','80.154.98.131','2014-11-03 12:12:24','','','fensterdichtungen.org/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('156','1','80.154.98.131','2014-11-03 12:28:31','fensterdichtungen.org','','fensterdichtungen.org/logoff.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('157','1','80.154.98.131','2014-11-03 12:33:46','fensterdichtungen.org','','fensterdichtungen.org/admin/configuration.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('158','1','80.154.98.131','2014-11-03 12:37:28','fensterdichtungen.org','','fensterdichtungen.org/logoff.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('159','1','80.154.98.131','2014-11-03 12:44:25','fensterdichtungen.org','','fensterdichtungen.org/logoff.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('160','1','80.154.98.131','2014-11-03 13:05:00','fensterdichtungen.org','','fensterdichtungen.org/logoff.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('161','1','80.154.98.131','2014-11-03 13:18:04','fensterdichtungen.org','','fensterdichtungen.org/logoff.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('162','1','80.87.117.38','2014-11-03 13:27:24','','','fensterdichtungen.org/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('163','1','80.187.100.183','2014-11-03 14:07:15','','','fensterdichtungen.org/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('164','1','80.154.98.131','2014-11-03 14:07:41','','','fensterdichtungen.org/');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('165','1','80.154.98.131','2014-11-03 14:27:19','fensterdichtungen.org','','fensterdichtungen.org/logoff.php');
INSERT INTO `customers_ip` (`customers_ip_id`, `customers_id`, `customers_ip`, `customers_ip_date`, `customers_host`, `customers_advertiser`, `customers_referer_url`) VALUES ('166','1','80.87.117.38','2014-11-03 14:33:25','fensterdichtungen.org','','fensterdichtungen.org/logoff.php');
/*!40000 ALTER TABLE `customers_ip` ENABLE KEYS */;

DROP TABLE IF EXISTS `customers_memo`;
CREATE TABLE `customers_memo` (
  `memo_id` int(11) NOT NULL AUTO_INCREMENT,
  `customers_id` int(11) NOT NULL DEFAULT '0',
  `memo_date` date NOT NULL DEFAULT '0000-00-00',
  `memo_title` text COLLATE latin1_german1_ci NOT NULL,
  `memo_text` text COLLATE latin1_german1_ci NOT NULL,
  `poster_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`memo_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `customers_memo` DISABLE KEYS */;
/*!40000 ALTER TABLE `customers_memo` ENABLE KEYS */;

DROP TABLE IF EXISTS `customers_status`;
CREATE TABLE `customers_status` (
  `customers_status_id` int(11) NOT NULL DEFAULT '0',
  `language_id` tinyint(4) NOT NULL DEFAULT '1',
  `customers_status_name` varchar(32) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `customers_status_public` int(1) NOT NULL DEFAULT '1',
  `customers_status_min_order` int(7) DEFAULT NULL,
  `customers_status_max_order` int(7) DEFAULT NULL,
  `customers_status_image` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `customers_status_discount` decimal(4,2) DEFAULT '0.00',
  `customers_status_ot_discount_flag` char(1) COLLATE latin1_german1_ci NOT NULL DEFAULT '0',
  `customers_status_ot_discount` decimal(4,2) DEFAULT '0.00',
  `customers_status_graduated_prices` varchar(1) COLLATE latin1_german1_ci NOT NULL DEFAULT '0',
  `customers_status_show_price` int(1) NOT NULL DEFAULT '1',
  `customers_status_show_price_tax` int(1) NOT NULL DEFAULT '1',
  `customers_status_add_tax_ot` int(1) NOT NULL DEFAULT '0',
  `customers_status_payment_unallowed` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `customers_status_shipping_unallowed` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `customers_status_discount_attributes` int(1) NOT NULL DEFAULT '0',
  `customers_fsk18` int(1) NOT NULL DEFAULT '1',
  `customers_fsk18_display` int(1) NOT NULL DEFAULT '1',
  `customers_status_write_reviews` int(1) NOT NULL DEFAULT '1',
  `customers_status_read_reviews` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`customers_status_id`,`language_id`),
  KEY `idx_orders_status_name` (`customers_status_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `customers_status` DISABLE KEYS */;
INSERT INTO `customers_status` (`customers_status_id`, `language_id`, `customers_status_name`, `customers_status_public`, `customers_status_min_order`, `customers_status_max_order`, `customers_status_image`, `customers_status_discount`, `customers_status_ot_discount_flag`, `customers_status_ot_discount`, `customers_status_graduated_prices`, `customers_status_show_price`, `customers_status_show_price_tax`, `customers_status_add_tax_ot`, `customers_status_payment_unallowed`, `customers_status_shipping_unallowed`, `customers_status_discount_attributes`, `customers_fsk18`, `customers_fsk18_display`, `customers_status_write_reviews`, `customers_status_read_reviews`) VALUES ('0','2','Admin','1',NULL,NULL,'admin_status.gif','0.00','1','0.00','1','1','1','0','','','0','1','1','1','1');
INSERT INTO `customers_status` (`customers_status_id`, `language_id`, `customers_status_name`, `customers_status_public`, `customers_status_min_order`, `customers_status_max_order`, `customers_status_image`, `customers_status_discount`, `customers_status_ot_discount_flag`, `customers_status_ot_discount`, `customers_status_graduated_prices`, `customers_status_show_price`, `customers_status_show_price_tax`, `customers_status_add_tax_ot`, `customers_status_payment_unallowed`, `customers_status_shipping_unallowed`, `customers_status_discount_attributes`, `customers_fsk18`, `customers_fsk18_display`, `customers_status_write_reviews`, `customers_status_read_reviews`) VALUES ('0','1','Admin','1',NULL,NULL,'admin_status.gif','0.00','1','0.00','1','1','1','0','','','0','1','1','1','1');
INSERT INTO `customers_status` (`customers_status_id`, `language_id`, `customers_status_name`, `customers_status_public`, `customers_status_min_order`, `customers_status_max_order`, `customers_status_image`, `customers_status_discount`, `customers_status_ot_discount_flag`, `customers_status_ot_discount`, `customers_status_graduated_prices`, `customers_status_show_price`, `customers_status_show_price_tax`, `customers_status_add_tax_ot`, `customers_status_payment_unallowed`, `customers_status_shipping_unallowed`, `customers_status_discount_attributes`, `customers_fsk18`, `customers_fsk18_display`, `customers_status_write_reviews`, `customers_status_read_reviews`) VALUES ('1','2','Gast','1',NULL,NULL,'guest_status.gif','0.00','0','0.00','0','1','1','0','','','0','1','1','0','1');
INSERT INTO `customers_status` (`customers_status_id`, `language_id`, `customers_status_name`, `customers_status_public`, `customers_status_min_order`, `customers_status_max_order`, `customers_status_image`, `customers_status_discount`, `customers_status_ot_discount_flag`, `customers_status_ot_discount`, `customers_status_graduated_prices`, `customers_status_show_price`, `customers_status_show_price_tax`, `customers_status_add_tax_ot`, `customers_status_payment_unallowed`, `customers_status_shipping_unallowed`, `customers_status_discount_attributes`, `customers_fsk18`, `customers_fsk18_display`, `customers_status_write_reviews`, `customers_status_read_reviews`) VALUES ('1','1','Guest','1',NULL,NULL,'guest_status.gif','0.00','0','0.00','0','1','1','0','','','0','1','1','0','1');
INSERT INTO `customers_status` (`customers_status_id`, `language_id`, `customers_status_name`, `customers_status_public`, `customers_status_min_order`, `customers_status_max_order`, `customers_status_image`, `customers_status_discount`, `customers_status_ot_discount_flag`, `customers_status_ot_discount`, `customers_status_graduated_prices`, `customers_status_show_price`, `customers_status_show_price_tax`, `customers_status_add_tax_ot`, `customers_status_payment_unallowed`, `customers_status_shipping_unallowed`, `customers_status_discount_attributes`, `customers_fsk18`, `customers_fsk18_display`, `customers_status_write_reviews`, `customers_status_read_reviews`) VALUES ('2','2','Neuer Kunde','1',NULL,NULL,'customer_status.gif','0.00','0','0.00','1','1','1','0','','','0','1','1','1','1');
INSERT INTO `customers_status` (`customers_status_id`, `language_id`, `customers_status_name`, `customers_status_public`, `customers_status_min_order`, `customers_status_max_order`, `customers_status_image`, `customers_status_discount`, `customers_status_ot_discount_flag`, `customers_status_ot_discount`, `customers_status_graduated_prices`, `customers_status_show_price`, `customers_status_show_price_tax`, `customers_status_add_tax_ot`, `customers_status_payment_unallowed`, `customers_status_shipping_unallowed`, `customers_status_discount_attributes`, `customers_fsk18`, `customers_fsk18_display`, `customers_status_write_reviews`, `customers_status_read_reviews`) VALUES ('2','1','New Customer','1',NULL,NULL,'customer_status.gif','0.00','0','0.00','1','1','1','0','','','0','1','1','1','1');
INSERT INTO `customers_status` (`customers_status_id`, `language_id`, `customers_status_name`, `customers_status_public`, `customers_status_min_order`, `customers_status_max_order`, `customers_status_image`, `customers_status_discount`, `customers_status_ot_discount_flag`, `customers_status_ot_discount`, `customers_status_graduated_prices`, `customers_status_show_price`, `customers_status_show_price_tax`, `customers_status_add_tax_ot`, `customers_status_payment_unallowed`, `customers_status_shipping_unallowed`, `customers_status_discount_attributes`, `customers_fsk18`, `customers_fsk18_display`, `customers_status_write_reviews`, `customers_status_read_reviews`) VALUES ('3','2','H&auml;ndler','1',NULL,NULL,'merchant_status.gif','0.00','0','0.00','1','1','0','1','','','0','1','1','1','1');
INSERT INTO `customers_status` (`customers_status_id`, `language_id`, `customers_status_name`, `customers_status_public`, `customers_status_min_order`, `customers_status_max_order`, `customers_status_image`, `customers_status_discount`, `customers_status_ot_discount_flag`, `customers_status_ot_discount`, `customers_status_graduated_prices`, `customers_status_show_price`, `customers_status_show_price_tax`, `customers_status_add_tax_ot`, `customers_status_payment_unallowed`, `customers_status_shipping_unallowed`, `customers_status_discount_attributes`, `customers_fsk18`, `customers_fsk18_display`, `customers_status_write_reviews`, `customers_status_read_reviews`) VALUES ('3','1','Merchant','1',NULL,NULL,'merchant_status.gif','0.00','0','0.00','1','1','0','1','','','0','1','1','1','1');
/*!40000 ALTER TABLE `customers_status` ENABLE KEYS */;

DROP TABLE IF EXISTS `customers_status_history`;
CREATE TABLE `customers_status_history` (
  `customers_status_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `customers_id` int(11) NOT NULL DEFAULT '0',
  `new_value` int(5) NOT NULL DEFAULT '0',
  `old_value` int(5) DEFAULT NULL,
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `customer_notified` int(1) DEFAULT '0',
  PRIMARY KEY (`customers_status_history_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `customers_status_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `customers_status_history` ENABLE KEYS */;

DROP TABLE IF EXISTS `database_version`;
CREATE TABLE `database_version` (
  `version` varchar(32) COLLATE latin1_german1_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `database_version` DISABLE KEYS */;
INSERT INTO `database_version` (`version`) VALUES ('MOD_1.0.6.0');
/*!40000 ALTER TABLE `database_version` ENABLE KEYS */;

DROP TABLE IF EXISTS `geo_zones`;
CREATE TABLE `geo_zones` (
  `geo_zone_id` int(11) NOT NULL AUTO_INCREMENT,
  `geo_zone_name` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `geo_zone_description` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `last_modified` datetime DEFAULT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`geo_zone_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `geo_zones` DISABLE KEYS */;
INSERT INTO `geo_zones` (`geo_zone_id`, `geo_zone_name`, `geo_zone_description`, `last_modified`, `date_added`) VALUES ('6','Steuerzone EU-Ausland','','0000-00-00 00:00:00','2014-10-16 20:38:36');
INSERT INTO `geo_zones` (`geo_zone_id`, `geo_zone_name`, `geo_zone_description`, `last_modified`, `date_added`) VALUES ('5','Steuerzone EU','Steuerzone f&uuml;r die EU','0000-00-00 00:00:00','2014-10-16 20:38:36');
INSERT INTO `geo_zones` (`geo_zone_id`, `geo_zone_name`, `geo_zone_description`, `last_modified`, `date_added`) VALUES ('7','Steuerzone B2B','',NULL,'2014-10-16 20:38:36');
/*!40000 ALTER TABLE `geo_zones` ENABLE KEYS */;

DROP TABLE IF EXISTS `languages`;
CREATE TABLE `languages` (
  `languages_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `code` char(5) COLLATE latin1_german1_ci NOT NULL,
  `image` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `directory` varchar(32) COLLATE latin1_german1_ci DEFAULT NULL,
  `sort_order` int(3) DEFAULT NULL,
  `language_charset` text COLLATE latin1_german1_ci NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`languages_id`),
  KEY `idx_languages_name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `languages` DISABLE KEYS */;
INSERT INTO `languages` (`languages_id`, `name`, `code`, `image`, `directory`, `sort_order`, `language_charset`, `status`) VALUES ('1','English','en','icon.gif','english','2','iso-8859-15','0');
INSERT INTO `languages` (`languages_id`, `name`, `code`, `image`, `directory`, `sort_order`, `language_charset`, `status`) VALUES ('2','Deutsch','de','icon.gif','german','1','iso-8859-15','1');
/*!40000 ALTER TABLE `languages` ENABLE KEYS */;

DROP TABLE IF EXISTS `manufacturers`;
CREATE TABLE `manufacturers` (
  `manufacturers_id` int(11) NOT NULL AUTO_INCREMENT,
  `manufacturers_name` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `manufacturers_image` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`manufacturers_id`),
  KEY `idx_manufacturers_name` (`manufacturers_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `manufacturers` DISABLE KEYS */;
/*!40000 ALTER TABLE `manufacturers` ENABLE KEYS */;

DROP TABLE IF EXISTS `manufacturers_info`;
CREATE TABLE `manufacturers_info` (
  `manufacturers_id` int(11) NOT NULL,
  `languages_id` int(11) NOT NULL,
  `manufacturers_meta_title` varchar(100) COLLATE latin1_german1_ci NOT NULL,
  `manufacturers_meta_description` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `manufacturers_meta_keywords` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `manufacturers_url` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `url_clicked` int(5) NOT NULL DEFAULT '0',
  `date_last_click` datetime DEFAULT NULL,
  PRIMARY KEY (`manufacturers_id`,`languages_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `manufacturers_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `manufacturers_info` ENABLE KEYS */;

DROP TABLE IF EXISTS `media_content`;
CREATE TABLE `media_content` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `old_filename` text COLLATE latin1_german1_ci NOT NULL,
  `new_filename` text COLLATE latin1_german1_ci NOT NULL,
  `file_comment` text COLLATE latin1_german1_ci NOT NULL,
  PRIMARY KEY (`file_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `media_content` DISABLE KEYS */;
/*!40000 ALTER TABLE `media_content` ENABLE KEYS */;

DROP TABLE IF EXISTS `module_newsletter`;
CREATE TABLE `module_newsletter` (
  `newsletter_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text COLLATE latin1_german1_ci NOT NULL,
  `bc` text COLLATE latin1_german1_ci NOT NULL,
  `cc` text COLLATE latin1_german1_ci NOT NULL,
  `date` datetime DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `body` text COLLATE latin1_german1_ci NOT NULL,
  PRIMARY KEY (`newsletter_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `module_newsletter` DISABLE KEYS */;
/*!40000 ALTER TABLE `module_newsletter` ENABLE KEYS */;

DROP TABLE IF EXISTS `newsletter_recipients`;
CREATE TABLE `newsletter_recipients` (
  `mail_id` int(11) NOT NULL AUTO_INCREMENT,
  `customers_email_address` varchar(96) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `customers_id` int(11) NOT NULL DEFAULT '0',
  `customers_status` int(5) NOT NULL DEFAULT '0',
  `customers_firstname` varchar(64) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `customers_lastname` varchar(64) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `mail_status` int(1) NOT NULL DEFAULT '0',
  `mail_key` varchar(32) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`mail_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `newsletter_recipients` DISABLE KEYS */;
INSERT INTO `newsletter_recipients` (`mail_id`, `customers_email_address`, `customers_id`, `customers_status`, `customers_firstname`, `customers_lastname`, `mail_status`, `mail_key`, `date_added`) VALUES ('1','konrad.bremer@htp-tel.de','9','1','konrad','Bremer','0','8X38YP5HV98ZNNU2XGFHVT66GQX43HZS','2014-11-03 12:02:40');
/*!40000 ALTER TABLE `newsletter_recipients` ENABLE KEYS */;

DROP TABLE IF EXISTS `newsletters`;
CREATE TABLE `newsletters` (
  `newsletters_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `content` text COLLATE latin1_german1_ci NOT NULL,
  `module` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `date_added` datetime NOT NULL,
  `date_sent` datetime DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `locked` int(1) DEFAULT '0',
  PRIMARY KEY (`newsletters_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `newsletters` DISABLE KEYS */;
/*!40000 ALTER TABLE `newsletters` ENABLE KEYS */;

DROP TABLE IF EXISTS `newsletters_history`;
CREATE TABLE `newsletters_history` (
  `news_hist_id` int(11) NOT NULL DEFAULT '0',
  `news_hist_cs` int(11) NOT NULL DEFAULT '0',
  `news_hist_cs_date_sent` date DEFAULT NULL,
  PRIMARY KEY (`news_hist_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `newsletters_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `newsletters_history` ENABLE KEYS */;

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `orders_id` int(11) NOT NULL AUTO_INCREMENT,
  `customers_id` int(11) NOT NULL,
  `customers_cid` varchar(32) COLLATE latin1_german1_ci DEFAULT NULL,
  `customers_vat_id` varchar(20) COLLATE latin1_german1_ci DEFAULT NULL,
  `customers_status` int(11) DEFAULT NULL,
  `customers_status_name` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `customers_status_image` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `customers_status_discount` decimal(4,2) DEFAULT NULL,
  `customers_name` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `customers_firstname` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `customers_lastname` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `customers_company` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `customers_street_address` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `customers_suburb` varchar(32) COLLATE latin1_german1_ci DEFAULT NULL,
  `customers_city` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `customers_postcode` varchar(10) COLLATE latin1_german1_ci NOT NULL,
  `customers_state` varchar(32) COLLATE latin1_german1_ci DEFAULT NULL,
  `customers_country` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `customers_telephone` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `customers_email_address` varchar(96) COLLATE latin1_german1_ci NOT NULL,
  `customers_address_format_id` int(5) NOT NULL,
  `delivery_name` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `delivery_firstname` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `delivery_lastname` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `delivery_company` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `delivery_street_address` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `delivery_suburb` varchar(32) COLLATE latin1_german1_ci DEFAULT NULL,
  `delivery_city` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `delivery_postcode` varchar(10) COLLATE latin1_german1_ci NOT NULL,
  `delivery_state` varchar(32) COLLATE latin1_german1_ci DEFAULT NULL,
  `delivery_country` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `delivery_country_iso_code_2` char(2) COLLATE latin1_german1_ci NOT NULL,
  `delivery_address_format_id` int(5) NOT NULL,
  `billing_name` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `billing_firstname` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `billing_lastname` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `billing_company` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `billing_street_address` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `billing_suburb` varchar(32) COLLATE latin1_german1_ci DEFAULT NULL,
  `billing_city` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `billing_postcode` varchar(10) COLLATE latin1_german1_ci NOT NULL,
  `billing_state` varchar(32) COLLATE latin1_german1_ci DEFAULT NULL,
  `billing_country` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `billing_country_iso_code_2` char(2) COLLATE latin1_german1_ci NOT NULL,
  `billing_address_format_id` int(5) NOT NULL,
  `payment_method` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `cc_type` varchar(20) COLLATE latin1_german1_ci DEFAULT NULL,
  `cc_owner` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `cc_number` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `cc_expires` varchar(4) COLLATE latin1_german1_ci DEFAULT NULL,
  `cc_start` varchar(4) COLLATE latin1_german1_ci DEFAULT NULL,
  `cc_issue` varchar(3) COLLATE latin1_german1_ci DEFAULT NULL,
  `cc_cvv` varchar(4) COLLATE latin1_german1_ci DEFAULT NULL,
  `comments` text COLLATE latin1_german1_ci,
  `last_modified` datetime DEFAULT NULL,
  `date_purchased` datetime DEFAULT NULL,
  `orders_status` int(5) NOT NULL,
  `orders_date_finished` datetime DEFAULT NULL,
  `currency` char(3) COLLATE latin1_german1_ci DEFAULT NULL,
  `currency_value` decimal(14,6) DEFAULT NULL,
  `account_type` int(1) NOT NULL DEFAULT '0',
  `payment_class` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `shipping_method` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `shipping_class` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `customers_ip` varchar(39) COLLATE latin1_german1_ci NOT NULL,
  `language` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `afterbuy_success` int(1) NOT NULL DEFAULT '0',
  `afterbuy_id` int(32) NOT NULL DEFAULT '0',
  `refferers_id` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `conversion_type` int(1) NOT NULL DEFAULT '0',
  `orders_ident_key` varchar(128) COLLATE latin1_german1_ci DEFAULT NULL,
  `ibn_billnr` varchar(32) COLLATE latin1_german1_ci DEFAULT '',
  `ibn_billdate` date NOT NULL,
  PRIMARY KEY (`orders_id`),
  KEY `idx_customers_id` (`customers_id`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` (`orders_id`, `customers_id`, `customers_cid`, `customers_vat_id`, `customers_status`, `customers_status_name`, `customers_status_image`, `customers_status_discount`, `customers_name`, `customers_firstname`, `customers_lastname`, `customers_company`, `customers_street_address`, `customers_suburb`, `customers_city`, `customers_postcode`, `customers_state`, `customers_country`, `customers_telephone`, `customers_email_address`, `customers_address_format_id`, `delivery_name`, `delivery_firstname`, `delivery_lastname`, `delivery_company`, `delivery_street_address`, `delivery_suburb`, `delivery_city`, `delivery_postcode`, `delivery_state`, `delivery_country`, `delivery_country_iso_code_2`, `delivery_address_format_id`, `billing_name`, `billing_firstname`, `billing_lastname`, `billing_company`, `billing_street_address`, `billing_suburb`, `billing_city`, `billing_postcode`, `billing_state`, `billing_country`, `billing_country_iso_code_2`, `billing_address_format_id`, `payment_method`, `cc_type`, `cc_owner`, `cc_number`, `cc_expires`, `cc_start`, `cc_issue`, `cc_cvv`, `comments`, `last_modified`, `date_purchased`, `orders_status`, `orders_date_finished`, `currency`, `currency_value`, `account_type`, `payment_class`, `shipping_method`, `shipping_class`, `customers_ip`, `language`, `afterbuy_success`, `afterbuy_id`, `refferers_id`, `conversion_type`, `orders_ident_key`, `ibn_billnr`, `ibn_billdate`) VALUES ('25','4','','','2','Neuer Kunde','customer_status.gif','0.00','Bernhard Dietzel','Bernhard','Dietzel','','Am Sandweg 11','','Tiefenort','36469','','Germany','03695825457','BDietzel@t-online.de','5','Bernhard Dietzel','Bernhard','Dietzel','','Am Sandweg 11','','Tiefenort','36469','','Germany','DE','5','Bernhard Dietzel','Bernhard','Dietzel','','Am Sandweg 11','','Tiefenort','36469','','Germany','DE','5','paypal_ipn','','','','','','','','','2014-11-01 19:33:50','2014-11-01 17:43:08','2',NULL,'EUR','1.000000','0','paypal_ipn','Tabellarische Versandkosten (Bes','table_table','2003:5f:650d:66cf:51bc:8f08:3525:22a0','german','0','0','','1',NULL,'','0000-00-00');
INSERT INTO `orders` (`orders_id`, `customers_id`, `customers_cid`, `customers_vat_id`, `customers_status`, `customers_status_name`, `customers_status_image`, `customers_status_discount`, `customers_name`, `customers_firstname`, `customers_lastname`, `customers_company`, `customers_street_address`, `customers_suburb`, `customers_city`, `customers_postcode`, `customers_state`, `customers_country`, `customers_telephone`, `customers_email_address`, `customers_address_format_id`, `delivery_name`, `delivery_firstname`, `delivery_lastname`, `delivery_company`, `delivery_street_address`, `delivery_suburb`, `delivery_city`, `delivery_postcode`, `delivery_state`, `delivery_country`, `delivery_country_iso_code_2`, `delivery_address_format_id`, `billing_name`, `billing_firstname`, `billing_lastname`, `billing_company`, `billing_street_address`, `billing_suburb`, `billing_city`, `billing_postcode`, `billing_state`, `billing_country`, `billing_country_iso_code_2`, `billing_address_format_id`, `payment_method`, `cc_type`, `cc_owner`, `cc_number`, `cc_expires`, `cc_start`, `cc_issue`, `cc_cvv`, `comments`, `last_modified`, `date_purchased`, `orders_status`, `orders_date_finished`, `currency`, `currency_value`, `account_type`, `payment_class`, `shipping_method`, `shipping_class`, `customers_ip`, `language`, `afterbuy_success`, `afterbuy_id`, `refferers_id`, `conversion_type`, `orders_ident_key`, `ibn_billnr`, `ibn_billdate`) VALUES ('30','5','','','2','Neuer Kunde','customer_status.gif','0.00','Ulf Jakubke','Ulf','Jakubke','','Sakrower Landstraße 41','','Berlin','14089','','Germany','03066307531','ulf.jakubke@halja.de','5','Ulf Jakubke','Ulf','Jakubke','','Sakrower Landstraße 41','','Berlin','14089','','Germany','DE','5','Ulf Jakubke','Ulf','Jakubke','','Sakrower Landstraße 41','','Berlin','14089','','Germany','DE','5','paypal_ipn','','','','','','','','',NULL,'2014-11-02 19:49:00','1',NULL,'EUR','1.000000','0','paypal_ipn','Tabellarische Versandkosten (Bes','table_table','85.178.134.35','german','0','0','','1',NULL,'','0000-00-00');
INSERT INTO `orders` (`orders_id`, `customers_id`, `customers_cid`, `customers_vat_id`, `customers_status`, `customers_status_name`, `customers_status_image`, `customers_status_discount`, `customers_name`, `customers_firstname`, `customers_lastname`, `customers_company`, `customers_street_address`, `customers_suburb`, `customers_city`, `customers_postcode`, `customers_state`, `customers_country`, `customers_telephone`, `customers_email_address`, `customers_address_format_id`, `delivery_name`, `delivery_firstname`, `delivery_lastname`, `delivery_company`, `delivery_street_address`, `delivery_suburb`, `delivery_city`, `delivery_postcode`, `delivery_state`, `delivery_country`, `delivery_country_iso_code_2`, `delivery_address_format_id`, `billing_name`, `billing_firstname`, `billing_lastname`, `billing_company`, `billing_street_address`, `billing_suburb`, `billing_city`, `billing_postcode`, `billing_state`, `billing_country`, `billing_country_iso_code_2`, `billing_address_format_id`, `payment_method`, `cc_type`, `cc_owner`, `cc_number`, `cc_expires`, `cc_start`, `cc_issue`, `cc_cvv`, `comments`, `last_modified`, `date_purchased`, `orders_status`, `orders_date_finished`, `currency`, `currency_value`, `account_type`, `payment_class`, `shipping_method`, `shipping_class`, `customers_ip`, `language`, `afterbuy_success`, `afterbuy_id`, `refferers_id`, `conversion_type`, `orders_ident_key`, `ibn_billnr`, `ibn_billdate`) VALUES ('31','6','','','2','Neuer Kunde','customer_status.gif','0.00','Frank Mladek','Frank','Mladek','','Wupperstraße 25','','Oranienburg','16515','','Germany','03301-204432','fmladek@aol.com','5','Frank Mladek','Frank','Mladek','','Wupperstraße 25','','Oranienburg','16515','','Germany','DE','5','Frank Mladek','Frank','Mladek','','Wupperstraße 25','','Oranienburg','16515','','Germany','DE','5','eustandardtransfer','','','','','','','','',NULL,'2014-11-02 22:15:12','1',NULL,'EUR','1.000000','0','eustandardtransfer','Tabellarische Versandkosten (Bes','table_table','88.72.206.64','german','0','0','','1',NULL,'','0000-00-00');
INSERT INTO `orders` (`orders_id`, `customers_id`, `customers_cid`, `customers_vat_id`, `customers_status`, `customers_status_name`, `customers_status_image`, `customers_status_discount`, `customers_name`, `customers_firstname`, `customers_lastname`, `customers_company`, `customers_street_address`, `customers_suburb`, `customers_city`, `customers_postcode`, `customers_state`, `customers_country`, `customers_telephone`, `customers_email_address`, `customers_address_format_id`, `delivery_name`, `delivery_firstname`, `delivery_lastname`, `delivery_company`, `delivery_street_address`, `delivery_suburb`, `delivery_city`, `delivery_postcode`, `delivery_state`, `delivery_country`, `delivery_country_iso_code_2`, `delivery_address_format_id`, `billing_name`, `billing_firstname`, `billing_lastname`, `billing_company`, `billing_street_address`, `billing_suburb`, `billing_city`, `billing_postcode`, `billing_state`, `billing_country`, `billing_country_iso_code_2`, `billing_address_format_id`, `payment_method`, `cc_type`, `cc_owner`, `cc_number`, `cc_expires`, `cc_start`, `cc_issue`, `cc_cvv`, `comments`, `last_modified`, `date_purchased`, `orders_status`, `orders_date_finished`, `currency`, `currency_value`, `account_type`, `payment_class`, `shipping_method`, `shipping_class`, `customers_ip`, `language`, `afterbuy_success`, `afterbuy_id`, `refferers_id`, `conversion_type`, `orders_ident_key`, `ibn_billnr`, `ibn_billdate`) VALUES ('32','8','','','2','Neuer Kunde','customer_status.gif','0.00','willi kröner','willi','kröner','','keglerstr. 22','','giengen','89537','','Germany','07322 21698','willi.kroener@gmx.de','5','willi kröner','willi','kröner','','keglerstr. 22','','giengen','89537','','Germany','DE','5','willi kröner','willi','kröner','','keglerstr. 22','','giengen','89537','','Germany','DE','5','eustandardtransfer','','','','','','','','',NULL,'2014-11-03 10:20:15','1',NULL,'EUR','1.000000','0','eustandardtransfer','Tabellarische Versandkosten (Bes','table_table','109.192.173.178','german','0','0','','1',NULL,'','0000-00-00');
INSERT INTO `orders` (`orders_id`, `customers_id`, `customers_cid`, `customers_vat_id`, `customers_status`, `customers_status_name`, `customers_status_image`, `customers_status_discount`, `customers_name`, `customers_firstname`, `customers_lastname`, `customers_company`, `customers_street_address`, `customers_suburb`, `customers_city`, `customers_postcode`, `customers_state`, `customers_country`, `customers_telephone`, `customers_email_address`, `customers_address_format_id`, `delivery_name`, `delivery_firstname`, `delivery_lastname`, `delivery_company`, `delivery_street_address`, `delivery_suburb`, `delivery_city`, `delivery_postcode`, `delivery_state`, `delivery_country`, `delivery_country_iso_code_2`, `delivery_address_format_id`, `billing_name`, `billing_firstname`, `billing_lastname`, `billing_company`, `billing_street_address`, `billing_suburb`, `billing_city`, `billing_postcode`, `billing_state`, `billing_country`, `billing_country_iso_code_2`, `billing_address_format_id`, `payment_method`, `cc_type`, `cc_owner`, `cc_number`, `cc_expires`, `cc_start`, `cc_issue`, `cc_cvv`, `comments`, `last_modified`, `date_purchased`, `orders_status`, `orders_date_finished`, `currency`, `currency_value`, `account_type`, `payment_class`, `shipping_method`, `shipping_class`, `customers_ip`, `language`, `afterbuy_success`, `afterbuy_id`, `refferers_id`, `conversion_type`, `orders_ident_key`, `ibn_billnr`, `ibn_billdate`) VALUES ('33','9','','','2','Neuer Kunde','customer_status.gif','0.00','konrad Bremer','konrad','Bremer','','Ringelnatzweg 1','','Seelze','30926','','Germany','0511 401092','konrad.bremer@htp-tel.de','5','konrad Bremer','konrad','Bremer','','Ringelnatzweg 1','','Seelze','30926','','Germany','DE','5','konrad Bremer','konrad','Bremer','','Ringelnatzweg 1','','Seelze','30926','','Germany','DE','5','paypal_ipn','','','','','','','','',NULL,'2014-11-03 12:08:10','1',NULL,'EUR','1.000000','0','paypal_ipn','Tabellarische Versandkosten (Bes','table_table','77.20.248.26','german','0','0','','1',NULL,'','0000-00-00');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;

DROP TABLE IF EXISTS `orders_products`;
CREATE TABLE `orders_products` (
  `orders_products_id` int(11) NOT NULL AUTO_INCREMENT,
  `orders_id` int(11) NOT NULL,
  `products_id` int(11) NOT NULL,
  `products_model` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `products_name` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `products_price` decimal(15,4) NOT NULL,
  `products_discount_made` decimal(4,2) DEFAULT NULL,
  `products_shipping_time` varchar(255) COLLATE latin1_german1_ci DEFAULT NULL,
  `final_price` decimal(15,4) NOT NULL,
  `products_tax` decimal(7,4) NOT NULL,
  `products_quantity` int(2) NOT NULL,
  `allow_tax` int(1) NOT NULL,
  `products_order_description` text COLLATE latin1_german1_ci,
  PRIMARY KEY (`orders_products_id`),
  KEY `idx_orders_id` (`orders_id`),
  KEY `idx_products_id` (`products_id`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `orders_products` DISABLE KEYS */;
INSERT INTO `orders_products` (`orders_products_id`, `orders_id`, `products_id`, `products_model`, `products_name`, `products_price`, `products_discount_made`, `products_shipping_time`, `final_price`, `products_tax`, `products_quantity`, `allow_tax`, `products_order_description`) VALUES ('31','25','7','01GO-14189','Fensterdichtung Silikon GO1','59.9500','0.00','3-4 Tage','59.9500','19.0000','1','1','<p><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\">Breite::&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 9,0 mm<br />\r\nH&ouml;he::&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 9,0 mm <br />\r\nFu&szlig;breite:&nbsp;&nbsp;&nbsp;&nbsp; 5 ,5 mm<br />\r\nStegbreite:&nbsp;&nbsp;&nbsp; 4,0 mm<br />\r\nFarbe:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; schwarz</span></span></p>');
INSERT INTO `orders_products` (`orders_products_id`, `orders_id`, `products_id`, `products_model`, `products_name`, `products_price`, `products_discount_made`, `products_shipping_time`, `final_price`, `products_tax`, `products_quantity`, `allow_tax`, `products_order_description`) VALUES ('39','32','20','HO TPE  RF 0002','Holzfensterdichtungen HO TPE RF 0002','14.9500','0.00','3-4 Tage','14.9500','19.0000','1','1','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Kopfbreite&nbsp; =&nbsp;&nbsp;&nbsp; 8,0 mm<br />\r\nFalzh&ouml;he&nbsp;&nbsp;&nbsp; =&nbsp; 12,0 mm <br />\r\nNutbreite&nbsp;&nbsp; =&nbsp;&nbsp;&nbsp; 5,0 mm <br />\r\nges. H&ouml;he&nbsp; =&nbsp; 19,0 mm</span></span></p>');
INSERT INTO `orders_products` (`orders_products_id`, `orders_id`, `products_id`, `products_model`, `products_name`, `products_price`, `products_discount_made`, `products_shipping_time`, `final_price`, `products_tax`, `products_quantity`, `allow_tax`, `products_order_description`) VALUES ('40','33','8','01GO2-4314','Fensterdichtung Silikon GO2','65.9500','0.00','3-4 Tage','131.9000','19.0000','2','1','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Breite::&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 8,0 mm<br />\r\nH&ouml;he::&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 7,0 mm <br />\r\nFu&szlig;breite:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 5 ,5 mm<br />\r\nStegbreite:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3,5 mm<br />\r\nFarbe:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; schwarz</span></span></p>');
INSERT INTO `orders_products` (`orders_products_id`, `orders_id`, `products_id`, `products_model`, `products_name`, `products_price`, `products_discount_made`, `products_shipping_time`, `final_price`, `products_tax`, `products_quantity`, `allow_tax`, `products_order_description`) VALUES ('37','30','8','01GO2-4314','Fensterdichtung Silikon GO2','65.9500','0.00','3-4 Tage','131.9000','19.0000','2','1','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Breite::&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 8,0 mm<br />\r\nH&ouml;he::&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 7,0 mm <br />\r\nFu&szlig;breite:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 5 ,5 mm<br />\r\nStegbreite:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3,5 mm<br />\r\nFarbe:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; schwarz</span></span></p>');
INSERT INTO `orders_products` (`orders_products_id`, `orders_id`, `products_id`, `products_model`, `products_name`, `products_price`, `products_discount_made`, `products_shipping_time`, `final_price`, `products_tax`, `products_quantity`, `allow_tax`, `products_order_description`) VALUES ('38','31','7','01GO-14189','Fensterdichtung Silikon GO1','15.9500','0.00','3-4 Tage','31.9000','19.0000','2','1','<p><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\">Breite::&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 9,0 mm<br />\r\nH&ouml;he::&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 9,0 mm <br />\r\nFu&szlig;breite:&nbsp;&nbsp;&nbsp;&nbsp; 5 ,5 mm<br />\r\nStegbreite:&nbsp;&nbsp;&nbsp; 4,0 mm<br />\r\nFarbe:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; schwarz</span></span></p>');
/*!40000 ALTER TABLE `orders_products` ENABLE KEYS */;

DROP TABLE IF EXISTS `orders_products_attributes`;
CREATE TABLE `orders_products_attributes` (
  `orders_products_attributes_id` int(11) NOT NULL AUTO_INCREMENT,
  `orders_id` int(11) NOT NULL,
  `orders_products_id` int(11) NOT NULL,
  `products_options` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `products_options_values` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `options_values_price` decimal(15,4) NOT NULL,
  `price_prefix` char(1) COLLATE latin1_german1_ci NOT NULL,
  `orders_products_options_id` int(11) NOT NULL,
  `orders_products_options_values_id` int(11) NOT NULL,
  PRIMARY KEY (`orders_products_attributes_id`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `orders_products_attributes` DISABLE KEYS */;
INSERT INTO `orders_products_attributes` (`orders_products_attributes_id`, `orders_id`, `orders_products_id`, `products_options`, `products_options_values`, `options_values_price`, `price_prefix`, `orders_products_options_id`, `orders_products_options_values_id`) VALUES ('35','30','37','Laufende Meter','25','42.0168','+','1','5');
INSERT INTO `orders_products_attributes` (`orders_products_attributes_id`, `orders_id`, `orders_products_id`, `products_options`, `products_options_values`, `options_values_price`, `price_prefix`, `orders_products_options_id`, `orders_products_options_values_id`) VALUES ('36','31','38','Laufende Meter','5','0.0000','+','1','1');
INSERT INTO `orders_products_attributes` (`orders_products_attributes_id`, `orders_id`, `orders_products_id`, `products_options`, `products_options_values`, `options_values_price`, `price_prefix`, `orders_products_options_id`, `orders_products_options_values_id`) VALUES ('37','32','39','Laufende Meter','6','0.0000','+','1','2');
INSERT INTO `orders_products_attributes` (`orders_products_attributes_id`, `orders_id`, `orders_products_id`, `products_options`, `products_options_values`, `options_values_price`, `price_prefix`, `orders_products_options_id`, `orders_products_options_values_id`) VALUES ('38','32','39','Farbe','braun','0.0000','+','2','10');
INSERT INTO `orders_products_attributes` (`orders_products_attributes_id`, `orders_id`, `orders_products_id`, `products_options`, `products_options_values`, `options_values_price`, `price_prefix`, `orders_products_options_id`, `orders_products_options_values_id`) VALUES ('39','33','40','Laufende Meter','25','42.0168','+','1','5');
INSERT INTO `orders_products_attributes` (`orders_products_attributes_id`, `orders_id`, `orders_products_id`, `products_options`, `products_options_values`, `options_values_price`, `price_prefix`, `orders_products_options_id`, `orders_products_options_values_id`) VALUES ('28','25','31','Laufende Meter','25','36.9748','+','1','5');
/*!40000 ALTER TABLE `orders_products_attributes` ENABLE KEYS */;

DROP TABLE IF EXISTS `orders_products_download`;
CREATE TABLE `orders_products_download` (
  `orders_products_download_id` int(11) NOT NULL AUTO_INCREMENT,
  `orders_id` int(11) NOT NULL DEFAULT '0',
  `orders_products_id` int(11) NOT NULL DEFAULT '0',
  `orders_products_filename` varchar(255) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `download_maxdays` int(2) NOT NULL DEFAULT '0',
  `download_count` int(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`orders_products_download_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `orders_products_download` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders_products_download` ENABLE KEYS */;

DROP TABLE IF EXISTS `orders_recalculate`;
CREATE TABLE `orders_recalculate` (
  `orders_recalculate_id` int(11) NOT NULL AUTO_INCREMENT,
  `orders_id` int(11) NOT NULL DEFAULT '0',
  `n_price` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `b_price` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `tax` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `tax_rate` decimal(7,4) NOT NULL DEFAULT '0.0000',
  `class` varchar(32) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`orders_recalculate_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `orders_recalculate` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders_recalculate` ENABLE KEYS */;

DROP TABLE IF EXISTS `orders_status`;
CREATE TABLE `orders_status` (
  `orders_status_id` int(11) NOT NULL DEFAULT '0',
  `language_id` tinyint(4) NOT NULL DEFAULT '1',
  `orders_status_name` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  PRIMARY KEY (`orders_status_id`,`language_id`),
  KEY `idx_orders_status_name` (`orders_status_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `orders_status` DISABLE KEYS */;
INSERT INTO `orders_status` (`orders_status_id`, `language_id`, `orders_status_name`) VALUES ('1','1','Pending');
INSERT INTO `orders_status` (`orders_status_id`, `language_id`, `orders_status_name`) VALUES ('1','2','Offen');
INSERT INTO `orders_status` (`orders_status_id`, `language_id`, `orders_status_name`) VALUES ('2','1','Processing');
INSERT INTO `orders_status` (`orders_status_id`, `language_id`, `orders_status_name`) VALUES ('2','2','In Bearbeitung');
INSERT INTO `orders_status` (`orders_status_id`, `language_id`, `orders_status_name`) VALUES ('3','1','Delivered');
INSERT INTO `orders_status` (`orders_status_id`, `language_id`, `orders_status_name`) VALUES ('3','2','Versendet');
INSERT INTO `orders_status` (`orders_status_id`, `language_id`, `orders_status_name`) VALUES ('4','1','Payment pending');
INSERT INTO `orders_status` (`orders_status_id`, `language_id`, `orders_status_name`) VALUES ('5','1','Payment confirmed');
INSERT INTO `orders_status` (`orders_status_id`, `language_id`, `orders_status_name`) VALUES ('6','1','Payment canceled');
INSERT INTO `orders_status` (`orders_status_id`, `language_id`, `orders_status_name`) VALUES ('7','1','Needs review.');
INSERT INTO `orders_status` (`orders_status_id`, `language_id`, `orders_status_name`) VALUES ('8','1','Unconfirmed');
INSERT INTO `orders_status` (`orders_status_id`, `language_id`, `orders_status_name`) VALUES ('9','1','Confirmed');
INSERT INTO `orders_status` (`orders_status_id`, `language_id`, `orders_status_name`) VALUES ('4','2','Bezahlung schwebend');
INSERT INTO `orders_status` (`orders_status_id`, `language_id`, `orders_status_name`) VALUES ('5','2','Bezahlung erfolgt');
INSERT INTO `orders_status` (`orders_status_id`, `language_id`, `orders_status_name`) VALUES ('6','2','Bezahlung storniert');
INSERT INTO `orders_status` (`orders_status_id`, `language_id`, `orders_status_name`) VALUES ('7','2','Prüfung notwendig');
INSERT INTO `orders_status` (`orders_status_id`, `language_id`, `orders_status_name`) VALUES ('8','2','Unbestätigt');
INSERT INTO `orders_status` (`orders_status_id`, `language_id`, `orders_status_name`) VALUES ('9','2','Bestätigt');
INSERT INTO `orders_status` (`orders_status_id`, `language_id`, `orders_status_name`) VALUES ('10','2','PayPal Abbruch');
INSERT INTO `orders_status` (`orders_status_id`, `language_id`, `orders_status_name`) VALUES ('10','1','PayPal canceled');
INSERT INTO `orders_status` (`orders_status_id`, `language_id`, `orders_status_name`) VALUES ('11','2','Offen PP bezahlt');
INSERT INTO `orders_status` (`orders_status_id`, `language_id`, `orders_status_name`) VALUES ('11','1','Pending PP sold');
INSERT INTO `orders_status` (`orders_status_id`, `language_id`, `orders_status_name`) VALUES ('12','2','Offen PP wartend');
INSERT INTO `orders_status` (`orders_status_id`, `language_id`, `orders_status_name`) VALUES ('12','1','Open PP pending');
INSERT INTO `orders_status` (`orders_status_id`, `language_id`, `orders_status_name`) VALUES ('13','2','PayPal abgelehnt');
INSERT INTO `orders_status` (`orders_status_id`, `language_id`, `orders_status_name`) VALUES ('13','1','PayPal rejected');
INSERT INTO `orders_status` (`orders_status_id`, `language_id`, `orders_status_name`) VALUES ('17','2','Pr�fung notwendig');
INSERT INTO `orders_status` (`orders_status_id`, `language_id`, `orders_status_name`) VALUES ('18','2','Unbest�tigt');
INSERT INTO `orders_status` (`orders_status_id`, `language_id`, `orders_status_name`) VALUES ('19','2','Best�tigt');
/*!40000 ALTER TABLE `orders_status` ENABLE KEYS */;

DROP TABLE IF EXISTS `orders_status_history`;
CREATE TABLE `orders_status_history` (
  `orders_status_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `orders_id` int(11) NOT NULL,
  `orders_status_id` int(5) NOT NULL,
  `date_added` datetime NOT NULL,
  `customer_notified` int(1) DEFAULT '0',
  `comments` text COLLATE latin1_german1_ci,
  `comments_sent` int(1) DEFAULT '0',
  PRIMARY KEY (`orders_status_history_id`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `orders_status_history` DISABLE KEYS */;
INSERT INTO `orders_status_history` (`orders_status_history_id`, `orders_id`, `orders_status_id`, `date_added`, `customer_notified`, `comments`, `comments_sent`) VALUES ('34','33','1','2014-11-03 12:08:10','1','','0');
INSERT INTO `orders_status_history` (`orders_status_history_id`, `orders_id`, `orders_status_id`, `date_added`, `customer_notified`, `comments`, `comments_sent`) VALUES ('33','32','1','2014-11-03 10:20:16','1','','0');
INSERT INTO `orders_status_history` (`orders_status_history_id`, `orders_id`, `orders_status_id`, `date_added`, `customer_notified`, `comments`, `comments_sent`) VALUES ('25','25','1','2014-11-01 17:43:08','1','','0');
INSERT INTO `orders_status_history` (`orders_status_history_id`, `orders_id`, `orders_status_id`, `date_added`, `customer_notified`, `comments`, `comments_sent`) VALUES ('32','31','1','2014-11-02 22:15:12','1','','0');
INSERT INTO `orders_status_history` (`orders_status_history_id`, `orders_id`, `orders_status_id`, `date_added`, `customer_notified`, `comments`, `comments_sent`) VALUES ('29','25','2','2014-11-01 19:33:50','1','','1');
INSERT INTO `orders_status_history` (`orders_status_history_id`, `orders_id`, `orders_status_id`, `date_added`, `customer_notified`, `comments`, `comments_sent`) VALUES ('31','30','1','2014-11-02 19:49:00','1','','0');
/*!40000 ALTER TABLE `orders_status_history` ENABLE KEYS */;

DROP TABLE IF EXISTS `orders_total`;
CREATE TABLE `orders_total` (
  `orders_total_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `orders_id` int(11) NOT NULL,
  `title` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `text` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `value` decimal(15,4) NOT NULL,
  `class` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`orders_total_id`),
  KEY `idx_orders_total_orders_id` (`orders_id`)
) ENGINE=MyISAM AUTO_INCREMENT=133 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `orders_total` DISABLE KEYS */;
INSERT INTO `orders_total` (`orders_total_id`, `orders_id`, `title`, `text`, `value`, `class`, `sort_order`) VALUES ('117','30','Zwischensumme:',' 131,90 EUR','131.9000','ot_subtotal','20');
INSERT INTO `orders_total` (`orders_total_id`, `orders_id`, `title`, `text`, `value`, `class`, `sort_order`) VALUES ('118','30','inkl. MwSt. 19%:',' 21,06 EUR','21.0600','ot_tax','50');
INSERT INTO `orders_total` (`orders_total_id`, `orders_id`, `title`, `text`, `value`, `class`, `sort_order`) VALUES ('119','30','Tabellarische Versandkosten (Bester Weg):',' 6,90 EUR','6.9000','ot_shipping','60');
INSERT INTO `orders_total` (`orders_total_id`, `orders_id`, `title`, `text`, `value`, `class`, `sort_order`) VALUES ('120','30','<b>Summe</b>:','<strong> 138,80 EUR</strong>','138.8000','ot_total','99');
INSERT INTO `orders_total` (`orders_total_id`, `orders_id`, `title`, `text`, `value`, `class`, `sort_order`) VALUES ('121','31','Zwischensumme:',' 31,90 EUR','31.9000','ot_subtotal','20');
INSERT INTO `orders_total` (`orders_total_id`, `orders_id`, `title`, `text`, `value`, `class`, `sort_order`) VALUES ('122','31','inkl. MwSt. 19%:',' 5,09 EUR','5.0900','ot_tax','50');
INSERT INTO `orders_total` (`orders_total_id`, `orders_id`, `title`, `text`, `value`, `class`, `sort_order`) VALUES ('123','31','Tabellarische Versandkosten (Bester Weg):',' 6,90 EUR','6.9000','ot_shipping','60');
INSERT INTO `orders_total` (`orders_total_id`, `orders_id`, `title`, `text`, `value`, `class`, `sort_order`) VALUES ('124','31','<b>Summe</b>:','<strong> 38,80 EUR</strong>','38.8000','ot_total','99');
INSERT INTO `orders_total` (`orders_total_id`, `orders_id`, `title`, `text`, `value`, `class`, `sort_order`) VALUES ('125','32','Zwischensumme:',' 14,95 EUR','14.9500','ot_subtotal','20');
INSERT INTO `orders_total` (`orders_total_id`, `orders_id`, `title`, `text`, `value`, `class`, `sort_order`) VALUES ('126','32','inkl. MwSt. 19%:',' 2,39 EUR','2.3900','ot_tax','50');
INSERT INTO `orders_total` (`orders_total_id`, `orders_id`, `title`, `text`, `value`, `class`, `sort_order`) VALUES ('127','32','Tabellarische Versandkosten (Bester Weg):',' 3,90 EUR','3.9000','ot_shipping','60');
INSERT INTO `orders_total` (`orders_total_id`, `orders_id`, `title`, `text`, `value`, `class`, `sort_order`) VALUES ('128','32','<b>Summe</b>:','<strong> 18,85 EUR</strong>','18.8500','ot_total','99');
INSERT INTO `orders_total` (`orders_total_id`, `orders_id`, `title`, `text`, `value`, `class`, `sort_order`) VALUES ('129','33','Zwischensumme:',' 131,90 EUR','131.9000','ot_subtotal','20');
INSERT INTO `orders_total` (`orders_total_id`, `orders_id`, `title`, `text`, `value`, `class`, `sort_order`) VALUES ('130','33','inkl. MwSt. 19%:',' 21,06 EUR','21.0600','ot_tax','50');
INSERT INTO `orders_total` (`orders_total_id`, `orders_id`, `title`, `text`, `value`, `class`, `sort_order`) VALUES ('131','33','Tabellarische Versandkosten (Bester Weg):',' 6,90 EUR','6.9000','ot_shipping','60');
INSERT INTO `orders_total` (`orders_total_id`, `orders_id`, `title`, `text`, `value`, `class`, `sort_order`) VALUES ('132','33','<b>Summe</b>:','<strong> 138,80 EUR</strong>','138.8000','ot_total','99');
INSERT INTO `orders_total` (`orders_total_id`, `orders_id`, `title`, `text`, `value`, `class`, `sort_order`) VALUES ('97','25','Zwischensumme:',' 59,95 EUR','59.9500','ot_subtotal','20');
INSERT INTO `orders_total` (`orders_total_id`, `orders_id`, `title`, `text`, `value`, `class`, `sort_order`) VALUES ('98','25','inkl. MwSt. 19%:',' 9,57 EUR','9.5700','ot_tax','50');
INSERT INTO `orders_total` (`orders_total_id`, `orders_id`, `title`, `text`, `value`, `class`, `sort_order`) VALUES ('99','25','Tabellarische Versandkosten (Bester Weg):',' 6,90 EUR','6.9000','ot_shipping','60');
INSERT INTO `orders_total` (`orders_total_id`, `orders_id`, `title`, `text`, `value`, `class`, `sort_order`) VALUES ('100','25','<b>Summe</b>:','<strong> 66,85 EUR</strong>','66.8500','ot_total','99');
/*!40000 ALTER TABLE `orders_total` ENABLE KEYS */;

DROP TABLE IF EXISTS `payment_moneybookers`;
CREATE TABLE `payment_moneybookers` (
  `mb_TRID` varchar(255) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `mb_ERRNO` smallint(3) unsigned NOT NULL DEFAULT '0',
  `mb_ERRTXT` varchar(255) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `mb_DATE` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `mb_MBTID` bigint(18) unsigned NOT NULL DEFAULT '0',
  `mb_STATUS` tinyint(1) NOT NULL DEFAULT '0',
  `mb_ORDERID` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`mb_TRID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `payment_moneybookers` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_moneybookers` ENABLE KEYS */;

DROP TABLE IF EXISTS `payment_moneybookers_countries`;
CREATE TABLE `payment_moneybookers_countries` (
  `osc_cID` int(11) NOT NULL DEFAULT '0',
  `mb_cID` char(3) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`osc_cID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `payment_moneybookers_countries` DISABLE KEYS */;
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('2','ALB');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('3','ALG');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('4','AME');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('5','AND');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('6','AGL');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('7','ANG');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('9','ANT');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('10','ARG');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('11','ARM');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('12','ARU');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('13','AUS');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('14','AUT');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('15','AZE');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('16','BMS');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('17','BAH');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('18','BAN');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('19','BAR');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('20','BLR');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('21','BGM');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('22','BEL');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('23','BEN');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('24','BER');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('26','BOL');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('27','BOS');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('28','BOT');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('30','BRA');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('32','BRU');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('33','BUL');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('34','BKF');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('35','BUR');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('36','CAM');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('37','CMR');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('38','CAN');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('39','CAP');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('40','CAY');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('41','CEN');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('42','CHA');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('43','CHL');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('44','CHN');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('47','COL');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('49','CON');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('51','COS');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('52','COT');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('53','CRO');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('54','CUB');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('55','CYP');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('56','CZE');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('57','DEN');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('58','DJI');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('59','DOM');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('60','DRP');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('62','ECU');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('64','EL_');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('65','EQU');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('66','ERI');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('67','EST');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('68','ETH');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('70','FAR');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('71','FIJ');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('72','FIN');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('73','FRA');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('75','FRE');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('78','GAB');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('79','GAM');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('80','GEO');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('81','GER');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('82','GHA');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('83','GIB');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('84','GRC');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('85','GRL');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('87','GDL');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('88','GUM');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('89','GUA');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('90','GUI');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('91','GBS');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('92','GUY');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('93','HAI');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('95','HON');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('96','HKG');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('97','HUN');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('98','ICE');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('99','IND');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('101','IRN');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('102','IRA');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('103','IRE');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('104','ISR');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('105','ITA');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('106','JAM');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('107','JAP');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('108','JOR');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('109','KAZ');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('110','KEN');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('112','SKO');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('113','KOR');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('114','KUW');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('115','KYR');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('116','LAO');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('117','LAT');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('141','MCO');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('119','LES');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('120','LIB');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('121','LBY');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('122','LIE');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('123','LIT');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('124','LUX');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('125','MAC');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('126','F.Y');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('127','MAD');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('128','MLW');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('129','MLS');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('130','MAL');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('131','MLI');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('132','MLT');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('134','MAR');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('135','MRT');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('136','MAU');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('138','MEX');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('140','MOL');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('142','MON');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('143','MTT');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('144','MOR');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('145','MOZ');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('76','PYF');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('147','NAM');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('149','NEP');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('150','NED');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('151','NET');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('152','CDN');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('153','NEW');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('154','NIC');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('155','NIG');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('69','FLK');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('160','NWY');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('161','OMA');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('162','PAK');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('164','PAN');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('165','PAP');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('166','PAR');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('167','PER');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('168','PHI');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('170','POL');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('171','POR');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('172','PUE');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('173','QAT');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('175','ROM');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('176','RUS');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('177','RWA');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('178','SKN');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('179','SLU');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('180','ST.');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('181','WES');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('182','SAN');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('183','SAO');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('184','SAU');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('185','SEN');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('186','SEY');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('187','SIE');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('188','SIN');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('189','SLO');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('190','SLV');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('191','SOL');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('192','SOM');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('193','SOU');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('195','SPA');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('196','SRI');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('199','SUD');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('200','SUR');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('202','SWA');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('203','SWE');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('204','SWI');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('205','SYR');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('206','TWN');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('207','TAJ');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('208','TAN');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('209','THA');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('210','TOG');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('212','TON');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('213','TRI');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('214','TUN');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('215','TUR');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('216','TKM');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('217','TCI');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('219','UGA');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('231','BRI');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('221','UAE');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('222','GBR');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('223','UNI');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('225','URU');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('226','UZB');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('227','VAN');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('229','VEN');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('230','VIE');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('232','US_');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('235','YEM');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('236','YUG');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('238','ZAM');
INSERT INTO `payment_moneybookers_countries` (`osc_cID`, `mb_cID`) VALUES ('239','ZIM');
/*!40000 ALTER TABLE `payment_moneybookers_countries` ENABLE KEYS */;

DROP TABLE IF EXISTS `payment_moneybookers_currencies`;
CREATE TABLE `payment_moneybookers_currencies` (
  `mb_currID` char(3) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `mb_currName` varchar(255) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`mb_currID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `payment_moneybookers_currencies` DISABLE KEYS */;
INSERT INTO `payment_moneybookers_currencies` (`mb_currID`, `mb_currName`) VALUES ('AUD','Australian Dollar');
INSERT INTO `payment_moneybookers_currencies` (`mb_currID`, `mb_currName`) VALUES ('BGN','Bulgarian Lev');
INSERT INTO `payment_moneybookers_currencies` (`mb_currID`, `mb_currName`) VALUES ('CAD','Canadian Dollar');
INSERT INTO `payment_moneybookers_currencies` (`mb_currID`, `mb_currName`) VALUES ('CHF','Swiss Franc');
INSERT INTO `payment_moneybookers_currencies` (`mb_currID`, `mb_currName`) VALUES ('CZK','Czech Koruna');
INSERT INTO `payment_moneybookers_currencies` (`mb_currID`, `mb_currName`) VALUES ('DKK','Danish Krone');
INSERT INTO `payment_moneybookers_currencies` (`mb_currID`, `mb_currName`) VALUES ('EEK','Estonian Koruna');
INSERT INTO `payment_moneybookers_currencies` (`mb_currID`, `mb_currName`) VALUES ('EUR','Euro');
INSERT INTO `payment_moneybookers_currencies` (`mb_currID`, `mb_currName`) VALUES ('GBP','Pound Sterling');
INSERT INTO `payment_moneybookers_currencies` (`mb_currID`, `mb_currName`) VALUES ('HKD','Hong Kong Dollar');
INSERT INTO `payment_moneybookers_currencies` (`mb_currID`, `mb_currName`) VALUES ('HUF','Forint');
INSERT INTO `payment_moneybookers_currencies` (`mb_currID`, `mb_currName`) VALUES ('ILS','Shekel');
INSERT INTO `payment_moneybookers_currencies` (`mb_currID`, `mb_currName`) VALUES ('ISK','Iceland Krona');
INSERT INTO `payment_moneybookers_currencies` (`mb_currID`, `mb_currName`) VALUES ('JPY','Yen');
INSERT INTO `payment_moneybookers_currencies` (`mb_currID`, `mb_currName`) VALUES ('KRW','South-Korean Won');
INSERT INTO `payment_moneybookers_currencies` (`mb_currID`, `mb_currName`) VALUES ('LVL','Latvian Lat');
INSERT INTO `payment_moneybookers_currencies` (`mb_currID`, `mb_currName`) VALUES ('MYR','Malaysian Ringgit');
INSERT INTO `payment_moneybookers_currencies` (`mb_currID`, `mb_currName`) VALUES ('NOK','Norwegian Krone');
INSERT INTO `payment_moneybookers_currencies` (`mb_currID`, `mb_currName`) VALUES ('NZD','New Zealand Dollar');
INSERT INTO `payment_moneybookers_currencies` (`mb_currID`, `mb_currName`) VALUES ('PLN','Zloty');
INSERT INTO `payment_moneybookers_currencies` (`mb_currID`, `mb_currName`) VALUES ('SEK','Swedish Krona');
INSERT INTO `payment_moneybookers_currencies` (`mb_currID`, `mb_currName`) VALUES ('SGD','Singapore Dollar');
INSERT INTO `payment_moneybookers_currencies` (`mb_currID`, `mb_currName`) VALUES ('SKK','Slovak Koruna');
INSERT INTO `payment_moneybookers_currencies` (`mb_currID`, `mb_currName`) VALUES ('THB','Baht');
INSERT INTO `payment_moneybookers_currencies` (`mb_currID`, `mb_currName`) VALUES ('TWD','New Taiwan Dollar');
INSERT INTO `payment_moneybookers_currencies` (`mb_currID`, `mb_currName`) VALUES ('USD','US Dollar');
/*!40000 ALTER TABLE `payment_moneybookers_currencies` ENABLE KEYS */;

DROP TABLE IF EXISTS `paypal`;
CREATE TABLE `paypal` (
  `paypal_ipn_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `xtc_order_id` int(11) unsigned NOT NULL DEFAULT '0',
  `txn_type` varchar(32) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `reason_code` varchar(15) COLLATE latin1_german1_ci DEFAULT NULL,
  `payment_type` varchar(7) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `payment_status` varchar(17) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `pending_reason` varchar(14) COLLATE latin1_german1_ci DEFAULT NULL,
  `invoice` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `mc_currency` char(3) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `first_name` varchar(32) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `last_name` varchar(32) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `payer_business_name` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `address_name` varchar(32) COLLATE latin1_german1_ci DEFAULT NULL,
  `address_street` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `address_city` varchar(32) COLLATE latin1_german1_ci DEFAULT NULL,
  `address_state` varchar(32) COLLATE latin1_german1_ci DEFAULT NULL,
  `address_zip` varchar(10) COLLATE latin1_german1_ci DEFAULT NULL,
  `address_country` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `address_status` varchar(11) COLLATE latin1_german1_ci DEFAULT NULL,
  `payer_email` varchar(96) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `payer_id` varchar(32) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `payer_status` varchar(10) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `payment_date` datetime NOT NULL DEFAULT '0001-01-01 00:00:00',
  `business` varchar(96) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `receiver_email` varchar(96) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `receiver_id` varchar(32) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `txn_id` varchar(40) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `parent_txn_id` varchar(17) COLLATE latin1_german1_ci DEFAULT NULL,
  `num_cart_items` tinyint(4) unsigned NOT NULL DEFAULT '1',
  `mc_gross` decimal(7,2) NOT NULL DEFAULT '0.00',
  `mc_fee` decimal(7,2) NOT NULL DEFAULT '0.00',
  `mc_shipping` decimal(7,2) NOT NULL DEFAULT '0.00',
  `payment_gross` decimal(7,2) DEFAULT NULL,
  `payment_fee` decimal(7,2) DEFAULT NULL,
  `settle_amount` decimal(7,2) DEFAULT NULL,
  `settle_currency` char(3) COLLATE latin1_german1_ci DEFAULT NULL,
  `exchange_rate` decimal(4,2) DEFAULT NULL,
  `notify_version` decimal(2,1) NOT NULL DEFAULT '0.0',
  `verify_sign` varchar(128) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `last_modified` datetime NOT NULL DEFAULT '0001-01-01 00:00:00',
  `date_added` datetime NOT NULL DEFAULT '0001-01-01 00:00:00',
  `memo` text COLLATE latin1_german1_ci,
  `mc_authorization` decimal(7,2) NOT NULL,
  `mc_captured` decimal(7,2) NOT NULL,
  PRIMARY KEY (`paypal_ipn_id`,`txn_id`),
  KEY `xtc_order_id` (`xtc_order_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `paypal` DISABLE KEYS */;
/*!40000 ALTER TABLE `paypal` ENABLE KEYS */;

DROP TABLE IF EXISTS `paypal_status_history`;
CREATE TABLE `paypal_status_history` (
  `payment_status_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `paypal_ipn_id` int(11) NOT NULL DEFAULT '0',
  `txn_id` varchar(64) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `parent_txn_id` varchar(64) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `payment_status` varchar(17) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `pending_reason` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `mc_amount` decimal(7,2) NOT NULL,
  `date_added` datetime NOT NULL DEFAULT '0001-01-01 00:00:00',
  PRIMARY KEY (`payment_status_history_id`),
  KEY `paypal_ipn_id` (`paypal_ipn_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `paypal_status_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `paypal_status_history` ENABLE KEYS */;

DROP TABLE IF EXISTS `personal_offers_by_customers_status_0`;
CREATE TABLE `personal_offers_by_customers_status_0` (
  `price_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `personal_offer` decimal(15,4) DEFAULT NULL,
  PRIMARY KEY (`price_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `personal_offers_by_customers_status_0` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_offers_by_customers_status_0` ENABLE KEYS */;

DROP TABLE IF EXISTS `personal_offers_by_customers_status_1`;
CREATE TABLE `personal_offers_by_customers_status_1` (
  `price_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `personal_offer` decimal(15,4) DEFAULT NULL,
  PRIMARY KEY (`price_id`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `personal_offers_by_customers_status_1` DISABLE KEYS */;
INSERT INTO `personal_offers_by_customers_status_1` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('1','0','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_1` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('9','8','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_1` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('10','9','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_1` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('8','7','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_1` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('11','10','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_1` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('12','11','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_1` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('13','12','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_1` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('14','13','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_1` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('15','14','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_1` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('16','15','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_1` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('17','16','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_1` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('19','18','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_1` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('21','20','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_1` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('22','21','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_1` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('23','22','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_1` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('24','23','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_1` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('25','24','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_1` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('26','25','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_1` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('27','26','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_1` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('28','27','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_1` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('29','28','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_1` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('30','29','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_1` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('31','30','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_1` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('36','35','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_1` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('33','32','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_1` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('34','33','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_1` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('35','34','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_1` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('37','36','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_1` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('38','37','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_1` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('39','38','1','0.0000');
/*!40000 ALTER TABLE `personal_offers_by_customers_status_1` ENABLE KEYS */;

DROP TABLE IF EXISTS `personal_offers_by_customers_status_2`;
CREATE TABLE `personal_offers_by_customers_status_2` (
  `price_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `personal_offer` decimal(15,4) DEFAULT NULL,
  PRIMARY KEY (`price_id`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `personal_offers_by_customers_status_2` DISABLE KEYS */;
INSERT INTO `personal_offers_by_customers_status_2` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('1','0','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_2` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('9','8','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_2` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('10','9','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_2` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('8','7','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_2` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('11','10','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_2` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('12','11','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_2` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('13','12','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_2` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('14','13','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_2` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('15','14','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_2` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('16','15','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_2` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('17','16','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_2` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('19','18','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_2` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('21','20','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_2` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('22','21','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_2` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('23','22','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_2` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('24','23','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_2` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('25','24','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_2` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('26','25','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_2` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('27','26','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_2` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('28','27','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_2` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('29','28','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_2` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('30','29','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_2` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('31','30','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_2` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('36','35','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_2` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('33','32','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_2` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('34','33','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_2` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('35','34','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_2` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('37','36','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_2` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('38','37','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_2` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('39','38','1','0.0000');
/*!40000 ALTER TABLE `personal_offers_by_customers_status_2` ENABLE KEYS */;

DROP TABLE IF EXISTS `personal_offers_by_customers_status_3`;
CREATE TABLE `personal_offers_by_customers_status_3` (
  `price_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `personal_offer` decimal(15,4) DEFAULT NULL,
  PRIMARY KEY (`price_id`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `personal_offers_by_customers_status_3` DISABLE KEYS */;
INSERT INTO `personal_offers_by_customers_status_3` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('1','0','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_3` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('9','8','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_3` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('10','9','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_3` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('8','7','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_3` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('11','10','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_3` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('12','11','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_3` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('13','12','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_3` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('14','13','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_3` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('15','14','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_3` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('16','15','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_3` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('17','16','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_3` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('19','18','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_3` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('21','20','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_3` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('22','21','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_3` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('23','22','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_3` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('24','23','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_3` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('25','24','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_3` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('26','25','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_3` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('27','26','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_3` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('28','27','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_3` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('29','28','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_3` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('30','29','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_3` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('31','30','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_3` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('36','35','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_3` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('33','32','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_3` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('34','33','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_3` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('35','34','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_3` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('37','36','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_3` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('38','37','1','0.0000');
INSERT INTO `personal_offers_by_customers_status_3` (`price_id`, `products_id`, `quantity`, `personal_offer`) VALUES ('39','38','1','0.0000');
/*!40000 ALTER TABLE `personal_offers_by_customers_status_3` ENABLE KEYS */;

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `products_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_ean` varchar(128) COLLATE latin1_german1_ci DEFAULT NULL,
  `products_quantity` int(4) NOT NULL,
  `products_shippingtime` int(4) NOT NULL,
  `products_model` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `group_permission_0` tinyint(1) NOT NULL,
  `group_permission_1` tinyint(1) NOT NULL,
  `group_permission_2` tinyint(1) NOT NULL,
  `group_permission_3` tinyint(1) NOT NULL,
  `products_sort` int(4) NOT NULL DEFAULT '0',
  `products_image` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `products_price` decimal(15,4) NOT NULL,
  `products_discount_allowed` decimal(4,2) NOT NULL DEFAULT '0.00',
  `products_date_added` datetime NOT NULL,
  `products_last_modified` datetime DEFAULT NULL,
  `products_date_available` datetime DEFAULT NULL,
  `products_weight` decimal(6,3) NOT NULL,
  `products_status` tinyint(1) NOT NULL,
  `products_tax_class_id` int(11) NOT NULL,
  `product_template` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `options_template` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `manufacturers_id` int(11) DEFAULT NULL,
  `products_manufacturers_model` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `products_ordered` int(11) NOT NULL DEFAULT '0',
  `products_fsk18` int(1) NOT NULL DEFAULT '0',
  `products_vpe` int(11) NOT NULL,
  `products_vpe_status` int(1) NOT NULL DEFAULT '0',
  `products_vpe_value` decimal(15,4) NOT NULL,
  `products_startpage` int(1) NOT NULL DEFAULT '0',
  `products_startpage_sort` int(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`products_id`),
  KEY `idx_products_date_added` (`products_date_added`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` (`products_id`, `products_ean`, `products_quantity`, `products_shippingtime`, `products_model`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `products_sort`, `products_image`, `products_price`, `products_discount_allowed`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_status`, `products_tax_class_id`, `product_template`, `options_template`, `manufacturers_id`, `products_manufacturers_model`, `products_ordered`, `products_fsk18`, `products_vpe`, `products_vpe_status`, `products_vpe_value`, `products_startpage`, `products_startpage_sort`) VALUES ('8','','11104','1','01GO2-4314','0','0','0','0','2','8_0.jpg','13.4034','0.00','2014-10-23 11:30:08','2014-11-01 18:17:58',NULL,'0.000','1','1','product_info_v1.html','table_listing.html','0','','7','0','0','0','0.0000','0','0');
INSERT INTO `products` (`products_id`, `products_ean`, `products_quantity`, `products_shippingtime`, `products_model`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `products_sort`, `products_image`, `products_price`, `products_discount_allowed`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_status`, `products_tax_class_id`, `product_template`, `options_template`, `manufacturers_id`, `products_manufacturers_model`, `products_ordered`, `products_fsk18`, `products_vpe`, `products_vpe_status`, `products_vpe_value`, `products_startpage`, `products_startpage_sort`) VALUES ('9','','1109','1','01GO3-4384','0','0','0','0','3','9_0.JPG','13.4034','0.00','2014-10-23 12:15:05','2014-11-01 18:52:25',NULL,'0.000','1','1','product_info_v1.html','table_listing.html','0','','2','0','0','0','0.0000','0','0');
INSERT INTO `products` (`products_id`, `products_ean`, `products_quantity`, `products_shippingtime`, `products_model`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `products_sort`, `products_image`, `products_price`, `products_discount_allowed`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_status`, `products_tax_class_id`, `product_template`, `options_template`, `manufacturers_id`, `products_manufacturers_model`, `products_ordered`, `products_fsk18`, `products_vpe`, `products_vpe_status`, `products_vpe_value`, `products_startpage`, `products_startpage_sort`) VALUES ('10','','11111','1','01KO14385','0','0','0','0','4','10_0.jpg','13.4034','0.00','2014-10-23 13:30:17','2014-11-01 18:52:49',NULL,'0.000','1','1','product_info_v1.html','product_options_selection.html','0','','0','0','0','0','0.0000','0','0');
INSERT INTO `products` (`products_id`, `products_ean`, `products_quantity`, `products_shippingtime`, `products_model`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `products_sort`, `products_image`, `products_price`, `products_discount_allowed`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_status`, `products_tax_class_id`, `product_template`, `options_template`, `manufacturers_id`, `products_manufacturers_model`, `products_ordered`, `products_fsk18`, `products_vpe`, `products_vpe_status`, `products_vpe_value`, `products_startpage`, `products_startpage_sort`) VALUES ('11','','108','1','01KO2-4189','0','0','0','0','5','11_0.JPG','13.4034','0.00','2014-10-23 14:04:06','2014-11-01 18:19:07',NULL,'0.000','1','1','product_info_v1.html','table_listing.html','0','','3','0','0','0','0.0000','1','0');
INSERT INTO `products` (`products_id`, `products_ean`, `products_quantity`, `products_shippingtime`, `products_model`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `products_sort`, `products_image`, `products_price`, `products_discount_allowed`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_status`, `products_tax_class_id`, `product_template`, `options_template`, `manufacturers_id`, `products_manufacturers_model`, `products_ordered`, `products_fsk18`, `products_vpe`, `products_vpe_status`, `products_vpe_value`, `products_startpage`, `products_startpage_sort`) VALUES ('7','','1095','1','01GO-14189','0','0','0','0','1','7_0.jpg','13.4034','0.00','2014-10-23 10:42:29','2014-11-02 16:58:23',NULL,'1.000','1','1','product_info_v1.html','table_listing.html','0','','16','0','0','0','0.0000','0','0');
INSERT INTO `products` (`products_id`, `products_ean`, `products_quantity`, `products_shippingtime`, `products_model`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `products_sort`, `products_image`, `products_price`, `products_discount_allowed`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_status`, `products_tax_class_id`, `product_template`, `options_template`, `manufacturers_id`, `products_manufacturers_model`, `products_ordered`, `products_fsk18`, `products_vpe`, `products_vpe_status`, `products_vpe_value`, `products_startpage`, `products_startpage_sort`) VALUES ('12','','11111','1','01MO1-4246','0','0','0','0','6','12_0.jpg','13.4034','0.00','2014-10-23 14:12:40','2014-11-01 18:53:13',NULL,'0.000','1','1','product_info_v1.html','product_options_selection.html','0','','0','0','0','0','0.0000','0','0');
INSERT INTO `products` (`products_id`, `products_ean`, `products_quantity`, `products_shippingtime`, `products_model`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `products_sort`, `products_image`, `products_price`, `products_discount_allowed`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_status`, `products_tax_class_id`, `product_template`, `options_template`, `manufacturers_id`, `products_manufacturers_model`, `products_ordered`, `products_fsk18`, `products_vpe`, `products_vpe_status`, `products_vpe_value`, `products_startpage`, `products_startpage_sort`) VALUES ('13','','111110','1','02 G - 1000','0','0','0','0','0','13_0.JPG','12.5630','0.00','2014-10-27 12:50:01','2014-11-01 09:12:25',NULL,'0.000','1','1','product_info_v1.html','table_listing.html','0','','1','0','0','0','0.0000','0','0');
INSERT INTO `products` (`products_id`, `products_ean`, `products_quantity`, `products_shippingtime`, `products_model`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `products_sort`, `products_image`, `products_price`, `products_discount_allowed`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_status`, `products_tax_class_id`, `product_template`, `options_template`, `manufacturers_id`, `products_manufacturers_model`, `products_ordered`, `products_fsk18`, `products_vpe`, `products_vpe_status`, `products_vpe_value`, `products_startpage`, `products_startpage_sort`) VALUES ('14','','1110','1','02 H - 1000','0','0','0','0','0','14_0.jpg','12.5630','0.00','2014-10-27 18:26:13','2014-11-01 09:12:33',NULL,'0.000','1','1','product_info_v1.html','table_listing.html','0','','1','0','0','0','0.0000','0','0');
INSERT INTO `products` (`products_id`, `products_ean`, `products_quantity`, `products_shippingtime`, `products_model`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `products_sort`, `products_image`, `products_price`, `products_discount_allowed`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_status`, `products_tax_class_id`, `product_template`, `options_template`, `manufacturers_id`, `products_manufacturers_model`, `products_ordered`, `products_fsk18`, `products_vpe`, `products_vpe_status`, `products_vpe_value`, `products_startpage`, `products_startpage_sort`) VALUES ('15','','1110','1','02 K - 1000','0','0','0','0','0','15_0.jpg','12.5630','0.00','2014-10-27 18:31:20','2014-10-30 16:18:26',NULL,'0.000','1','1','product_info_v1.html','table_listing.html','0','','1','0','0','0','0.0000','1','0');
INSERT INTO `products` (`products_id`, `products_ean`, `products_quantity`, `products_shippingtime`, `products_model`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `products_sort`, `products_image`, `products_price`, `products_discount_allowed`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_status`, `products_tax_class_id`, `product_template`, `options_template`, `manufacturers_id`, `products_manufacturers_model`, `products_ordered`, `products_fsk18`, `products_vpe`, `products_vpe_status`, `products_vpe_value`, `products_startpage`, `products_startpage_sort`) VALUES ('16','','1111','1','02 S - 1000','0','0','0','0','0','16_0.jpg','12.5630','0.00','2014-10-27 18:49:31','2014-11-01 09:13:39',NULL,'0.000','1','1','product_info_v1.html','table_listing.html','0','','0','0','0','0','0.0000','0','0');
INSERT INTO `products` (`products_id`, `products_ean`, `products_quantity`, `products_shippingtime`, `products_model`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `products_sort`, `products_image`, `products_price`, `products_discount_allowed`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_status`, `products_tax_class_id`, `product_template`, `options_template`, `manufacturers_id`, `products_manufacturers_model`, `products_ordered`, `products_fsk18`, `products_vpe`, `products_vpe_status`, `products_vpe_value`, `products_startpage`, `products_startpage_sort`) VALUES ('18','','111','1','02 V - 1000','0','0','0','0','0','18_0.jpg','12.5630','0.00','2014-10-27 19:01:21','2014-11-02 16:58:55',NULL,'0.000','1','1','product_info_v1.html','table_listing.html','0','','0','0','0','0','0.0000','0','0');
INSERT INTO `products` (`products_id`, `products_ean`, `products_quantity`, `products_shippingtime`, `products_model`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `products_sort`, `products_image`, `products_price`, `products_discount_allowed`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_status`, `products_tax_class_id`, `product_template`, `options_template`, `manufacturers_id`, `products_manufacturers_model`, `products_ordered`, `products_fsk18`, `products_vpe`, `products_vpe_status`, `products_vpe_value`, `products_startpage`, `products_startpage_sort`) VALUES ('20','','1110','1','HO TPE  RF 0002','0','0','0','0','1','20_0.JPG','12.5630','0.00','2014-10-28 12:24:12','2014-11-01 18:37:37',NULL,'0.000','1','1','product_info_v1.html','product_options_selection.html','0','','1','0','0','0','0.0000','1','0');
INSERT INTO `products` (`products_id`, `products_ean`, `products_quantity`, `products_shippingtime`, `products_model`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `products_sort`, `products_image`, `products_price`, `products_discount_allowed`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_status`, `products_tax_class_id`, `product_template`, `options_template`, `manufacturers_id`, `products_manufacturers_model`, `products_ordered`, `products_fsk18`, `products_vpe`, `products_vpe_status`, `products_vpe_value`, `products_startpage`, `products_startpage_sort`) VALUES ('21','','11107','1','HO TPE RF 0003','0','0','0','0','2','21_0.jpg','13.4034','0.00','2014-10-28 13:40:33','2014-11-01 18:38:17',NULL,'0.000','1','1','product_info_v1.html','product_options_selection.html','0','','4','0','0','0','0.0000','1','0');
INSERT INTO `products` (`products_id`, `products_ean`, `products_quantity`, `products_shippingtime`, `products_model`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `products_sort`, `products_image`, `products_price`, `products_discount_allowed`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_status`, `products_tax_class_id`, `product_template`, `options_template`, `manufacturers_id`, `products_manufacturers_model`, `products_ordered`, `products_fsk18`, `products_vpe`, `products_vpe_status`, `products_vpe_value`, `products_startpage`, `products_startpage_sort`) VALUES ('22','','1111','1','HO TPE RF 0012','0','0','0','0','3','22_0.jpg','19.2857','0.00','2014-10-28 13:50:00','2014-11-01 18:39:47',NULL,'0.000','1','1','product_info_v1.html','product_options_selection.html','0','','0','0','0','0','0.0000','0','0');
INSERT INTO `products` (`products_id`, `products_ean`, `products_quantity`, `products_shippingtime`, `products_model`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `products_sort`, `products_image`, `products_price`, `products_discount_allowed`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_status`, `products_tax_class_id`, `product_template`, `options_template`, `manufacturers_id`, `products_manufacturers_model`, `products_ordered`, `products_fsk18`, `products_vpe`, `products_vpe_status`, `products_vpe_value`, `products_startpage`, `products_startpage_sort`) VALUES ('23','','111','1','HO TPE  RF 0022','0','0','0','0','4','23_0.jpg','16.7647','0.00','2014-10-28 13:54:19','2014-11-01 18:40:06',NULL,'0.000','1','1','product_info_v1.html','product_options_selection.html','0','','0','0','0','0','0.0000','0','0');
INSERT INTO `products` (`products_id`, `products_ean`, `products_quantity`, `products_shippingtime`, `products_model`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `products_sort`, `products_image`, `products_price`, `products_discount_allowed`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_status`, `products_tax_class_id`, `product_template`, `options_template`, `manufacturers_id`, `products_manufacturers_model`, `products_ordered`, `products_fsk18`, `products_vpe`, `products_vpe_status`, `products_vpe_value`, `products_startpage`, `products_startpage_sort`) VALUES ('24','','111','1','HO TPE RF 0023','0','0','0','0','5','24_0.jpg','18.4454','0.00','2014-10-28 13:58:58','2014-11-01 09:13:57',NULL,'0.000','1','1','product_info_v1.html','product_options_selection.html','0','','0','0','0','0','0.0000','0','0');
INSERT INTO `products` (`products_id`, `products_ean`, `products_quantity`, `products_shippingtime`, `products_model`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `products_sort`, `products_image`, `products_price`, `products_discount_allowed`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_status`, `products_tax_class_id`, `product_template`, `options_template`, `manufacturers_id`, `products_manufacturers_model`, `products_ordered`, `products_fsk18`, `products_vpe`, `products_vpe_status`, `products_vpe_value`, `products_startpage`, `products_startpage_sort`) VALUES ('25','','111111','1','HO TPE RF 0009','0','0','0','0','6','25_0.jpg','15.0840','0.00','2014-10-28 14:02:31','2014-11-01 18:44:35',NULL,'0.000','1','1','product_info_v1.html','product_options_selection.html','0','','0','0','0','0','0.0000','0','0');
INSERT INTO `products` (`products_id`, `products_ean`, `products_quantity`, `products_shippingtime`, `products_model`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `products_sort`, `products_image`, `products_price`, `products_discount_allowed`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_status`, `products_tax_class_id`, `product_template`, `options_template`, `manufacturers_id`, `products_manufacturers_model`, `products_ordered`, `products_fsk18`, `products_vpe`, `products_vpe_status`, `products_vpe_value`, `products_startpage`, `products_startpage_sort`) VALUES ('26','','1111','1','HO TPE RF 0010','0','0','0','0','7','26_0.jpg','15.0840','0.00','2014-10-28 14:05:46','2014-11-01 18:45:20',NULL,'0.000','1','1','product_info_v1.html','product_options_selection.html','0','','0','0','0','0','0.0000','0','0');
INSERT INTO `products` (`products_id`, `products_ean`, `products_quantity`, `products_shippingtime`, `products_model`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `products_sort`, `products_image`, `products_price`, `products_discount_allowed`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_status`, `products_tax_class_id`, `product_template`, `options_template`, `manufacturers_id`, `products_manufacturers_model`, `products_ordered`, `products_fsk18`, `products_vpe`, `products_vpe_status`, `products_vpe_value`, `products_startpage`, `products_startpage_sort`) VALUES ('27','','1111','1','HO TPE RF 0013','0','0','0','0','10','27_0.jpg','15.0840','0.00','2014-10-28 14:14:46','2014-11-01 18:46:31',NULL,'0.000','1','1','product_info_v1.html','product_options_selection.html','0','','0','0','0','0','0.0000','0','0');
INSERT INTO `products` (`products_id`, `products_ean`, `products_quantity`, `products_shippingtime`, `products_model`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `products_sort`, `products_image`, `products_price`, `products_discount_allowed`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_status`, `products_tax_class_id`, `product_template`, `options_template`, `manufacturers_id`, `products_manufacturers_model`, `products_ordered`, `products_fsk18`, `products_vpe`, `products_vpe_status`, `products_vpe_value`, `products_startpage`, `products_startpage_sort`) VALUES ('28','','111','1','HO TPE  RF 0021','0','0','0','0','11','28_0.jpg','15.0840','0.00','2014-10-28 14:16:43','2014-11-01 18:46:55',NULL,'0.000','1','1','product_info_v1.html','table_listing.html','0','','0','0','0','0','0.0000','0','0');
INSERT INTO `products` (`products_id`, `products_ean`, `products_quantity`, `products_shippingtime`, `products_model`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `products_sort`, `products_image`, `products_price`, `products_discount_allowed`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_status`, `products_tax_class_id`, `product_template`, `options_template`, `manufacturers_id`, `products_manufacturers_model`, `products_ordered`, `products_fsk18`, `products_vpe`, `products_vpe_status`, `products_vpe_value`, `products_startpage`, `products_startpage_sort`) VALUES ('29','','1111','1','HO TPE  RF 0024','0','0','0','0','8','29_0.jpg','16.7647','0.00','2014-10-28 14:20:34','2014-11-01 18:45:43',NULL,'0.000','1','1','product_info_v1.html','product_options_selection.html','0','','0','0','0','0','0.0000','0','0');
INSERT INTO `products` (`products_id`, `products_ean`, `products_quantity`, `products_shippingtime`, `products_model`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `products_sort`, `products_image`, `products_price`, `products_discount_allowed`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_status`, `products_tax_class_id`, `product_template`, `options_template`, `manufacturers_id`, `products_manufacturers_model`, `products_ordered`, `products_fsk18`, `products_vpe`, `products_vpe_status`, `products_vpe_value`, `products_startpage`, `products_startpage_sort`) VALUES ('30','','1111','1','HO TPE  RF 0011','0','0','0','0','9','30_0.jpg','15.0840','0.00','2014-10-28 14:21:50','2014-11-01 18:46:13',NULL,'0.000','1','1','product_info_v1.html','product_options_selection.html','0','','0','0','0','0','0.0000','0','0');
INSERT INTO `products` (`products_id`, `products_ean`, `products_quantity`, `products_shippingtime`, `products_model`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `products_sort`, `products_image`, `products_price`, `products_discount_allowed`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_status`, `products_tax_class_id`, `product_template`, `options_template`, `manufacturers_id`, `products_manufacturers_model`, `products_ordered`, `products_fsk18`, `products_vpe`, `products_vpe_status`, `products_vpe_value`, `products_startpage`, `products_startpage_sort`) VALUES ('32','','1107','1','HO TPE  RF 0004','0','0','0','0','12','32_0.jpg','15.5462','0.00','2014-10-28 14:26:14','2014-11-01 09:14:15',NULL,'0.000','1','1','product_info_v1.html','product_options_selection.html','0','','4','0','0','0','0.0000','0','0');
INSERT INTO `products` (`products_id`, `products_ean`, `products_quantity`, `products_shippingtime`, `products_model`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `products_sort`, `products_image`, `products_price`, `products_discount_allowed`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_status`, `products_tax_class_id`, `product_template`, `options_template`, `manufacturers_id`, `products_manufacturers_model`, `products_ordered`, `products_fsk18`, `products_vpe`, `products_vpe_status`, `products_vpe_value`, `products_startpage`, `products_startpage_sort`) VALUES ('33','','1111','1','HO TPE  RF 1840','0','0','0','0','14','33_0.jpg','19.2857','0.00','2014-10-28 14:28:23','2014-11-01 18:48:30',NULL,'0.000','1','1','product_info_v1.html','product_options_selection.html','0','','0','0','0','0','0.0000','0','0');
INSERT INTO `products` (`products_id`, `products_ean`, `products_quantity`, `products_shippingtime`, `products_model`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `products_sort`, `products_image`, `products_price`, `products_discount_allowed`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_status`, `products_tax_class_id`, `product_template`, `options_template`, `manufacturers_id`, `products_manufacturers_model`, `products_ordered`, `products_fsk18`, `products_vpe`, `products_vpe_status`, `products_vpe_value`, `products_startpage`, `products_startpage_sort`) VALUES ('34','','111111','1','HO TPE  RF 0005','0','0','0','0','13','34_0.jpg','19.6639','0.00','2014-10-28 14:30:31','2014-11-01 18:48:10',NULL,'0.000','1','1','product_info_v1.html','product_options_selection.html','0','','0','0','0','0','0.0000','0','0');
INSERT INTO `products` (`products_id`, `products_ean`, `products_quantity`, `products_shippingtime`, `products_model`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `products_sort`, `products_image`, `products_price`, `products_discount_allowed`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_status`, `products_tax_class_id`, `product_template`, `options_template`, `manufacturers_id`, `products_manufacturers_model`, `products_ordered`, `products_fsk18`, `products_vpe`, `products_vpe_status`, `products_vpe_value`, `products_startpage`, `products_startpage_sort`) VALUES ('35','','11111','1','HO - FS - 0125','0','0','0','0','1','35_0.jpg','15.9244','0.00','2014-10-30 19:59:58','2014-11-01 18:49:18',NULL,'0.000','1','1','product_info_v1.html','product_options_selection.html','0','','0','0','0','0','0.0000','1','0');
INSERT INTO `products` (`products_id`, `products_ean`, `products_quantity`, `products_shippingtime`, `products_model`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `products_sort`, `products_image`, `products_price`, `products_discount_allowed`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_status`, `products_tax_class_id`, `product_template`, `options_template`, `manufacturers_id`, `products_manufacturers_model`, `products_ordered`, `products_fsk18`, `products_vpe`, `products_vpe_status`, `products_vpe_value`, `products_startpage`, `products_startpage_sort`) VALUES ('36','','1111','1','HO - FS - 0155','0','0','0','0','2','36_0.JPG','17.6050','0.00','2014-10-30 21:11:29','2014-11-01 18:49:46',NULL,'0.000','1','1','product_info_v1.html','product_options_selection.html','0','','0','0','0','0','0.0000','0','0');
INSERT INTO `products` (`products_id`, `products_ean`, `products_quantity`, `products_shippingtime`, `products_model`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `products_sort`, `products_image`, `products_price`, `products_discount_allowed`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_status`, `products_tax_class_id`, `product_template`, `options_template`, `manufacturers_id`, `products_manufacturers_model`, `products_ordered`, `products_fsk18`, `products_vpe`, `products_vpe_status`, `products_vpe_value`, `products_startpage`, `products_startpage_sort`) VALUES ('37','','1111','1','HO - FS - 0185','0','0','0','0','3','37_0.jpg','19.2857','0.00','2014-10-31 09:23:58','2014-11-01 18:50:36',NULL,'0.000','1','1','product_info_v1.html','product_options_selection.html','0','','0','0','0','0','0.0000','0','0');
INSERT INTO `products` (`products_id`, `products_ean`, `products_quantity`, `products_shippingtime`, `products_model`, `group_permission_0`, `group_permission_1`, `group_permission_2`, `group_permission_3`, `products_sort`, `products_image`, `products_price`, `products_discount_allowed`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_status`, `products_tax_class_id`, `product_template`, `options_template`, `manufacturers_id`, `products_manufacturers_model`, `products_ordered`, `products_fsk18`, `products_vpe`, `products_vpe_status`, `products_vpe_value`, `products_startpage`, `products_startpage_sort`) VALUES ('38','','1111','1','KL - 0001','0','0','0','0','0','38_0.jpg','5.0000','0.00','2014-10-31 10:12:15','2014-11-01 09:12:17',NULL,'0.000','1','1','product_info_v1.html','product_options_selection.html','0','','0','0','0','0','0.0000','0','0');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;

DROP TABLE IF EXISTS `products_attributes`;
CREATE TABLE `products_attributes` (
  `products_attributes_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL,
  `options_id` int(11) NOT NULL,
  `options_values_id` int(11) NOT NULL,
  `options_values_price` decimal(15,4) NOT NULL,
  `price_prefix` char(1) COLLATE latin1_german1_ci NOT NULL,
  `attributes_model` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  `attributes_stock` int(4) DEFAULT NULL,
  `options_values_weight` decimal(15,4) NOT NULL,
  `weight_prefix` char(1) COLLATE latin1_german1_ci NOT NULL,
  `sortorder` int(11) DEFAULT NULL,
  `attributes_ean` varchar(64) COLLATE latin1_german1_ci DEFAULT NULL,
  PRIMARY KEY (`products_attributes_id`),
  KEY `idx_products_id` (`products_id`),
  KEY `idx_options` (`options_id`,`options_values_id`)
) ENGINE=MyISAM AUTO_INCREMENT=748 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `products_attributes` DISABLE KEYS */;
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('747','7','1','5','42.0168','+','','1110','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('746','7','1','1','0.0000','+','','1101','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('740','9','1','1','0.0000','+','','1110','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('612','8','1','5','42.0168','+','','1107','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('611','8','1','1','0.0000','+','','1110','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('743','10','1','5','42.0168','+','','1111','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('742','10','1','1','0.0000','+','','11111','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('616','11','1','5','42.0168','+','','111111','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('630','20','2','10','0.0000','+','','1110','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('741','9','1','5','42.0168','+','','1110','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('657','25','2','9','0.0000','+','','1111','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('429','14','1','1','0.0000','+','','11110','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('433','15','1','1','0.0000','+','','1110','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('435','16','1','1','0.0000','+','','11111111','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('438','18','1','5','33.6555','+','','111','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('437','18','1','1','0.0000','+','','1111','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('680','30','1','4','53.3613','+','','2222','0.0000','+','3','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('681','30','2','8','0.0000','+','','1111','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('682','30','2','9','0.0000','+','','222','0.0000','+','3','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('656','25','2','8','0.0000','+','','1111','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('655','25','1','4','53.3613','+','','2222','0.0000','+','3','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('592','13','1','5','33.6555','+','','1110','22222.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('591','13','1','1','0.0000','+','','1111','2222.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('430','14','1','5','33.6555','+','','1111111','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('434','15','1','5','33.6555','+','','1111','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('436','16','1','5','33.6555','+','','1111','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('654','25','1','3','42.8571','+','','222','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('653','25','1','2','0.0000','+','','222','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('696','34','1','2','0.0000','+','','1111','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('697','34','1','3','55.9664','+','','11111','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('698','34','1','4','62.1849','+','','1111','0.0000','+','3','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('699','34','2','8','0.0000','+','','111','111.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('700','34','2','9','0.0000','+','','111','222.0000','+','3','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('701','34','2','10','0.0000','+','','1111','222.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('744','12','1','1','0.0000','+','','1111','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('444','32','2','10','0.0000','+','','100','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('443','32','2','9','0.0000','+','','100','0.0000','+','3','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('442','32','2','8','0.0000','+','','100','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('441','32','1','4','40.1681','+','','100','0.0000','+','3','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('440','32','1','3','28.5714','+','','100','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('439','32','1','2','0.0000','+','','100','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('745','12','1','5','42.0168','+','','1111111','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('683','30','2','10','0.0000','+','','2222','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('679','30','1','3','42.8571','+','','222','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('686','27','2','8','0.0000','+','','222','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('685','27','1','3','42.8571','+','','0','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('684','27','1','2','0.0000','+','','0','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('695','28','2','8','0.0000','+','','222','0.0000','+','0','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('693','28','1','3','42.8571','+','','222','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('694','28','1','4','53.3613','+','','2222','0.0000','+','3','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('652','23','2','8','0.0000','+','','1111','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('651','23','1','4','55.8824','+','','222','0.0000','+','3','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('650','23','1','3','44.5378','+','','222','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('649','23','1','2','0.0000','+','','222','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('504','24','1','2','0.0000','+','','222','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('505','24','1','3','52.1008','+','','222','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('506','24','1','4','64.7059','+','','222','0.0000','+','3','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('507','24','2','8','0.0000','+','','0','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('705','33','2','8','0.0000','+','','1111','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('704','33','1','4','64.7059','+','','222','0.0000','+','3','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('703','33','1','3','52.5210','+','','222','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('702','33','1','2','0.0000','+','','222','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('629','20','2','9','0.0000','+','','222','0.0000','+','3','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('628','20','2','8','0.0000','+','','224','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('627','20','1','4','44.5378','+','','222','0.0000','+','3','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('626','20','1','3','35.2941','+','','222','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('625','20','1','2','0.0000','+','','221','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('634','21','2','8','0.0000','+','','1111','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('633','21','1','4','46.2185','+','','222','0.0000','+','3','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('632','21','1','3','36.9748','+','','2222','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('631','21','1','2','0.0000','+','','2218','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('661','26','2','8','0.0000','+','','444','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('660','26','1','4','44.5378','+','','222','0.0000','+','3','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('659','26','1','3','35.2941','+','','222','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('658','26','1','2','0.0000','+','','222','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('648','22','2','8','0.0000','+','','2222','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('647','22','1','4','66.3866','+','','222','0.0000','+','3','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('646','22','1','3','52.5210','+','','222','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('671','29','2','8','0.0000','+','','1111','0.0000','+','0','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('670','29','1','4','57.1429','+','','222','0.0000','+','0','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('669','29','1','3','47.8992','+','','222','0.0000','+','0','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('711','35','2','10','0.0000','+','','111','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('710','35','2','9','0.0000','+','','111','0.0000','+','3','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('709','35','2','8','0.0000','+','','111','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('708','35','1','4','41.5966','+','','2222','0.0000','+','3','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('707','35','1','3','29.4118','+','','222','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('706','35','1','2','0.0000','+','','222','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('722','36','2','9','0.0000','+','','111','0.0000','+','3','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('721','36','2','8','0.0000','+','','1111','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('720','36','1','4','58.8235','+','','2222','0.0000','+','0','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('719','36','1','3','48.7395','+','','222','0.0000','+','0','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('734','37','2','9','0.0000','+','','111','0.0000','+','3','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('733','37','2','8','0.0000','+','','111','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('732','37','1','4','66.3866','+','','222','0.0000','+','3','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('731','37','1','3','54.6218','+','','2222','0.0000','+','2','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('615','11','1','1','0.0000','+','','1108','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('635','21','2','9','0.0000','+','','111','0.0000','+','3','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('636','21','2','10','0.0000','+','','4440','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('645','22','1','2','0.0000','+','','222','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('662','26','2','9','0.0000','+','','222','0.0000','+','3','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('663','26','2','10','0.0000','+','','2222','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('668','29','1','2','0.0000','+','','222222','0.0000','+','0','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('678','30','1','2','0.0000','+','','222','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('687','27','2','10','0.0000','+','','2222','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('692','28','1','2','0.0000','+','','222','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('723','36','2','10','0.0000','+','','1111','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('718','36','1','2','0.0000','+','','22222','0.0000','+','0','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('730','37','1','2','0.0000','+','','22222','0.0000','+','1','');
INSERT INTO `products_attributes` (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `attributes_model`, `attributes_stock`, `options_values_weight`, `weight_prefix`, `sortorder`, `attributes_ean`) VALUES ('735','37','2','10','0.0000','+','','111','0.0000','+','0','');
/*!40000 ALTER TABLE `products_attributes` ENABLE KEYS */;

DROP TABLE IF EXISTS `products_attributes_download`;
CREATE TABLE `products_attributes_download` (
  `products_attributes_id` int(11) NOT NULL,
  `products_attributes_filename` varchar(255) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `products_attributes_maxdays` int(2) DEFAULT '0',
  `products_attributes_maxcount` int(2) DEFAULT '0',
  PRIMARY KEY (`products_attributes_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `products_attributes_download` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_attributes_download` ENABLE KEYS */;

DROP TABLE IF EXISTS `products_content`;
CREATE TABLE `products_content` (
  `content_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL DEFAULT '0',
  `group_ids` text COLLATE latin1_german1_ci,
  `content_name` varchar(32) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `content_file` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `content_link` text COLLATE latin1_german1_ci NOT NULL,
  `languages_id` int(11) NOT NULL DEFAULT '0',
  `content_read` int(11) NOT NULL DEFAULT '0',
  `file_comment` text COLLATE latin1_german1_ci NOT NULL,
  PRIMARY KEY (`content_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `products_content` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_content` ENABLE KEYS */;

DROP TABLE IF EXISTS `products_description`;
CREATE TABLE `products_description` (
  `products_id` int(11) NOT NULL AUTO_INCREMENT,
  `language_id` tinyint(4) NOT NULL DEFAULT '1',
  `products_name` varchar(255) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `products_description` text COLLATE latin1_german1_ci,
  `products_short_description` text COLLATE latin1_german1_ci,
  `products_keywords` varchar(255) COLLATE latin1_german1_ci DEFAULT NULL,
  `products_meta_title` text COLLATE latin1_german1_ci NOT NULL,
  `products_meta_description` text COLLATE latin1_german1_ci NOT NULL,
  `products_meta_keywords` text COLLATE latin1_german1_ci NOT NULL,
  `products_url` varchar(255) COLLATE latin1_german1_ci DEFAULT NULL,
  `products_viewed` int(5) DEFAULT '0',
  `products_order_description` text COLLATE latin1_german1_ci,
  PRIMARY KEY (`products_id`,`language_id`),
  KEY `products_name` (`products_name`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `products_description` DISABLE KEYS */;
INSERT INTO `products_description` (`products_id`, `language_id`, `products_name`, `products_description`, `products_short_description`, `products_keywords`, `products_meta_title`, `products_meta_description`, `products_meta_keywords`, `products_url`, `products_viewed`, `products_order_description`) VALUES ('8','2','Fensterdichtung Silikon GO2','<p><span style=\"font-family: Verdana;\"><strong><font size=\"3\">Spezial - &nbsp;Fensterdichtung f&uuml;r Kunststofffenster aus Silikon GO 2</font></strong></span></p>\r\n<p><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\"><strong> - Fu&szlig;breite 5,5 mm - Stegbreite 3,5 mm<br />\r\n</strong><br />\r\n<br />\r\n- die&nbsp; Fensterdichtungen ben&ouml;tigen&nbsp; keinerlei &bdquo; Wartung &ldquo; und zus&auml;tzliche Pflege<br />\r\n<br />\r\n- das sehr weiche Material garantiert geringf&uuml;gigsten Schlie&szlig;druck&nbsp; ihrer Fenster<br />\r\n<br />\r\n- sehr hohe Alterungsbest&auml;ndigkeit im Temperaturbereich von -60 &deg; - +80&deg; Celsius.<br />\r\n<br />\r\n- kein Kleben der Fensterdichtungen am Fensterrahmen oder Fl&uuml;gel.<br />\r\n<br />\r\n- hohes R&uuml;ckstellverm&ouml;gen in Form und Funktion.<br />\r\n<br />\r\n- zus&auml;tzlich erh&ouml;ht unsere Hohlkammerdichtung den Schallschutz ihrer Fenster<br />\r\n<br />\r\n- sehr hoher Toleranzausgleich bei einer Spaltbreite von bis zu 7 mm <br />\r\n<br />\r\n</span><span style=\"font-family: Verdana;\">&nbsp; Anwendung finden unsere Fensterdichtungen GO 2 u.a. bei Fenstersystemen mit</span></span></p>\r\n<p><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\">&nbsp; Anschlagdichtungen&nbsp;</span></span><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\">u.a. bei den Herstellern: <strong>KBE &ndash; Roplasto &ndash; Sch&uuml;co -</strong></span></span></p>\r\n<p><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\"><strong>&nbsp;Salamander&nbsp; und Veka</strong></span></span><span style=\"font-family: Verdana;\"><span style=\"font-size: small;\"><br />\r\n</span></span></p>','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Breite::&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 8,0 mm<br />\r\nH&ouml;he::&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 7,0 mm <br />\r\nFu&szlig;breite:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 5 ,5 mm<br />\r\nStegbreite:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3,5 mm<br />\r\nFarbe:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; schwarz</span></span></p>','Fensterdichtungen kaufen, Fensterdichtung pfegen,Fensterdichtung Silikon, Dichtung,Fensterdichtung Kunststofffenster, Dichtung erneuern','Fensterdichtungen, Fensterdichtung','Fensterdichtung, Fensterdichtungen','Fensterdichtungen, Fensterdichtung,Fensterdichtung Silikon, Fensterdichtung erneuern, Fensterdichtung austauschen, Fensterdichtung Kunststofffenster, Fensterdichtunge','','47','');
INSERT INTO `products_description` (`products_id`, `language_id`, `products_name`, `products_description`, `products_short_description`, `products_keywords`, `products_meta_title`, `products_meta_description`, `products_meta_keywords`, `products_url`, `products_viewed`, `products_order_description`) VALUES ('9','2','Fensterdichtung Silikon GO3','<p><span style=\"font-size: medium;\">&nbsp;</span><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\"><strong>Spezial - Fensterdichtung f&uuml;r Kunststofffenster aus Silikon GO 3</strong></span></span></p>\r\n<p><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\"><strong> - Fu&szlig;breite 5,5 mm</strong></span></span><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\"><strong> - Stegbreite 3,5 mm<br />\r\n</strong><br />\r\n<br />\r\n- die&nbsp; Fensterdichtungen ben&ouml;tigen&nbsp; keinerlei &bdquo; Wartung &ldquo; und zus&auml;tzliche Pflege<br />\r\n<br />\r\n- das sehr weiche Material garantiert geringf&uuml;gigsten Schlie&szlig;druck&nbsp; ihrer Fenster<br />\r\n<br />\r\n- sehr hohe Alterungsbest&auml;ndigkeit im Temperaturbereich von -60 &deg; - +80&deg; Celsius.<br />\r\n<br />\r\n- kein Kleben der Fensterdichtungen am Fensterrahmen oder Fl&uuml;gel.<br />\r\n<br />\r\n- hohes R&uuml;ckstellverm&ouml;gen in Form und Funktion.<br />\r\n<br />\r\n- zus&auml;tzlich erh&ouml;ht unsere Hohlkammerdichtung den Schallschutz ihrer Fenster<br />\r\n<br />\r\n- sehr hoher Toleranzausgleich bei einer Spaltbreite von bis zu 9 mm <br />\r\n<br />\r\n</span><span style=\"font-family: Verdana;\">&nbsp; Anwendung finden unsere Fensterdichtungen GO 3 u.a. bei Fenstersystemen mit</span></span></p>\r\n<p><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\"> </span></span><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\">&nbsp; Anschlagsdichtung.&nbsp;</span></span><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\">u.a. bei den Herstellern: <strong>KBE &ndash; Roplasto &ndash; Sch&uuml;co&nbsp; und Veka</strong></span></span><span style=\"font-family: Verdana;\"><span style=\"font-size: small;\"><br />\r\n</span></span></p>','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Breite::&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 9 mm<br />\r\nH&ouml;he::&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 9 mm <br />\r\nFu&szlig;breite: &nbsp; &nbsp; &nbsp; 5 ,5 mm<br />\r\nStegbreite:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3,5 mm<br />\r\nFarbe:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; schwarz</span></span></p>','Fensterdichtungen kaufen, Fensterdichtung pfegen,Fensterdichtung Silikon, Dichtung,Fensterdichtung Kunststofffenster, Dichtung erneuern','Fensterdichtungen, Fensterdichtung,','Fensterdichtung, Fensterdichtungen,Fensterdichtung Silikon, Fensterdichtung kaufen, Fensterdichtung pflegen','Fensterdichtungen, Fensterdichtung,Fensterdichtung Silikon, Fensterdichtung erneuern, Fensterdichtung austauschen, Fensterdichtung Kunststofffenster, Fensterdichtunge','','11','');
INSERT INTO `products_description` (`products_id`, `language_id`, `products_name`, `products_description`, `products_short_description`, `products_keywords`, `products_meta_title`, `products_meta_description`, `products_meta_keywords`, `products_url`, `products_viewed`, `products_order_description`) VALUES ('10','2','Fensterdichtung Silikon KO1','<p><span style=\"font-size: medium;\"> </span><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\"><strong>Spezial - Fensterdichtung f&uuml;r Kunststofffenster aus Silikon KO 1</strong></span><br />\r\n</span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><strong> - Fu&szlig;breite 3,5 mm - Stegbreite 2 mm<br />\r\n</strong><br />\r\n<br />\r\n- die&nbsp; Fensterdichtungen ben&ouml;tigen&nbsp; keinerlei &bdquo; Wartung &ldquo; und zus&auml;tzliche Pflege<br />\r\n<br />\r\n- das sehr weiche Material garantiert geringf&uuml;gigsten Schlie&szlig;druck&nbsp; ihrer Fenster<br />\r\n<br />\r\n- sehr hohe Alterungsbest&auml;ndigkeit im Temperaturbereich von -60 &deg; - +80&deg; Celsius.<br />\r\n<br />\r\n- kein Kleben der Fensterdichtungen am Fensterrahmen oder Fl&uuml;gel.<br />\r\n<br />\r\n- hohes R&uuml;ckstellverm&ouml;gen in Form und Funktion.<br />\r\n<br />\r\n- zus&auml;tzlich erh&ouml;ht unsere Hohlkammerdichtung den Schallschutz ihrer Fenster<br />\r\n<br />\r\n- sehr hoher Toleranzausgleich bei einer Spaltbreite von bis zu 9 mm <br />\r\n<br />\r\n&nbsp;Anwendung finden unsere Fensterdichtungen KO 1 u.a. bei Fenstersystemen </span></span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">&nbsp;mit Anschlagsdichtung&nbsp;</span></span><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\">u.a. bei den Herstellern: <strong>K&ouml;mmerling - Rehau</strong></span></span><span style=\"font-family: Verdana;\"><span style=\"font-size: small;\"><br />\r\n</span></span></p>','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Breite::&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 9,0 mm<br />\r\nH&ouml;he::&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 9,0 mm<span style=\"font-size: small;\"> </span><br />\r\nFu&szlig;breite:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3 ,5 mm<br />\r\nStegbreite:&nbsp;&nbsp;&nbsp;&nbsp; 2,0 mm<br />\r\nFarbe:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; schwarz</span></span></p>','Fensterdichtungen kaufen, Fensterdichtung pfegen,Fensterdichtung Silikon, Dichtung,Fensterdichtung Kunststofffenster, Dichtung erneuern','Fensterdichtungen, Fensterdichtung','Fensterdichtung, Fensterdichtungen,Fensterdichtung Silikon, Fensterdichtung kaufen, Fensterdichtung pflegen','Fensterdichtungen, Fensterdichtung,Fensterdichtung Silikon, Fensterdichtung erneuern, Fensterdichtungen austauschen, Fensterdichtung Kunststofffenster, Fensterdichtunge','','35','');
INSERT INTO `products_description` (`products_id`, `language_id`, `products_name`, `products_description`, `products_short_description`, `products_keywords`, `products_meta_title`, `products_meta_description`, `products_meta_keywords`, `products_url`, `products_viewed`, `products_order_description`) VALUES ('11','2','Fensterdichtung Silikon KO2','<p>&nbsp;<span style=\"font-size: medium;\"> </span><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\"><strong>Spezial - Fensterdichtung f&uuml;r Kunststofffenster aus Silikon KO 2</strong></span><br />\r\n</span></p>\r\n<p><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\"><strong> - Fu&szlig;breite 3,5 mm - Stegbreite 2 mm<br />\r\n</strong><br />\r\n<br />\r\n- die&nbsp; Fensterdichtungen ben&ouml;tigen&nbsp; keinerlei &bdquo; Wartung &ldquo; und zus&auml;tzliche Pflege<br />\r\n<br />\r\n- das sehr weiche Material garantiert geringf&uuml;gigsten Schlie&szlig;druck&nbsp; ihrer Fenster<br />\r\n<br />\r\n- sehr hohe Alterungsbest&auml;ndigkeit im Temperaturbereich von -60 &deg; - +80&deg; Celsius.<br />\r\n<br />\r\n- kein Kleben der Fensterdichtungen am Fensterrahmen oder Fl&uuml;gel.<br />\r\n<br />\r\n- hohes R&uuml;ckstellverm&ouml;gen in Form und Funktion.<br />\r\n<br />\r\n- zus&auml;tzlich erh&ouml;ht unsere Hohlkammerdichtung den Schallschutz ihrer Fenster<br />\r\n<br />\r\n- sehr hoher Toleranzausgleich bei einer Spaltbreite von bis zu 7 mm <br />\r\n<br />\r\n</span><span style=\"font-family: Verdana;\"><br />\r\n&nbsp;Anwendung finden unsere Fensterdichtungen KO 2 u.a. bei Fenstersystemen mit </span></span></p>\r\n<p><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\">&nbsp;Anschlagsdichtung</span></span><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\">u.a. bei den Herstellern: <strong>K&ouml;mmerling - Rehau</strong></span></span><span style=\"font-family: Verdana;\"><span style=\"font-size: small;\"><br />\r\n</span></span></p>','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Breite::&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 8,0 mm<br />\r\nH&ouml;he::&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 7,0 mm <br />\r\nFu&szlig;breite:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3 ,5 mm<br />\r\nStegbreite:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2,0 mm<br />\r\nFarbe:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; schwarz</span></span></p>','Fensterdichtungen kaufen, Fensterdichtung pfegen,Fensterdichtung Silikon, Dichtung,Fensterdichtung Kunststofffenster, Dichtung erneuern','Fensterdichtungen, Fensterdichtung','Fensterdichtung, Fensterdichtungen,Fensterdichtung Silikon, Fensterdichtung kaufen, Fensterdichtung pflegen','Fensterdichtungen, Fensterdichtung,Fensterdichtung Silikon, Fensterdichtung erneuern, Fensterdichtung austauschen, Fensterdichtung Kunststofffenster, Fensterdichtunge','','21','');
INSERT INTO `products_description` (`products_id`, `language_id`, `products_name`, `products_description`, `products_short_description`, `products_keywords`, `products_meta_title`, `products_meta_description`, `products_meta_keywords`, `products_url`, `products_viewed`, `products_order_description`) VALUES ('12','2','Fensterdichtung Silikon MO1','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><strong>Spezial - Fensterdichtung f&uuml;r Kunststofffenster aus Silikon MO 1 </strong><br />\r\n</span></span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><strong>- Fu&szlig;breite 4,5 mm - Stegbreite 3 mm<br />\r\n</strong><br />\r\n<br />\r\n- die&nbsp; Fensterdichtungen ben&ouml;tigen&nbsp; keinerlei &bdquo; Wartung &ldquo; und zus&auml;tzliche Pflege<br />\r\n<br />\r\n- das sehr weiche Material garantiert geringf&uuml;gigsten Schlie&szlig;druck&nbsp; ihrer Fenster<br />\r\n<br />\r\n- sehr hohe Alterungsbest&auml;ndigkeit im Temperaturbereich von -60 &deg; - +80&deg; Celsius.<br />\r\n<br />\r\n- kein Kleben der Fensterdichtungen am Fensterrahmen oder Fl&uuml;gel.<br />\r\n<br />\r\n- hohes R&uuml;ckstellverm&ouml;gen in Form und Funktion.<br />\r\n<br />\r\n- zus&auml;tzlich erh&ouml;ht unsere Hohlkammerdichtung den Schallschutz ihrer Fenster<br />\r\n<br />\r\n- sehr hoher Toleranzausgleich bei einer Spaltbreite von bis zu 8,5 mm <br />\r\n<br />\r\n&nbsp; Anwendung finden unsere Fensterdichtungen MO 1 u.a. bei Fenstersystemen mit </span></span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">&nbsp; Anschlagsdichtung</span><span style=\"font-size: medium;\">&nbsp;</span><span style=\"font-size: medium;\">u.a. bei den Herstellern: <strong>Aluplast - Gealan -&nbsp; KBE&nbsp; </strong><br />\r\n</span></span></p>\r\n<p><span style=\"font-family: Verdana;\">&nbsp;</span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">&nbsp;</span></span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">&nbsp;</span></span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">&nbsp;</span></span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">&nbsp;</span></span></p>','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Breite::&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 8,5 mm<br />\r\nH&ouml;he::&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 8,5 mm <br />\r\nFu&szlig;breite:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 4 ,5 mm<br />\r\nStegbreite:&nbsp;&nbsp;&nbsp;&nbsp; 3,0 mm<br />\r\nFarbe:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; schwarz</span></span></p>','Fensterdichtungen kaufen, Fensterdichtung pfegen,Fensterdichtung Silikon, Dichtung,Fensterdichtung Kunststofffenster, Dichtung erneuern','Fensterdichtungen, Fensterdichtung','Fensterdichtung, Fensterdichtungen,Fensterdichtung Silikon, Fensterdichtung kaufen, Fensterdichtung pflegen','F','','10','');
INSERT INTO `products_description` (`products_id`, `language_id`, `products_name`, `products_description`, `products_short_description`, `products_keywords`, `products_meta_title`, `products_meta_description`, `products_meta_keywords`, `products_url`, `products_viewed`, `products_order_description`) VALUES ('7','2','Fensterdichtung Silikon GO1','<p><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\"><strong>Spezial - Fensterdichtung f&uuml;r Kunststofffenster aus Silikon GO 1</strong></span></span></p>\r\n<p><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\"><strong> - Fu&szlig;breite 5,5 mm - Stegbreite 4 mm<br />\r\n</strong><br />\r\n<br />\r\n- die&nbsp; Fensterdichtungen ben&ouml;tigen&nbsp; keinerlei &bdquo; Wartung &ldquo; und zus&auml;tzliche Pflege<br />\r\n<br />\r\n- das sehr weiche Material garantiert geringf&uuml;gigsten Schlie&szlig;druck&nbsp; ihrer Fenster<br />\r\n<br />\r\n- sehr hohe Alterungsbest&auml;ndigkeit im Temperaturbereich von -60 &deg; - +80&deg; Celsius.<br />\r\n<br />\r\n- kein Kleben der Fensterdichtungen am Fensterrahmen oder Fl&uuml;gel.<br />\r\n<br />\r\n- hohes R&uuml;ckstellverm&ouml;gen in Form und Funktion.<br />\r\n<br />\r\n- zus&auml;tzlich erh&ouml;ht unsere Hohlkammerdichtung den Schallschutz ihrer Fenster<br />\r\n<br />\r\n- sehr hoher Toleranzausgleich bei einer Spaltbreite von bis zu 9 mm <br />\r\n</span><span style=\"font-family: Verdana;\"><br />\r\n&nbsp; Anwendung finden unsere Fensterdichtungen GO 1 u.a. bei Fenstersystemen mit </span></span></p>\r\n<p><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\">&nbsp; Anschlagsdichtung&nbsp;</span></span><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\">u.a. bei den Herstellern: <strong>KBE &ndash; Roplasto &ndash; Sch&uuml;co&nbsp; und Veka</strong><br />\r\n</span></span><span style=\"font-family: Verdana;\"><span style=\"font-size: small;\"><br />\r\n</span></span></p>','<p><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\">Breite::&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 9,0 mm<br />\r\nH&ouml;he::&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 9,0 mm <br />\r\nFu&szlig;breite:&nbsp;&nbsp;&nbsp;&nbsp; 5 ,5 mm<br />\r\nStegbreite:&nbsp;&nbsp;&nbsp; 4,0 mm<br />\r\nFarbe:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; schwarz</span></span></p>','Fensterdichtungen kaufen, Fensterdichtung pfegen,Fensterdichtung Silikon, Dichtung,Fensterdichtung Kunststofffenster, Dichtung erneuern','','','Fensterdichtungen, Fensterdichtung,Fensterdichtung Silikon, Fensterdichtung erneuern, Fensterdichtung austauschen, Fensterdichtung Kunststofffenster, Fensterdichtunge','','54','');
INSERT INTO `products_description` (`products_id`, `language_id`, `products_name`, `products_description`, `products_short_description`, `products_keywords`, `products_meta_title`, `products_meta_description`, `products_meta_keywords`, `products_url`, `products_viewed`, `products_order_description`) VALUES ('13','2','Fensterdichtung Gealan','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Typische Einsatzgebiete von TPE Dichtungen:<br />\r\n<br />\r\nFenster, Haust&uuml;ren, Innent&uuml;ren, Stahlzargen, Br&uuml;stungen <br />\r\n<br />\r\nHolz, Holz - Alu. Kunststoff, Aluminium inen und au&szlig;en<br />\r\n<br />\r\nMaterialvorteile:<br />\r\n<br />\r\n- UV -&nbsp; und witterungsbest&auml;ndig<br />\r\n<br />\r\n- gutes R&uuml;ckstellverm&ouml;gen<br />\r\n<br />\r\n- glatte Oberfl&auml;che<br />\r\n<br />\r\n- gute Schwei&szlig;barkeit<br />\r\n<br />\r\n- vertr&auml;glich mit alle umweltfreundlichen Lacken<br />\r\n<br />\r\n&nbsp; sowie wasserverd&uuml;nnbaren Acrylat - Lacken<br />\r\n<br />\r\n- 100 % recyclingf&auml;hig</span></span></p>','<p><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\"><strong>Dichtungstyp: 02 G - 1000 aus TPE<br />\r\n</strong><br />\r\nBreite::&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 9,0 &nbsp; mm<br />\r\nges.H&ouml;he:&nbsp;&nbsp;&nbsp; 10,0&nbsp; mm <br />\r\nFu&szlig;breite:&nbsp;&nbsp;&nbsp; 5,0 &nbsp; mm<br />\r\nStegbreite:&nbsp;&nbsp; 3,9 &nbsp; mm<br />\r\nFarbe:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; schwarz</span></span></p>','Fensterdichtung Kunststofffenster','Fensterdichtung Kunststofffenster, Fensterdichtung','','Fensterdichtungen,Fensterdichtung,Fensterdichtung erneuern, Fensterdichtung austauschen, Fensterdichtung Kunststofffenster, Fensterundicht','','22','');
INSERT INTO `products_description` (`products_id`, `language_id`, `products_name`, `products_description`, `products_short_description`, `products_keywords`, `products_meta_title`, `products_meta_description`, `products_meta_keywords`, `products_url`, `products_viewed`, `products_order_description`) VALUES ('14','2','Fensterdichtung Heroal','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Typische Einsatzgebiete von TPE Dichtungen:<br />\r\n<br />\r\nFenster, Haust&uuml;ren, Innent&uuml;ren, Stahlzargen, Br&uuml;stungen <br />\r\n<br />\r\nHolz, Holz - Alu. Kunststoff, Aluminium innen und au&szlig;en<br />\r\n<br />\r\nMaterialvorteile:<br />\r\n<br />\r\n- UV -&nbsp; und witterungsbest&auml;ndig<br />\r\n<br />\r\n- gutes R&uuml;ckstellverm&ouml;gen<br />\r\n<br />\r\n- glatte Oberfl&auml;che<br />\r\n<br />\r\n- gute Schwei&szlig;barkeit<br />\r\n<br />\r\n- vertr&auml;glich mit alle umweltfreundlichen Lacken<br />\r\n<br />\r\n&nbsp; sowie wasserverd&uuml;nnbaren Acrylat - Lacken<br />\r\n<br />\r\n- 100 % recyclingf&auml;hig</span></span></p>','<p><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\"><strong>Dichtungstyp: 02 H - 1000 aus TPE<br />\r\n</strong><br />\r\nBreite::&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 6,0 &nbsp; mm<br />\r\nges.H&ouml;he:&nbsp;&nbsp;&nbsp; 10,0&nbsp; mm <br />\r\nFu&szlig;breite:&nbsp;&nbsp;&nbsp; 4,0 &nbsp; mm<br />\r\nStegbreite:&nbsp;&nbsp; 3,0 &nbsp; mm<br />\r\nFarbe:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; schwarz</span></span></p>','Fensterdichtungen kaufen, Fensterdichtung pfegen,Fensterdichtung Silikon, Dichtung,Fensterdichtung Kunststofffenster, Dichtung erneuern','Fensterdichungen, Fensterdichtung','','Fensterdichtungen, Fensterdichtung,Fensterdichtung Silikon, Fensterdichtung erneuern, Fensterdichtung austauschen, Fensterdichtung Kunststofffenster, Fensterdichtunge','','6','');
INSERT INTO `products_description` (`products_id`, `language_id`, `products_name`, `products_description`, `products_short_description`, `products_keywords`, `products_meta_title`, `products_meta_description`, `products_meta_keywords`, `products_url`, `products_viewed`, `products_order_description`) VALUES ('15','2','Fensterdichtung Kömmerling','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Typische Einsatzgebiete von TPE Dichtungen:<br />\r\n<br />\r\nFenster, Haust&uuml;ren, Innent&uuml;ren, Stahlzargen, Br&uuml;stungen <br />\r\n<br />\r\nHolz, Holz - Alu. Kunststoff, Aluminium innen und au&szlig;en<br />\r\n<br />\r\nMaterialvorteile:<br />\r\n<br />\r\n- UV -&nbsp; und witterungsbest&auml;ndig<br />\r\n<br />\r\n- gutes R&uuml;ckstellverm&ouml;gen<br />\r\n<br />\r\n- glatte Oberfl&auml;che<br />\r\n<br />\r\n- gute Schwei&szlig;barkeit<br />\r\n<br />\r\n- vertr&auml;glich mit alle umweltfreundlichen Lacken<br />\r\n<br />\r\n&nbsp; sowie wasserverd&uuml;nnbaren Acrylat - Lacken<br />\r\n<br />\r\n- 100 % recyclingf&auml;hig</span></span></p>','<p><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\"><strong>Dichtungstyp: 02 K - 1000 aus TPE<br />\r\n</strong><br />\r\nBreite::&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 8,0 &nbsp; mm<br />\r\nges.H&ouml;he:&nbsp;&nbsp;&nbsp; 11,0&nbsp; mm <br />\r\nFu&szlig;breite:&nbsp;&nbsp;&nbsp; 4,5 &nbsp; mm<br />\r\nStegbreite:&nbsp;&nbsp; 3,9 &nbsp; mm<br />\r\nFarbe:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; schwarz</span></span></p>','Fensterdichtungen kaufen, Fensterdichtung pfegen,Fensterdichtung Silikon, Dichtung,Fensterdichtung Kunststofffenster, Dichtung erneuern','Fensterdichtungen, Fensterdichtung','','Fensterdichtungen, Fensterdichtung,Fensterdichtung Silikon, Fensterdichtung erneuern, Fensterdichtung austauschen, Fensterdichtung Kunststofffenster, Fensterdichtunge','','16','');
INSERT INTO `products_description` (`products_id`, `language_id`, `products_name`, `products_description`, `products_short_description`, `products_keywords`, `products_meta_title`, `products_meta_description`, `products_meta_keywords`, `products_url`, `products_viewed`, `products_order_description`) VALUES ('16','2','Fensterdichtung Salamander','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Typische Einsatzgebiete von TPE Dichtungen:<br />\r\n<br />\r\nFenster, Haust&uuml;ren, Innent&uuml;ren, Stahlzargen, Br&uuml;stungen <br />\r\n<br />\r\nHolz, Holz - Alu. Kunststoff, Aluminium innen und au&szlig;en<br />\r\n<br />\r\nMaterialvorteile:<br />\r\n<br />\r\n- UV -&nbsp; und witterungsbest&auml;ndig<br />\r\n<br />\r\n- gutes R&uuml;ckstellverm&ouml;gen<br />\r\n<br />\r\n- glatte Oberfl&auml;che<br />\r\n<br />\r\n- gute Schwei&szlig;barkeit<br />\r\n<br />\r\n- vertr&auml;glich mit alle umweltfreundlichen Lacken<br />\r\n<br />\r\n&nbsp; sowie wasserverd&uuml;nnbaren Acrylat - Lacken<br />\r\n<br />\r\n- 100 % recyclingf&auml;hig</span></span></p>','<p><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\"><strong>Dichtungstyp: 02 S - 1000 aus TPE<br />\r\n</strong><br />\r\nBreite::&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 8,0 &nbsp; mm<br />\r\nges.H&ouml;he:&nbsp;&nbsp;&nbsp; 11,5&nbsp; mm <br />\r\nFu&szlig;breite:&nbsp;&nbsp;&nbsp; 5,0 &nbsp; mm<br />\r\nStegbreite:&nbsp;&nbsp; 3,0 &nbsp; mm<br />\r\nFarbe:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; schwarz</span></span></p>','Fensterdichtungen kaufen, Fensterdichtung pfegen,Fensterdichtung Silikon, Dichtung,Fensterdichtung Kunststofffenster, Dichtung erneuern','Fensterdichtungen, Fensterdichtung','','Fensterdichtungen, Fensterdichtung,Fensterdichtung Silikon, Fensterdichtung erneuern, Fensterdichtung austauschen, Fensterdichtung Kunststofffenster, Fensterdichtunge','','3','');
INSERT INTO `products_description` (`products_id`, `language_id`, `products_name`, `products_description`, `products_short_description`, `products_keywords`, `products_meta_title`, `products_meta_description`, `products_meta_keywords`, `products_url`, `products_viewed`, `products_order_description`) VALUES ('18','2','Fensterdichtung Veka','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Typische Einsatzgebiete von TPE Dichtungen:<br />\r\n<br />\r\nFenster, Haust&uuml;ren, Innent&uuml;ren, Stahlzargen, Br&uuml;stungen <br />\r\n<br />\r\nHolz, Holz - Alu. Kunststoff, Aluminium innen und au&szlig;en<br />\r\n<br />\r\nMaterialvorteile:<br />\r\n<br />\r\n- UV -&nbsp; und witterungsbest&auml;ndig<br />\r\n<br />\r\n- gutes R&uuml;ckstellverm&ouml;gen<br />\r\n<br />\r\n- glatte Oberfl&auml;che<br />\r\n<br />\r\n- gute Schwei&szlig;barkeit<br />\r\n<br />\r\n- vertr&auml;glich mit alle umweltfreundlichen Lacken<br />\r\n<br />\r\n&nbsp; sowie wasserverd&uuml;nnbaren Acrylat - Lacken<br />\r\n<br />\r\n- 100 % recyclingf&auml;hig</span></span></p>','<p><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\"><strong>Dichtungstyp: 02 V - 1000 aus TPE<br />\r\n</strong><br />\r\nBreite::&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 9,0 &nbsp; mm<br />\r\nges.H&ouml;he:&nbsp;&nbsp;&nbsp; 12,0&nbsp; mm <br />\r\nFu&szlig;breite:&nbsp;&nbsp;&nbsp; 5,5 &nbsp; mm<br />\r\nStegbreite:&nbsp;&nbsp; 4,5 &nbsp; mm<br />\r\nFarbe:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; schwarz</span></span></p>','Fensterdichtungen kaufen, Fensterdichtung pfegen,Fensterdichtung Silikon, Dichtung,Fensterdichtung Kunststofffenster, Dichtung erneuern','Fensterdichtungen, Fensterdichtung','','Fensterdichtungen, Fensterdichtung,Fensterdichtung Silikon, Fensterdichtung erneuern, Fensterdichtungen austauschen, Fensterdichtung Kunststofffenster, Fensterdichtunge','','18','');
INSERT INTO `products_description` (`products_id`, `language_id`, `products_name`, `products_description`, `products_short_description`, `products_keywords`, `products_meta_title`, `products_meta_description`, `products_meta_keywords`, `products_url`, `products_viewed`, `products_order_description`) VALUES ('20','2','Holzfensterdichtungen HO TPE RF 0002','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><strong>Eigenschaften:</strong><br />\r\n<br />\r\n- gutes R&uuml;ckstellverm&ouml;gen, leichter Einbau<br />\r\n<br />\r\n- zum verschwei&szlig;en und kleben geeignet<br />\r\n<br />\r\n- vertr&auml;glich mit Kunstharz - und DD- Lacken.<br />\r\n<br />\r\n- temperaturbest&auml;ndig -45 Celsius bis + 65 Celsius<br />\r\n<br />\r\n- alterungs-, witterungs-, lichtriss- und ozonbest&auml;ndig. <br />\r\n<br />\r\n- hohe Lebensdauer in Form und Funktion.</span></span></p>','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Kopfbreite&nbsp; =&nbsp;&nbsp;&nbsp; 8,0 mm<br />\r\nFalzh&ouml;he&nbsp;&nbsp;&nbsp; =&nbsp; 12,0 mm <br />\r\nNutbreite&nbsp;&nbsp; =&nbsp;&nbsp;&nbsp; 5,0 mm <br />\r\nges. H&ouml;he&nbsp; =&nbsp; 19,0 mm</span></span></p>','','','','','','30','');
INSERT INTO `products_description` (`products_id`, `language_id`, `products_name`, `products_description`, `products_short_description`, `products_keywords`, `products_meta_title`, `products_meta_description`, `products_meta_keywords`, `products_url`, `products_viewed`, `products_order_description`) VALUES ('21','2','Holzfensterdichtungen HO TPE RF 0003','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><strong>Eigenschaften:</strong><br />\r\n<br />\r\n- gutes R&uuml;ckstellverm&ouml;gen, leichter Einbau<br />\r\n<br />\r\n- zum verschwei&szlig;en und kleben geeignet<br />\r\n<br />\r\n- vertr&auml;glich mit Kunstharz - und DD- Lacken.<br />\r\n<br />\r\n- temperaturbest&auml;ndig -45 Celsius bis + 65 Celsius<br />\r\n<br />\r\n- alterungs-, witterungs-, lichtriss- und ozonbest&auml;ndig. <br />\r\n<br />\r\n- hohe Lebensdauer in Form und Funktion.</span></span></p>','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: small;\"><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Kopfbreite&nbsp; =&nbsp;&nbsp;&nbsp; 8,5 mm<br />\r\nFalzh&ouml;he&nbsp;&nbsp;&nbsp; =&nbsp; 12,0 mm <br />\r\nNutbreite&nbsp;&nbsp; =&nbsp;&nbsp;&nbsp; 5,0 mm <br />\r\nges. H&ouml;he&nbsp; =&nbsp; 19,0 mm</span></span></span> </span></span></p>','Fensterdichtungen kaufen, Fensterdichtung pfegen,Fensterdichtung Silikon, Dichtung,Fensterdichtung Kunststofffenster, Dichtung erneuern','Fensterdichtung Holzfenster, Dichtung Holzfenster,','Fensterdichtung Holzfenster, Fensterdichtung Holzfenster kaufen, Dichtung Holzfenster, Fensterdichtung austauschen,Fensterdichtung, Fensterd','Fensterdichtungen Holzfenster, Fensterdichtung Holzfenster kaufen, Dichtung Holzfenster,Fenster undicht, Fenterdichtung pflegen. Holzfensterdichtung','','12','');
INSERT INTO `products_description` (`products_id`, `language_id`, `products_name`, `products_description`, `products_short_description`, `products_keywords`, `products_meta_title`, `products_meta_description`, `products_meta_keywords`, `products_url`, `products_viewed`, `products_order_description`) VALUES ('22','2','Holzfensterdichtungen HO TPE RF 0012','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><strong>Eigenschaften:</strong><br />\r\n<br />\r\n- gutes R&uuml;ckstellverm&ouml;gen, leichter Einbau<br />\r\n<br />\r\n- zum verschwei&szlig;en und kleben geeignet<br />\r\n<br />\r\n- vertr&auml;glich mit Kunstharz - und DD- Lacken.<br />\r\n<br />\r\n- temperaturbest&auml;ndig -45 Celsius bis + 65 Celsius<br />\r\n<br />\r\n- alterungs-, witterungs-, lichtriss- und ozonbest&auml;ndig. <br />\r\n<br />\r\n- hohe Lebensdauer in Form und Funktion.</span></span></p>','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: small;\"><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Kopfbreite&nbsp; =&nbsp;&nbsp;&nbsp; 9,5 mm<br />\r\nFalzh&ouml;he&nbsp;&nbsp;&nbsp; =&nbsp; 12,0 mm <br />\r\nNutbreite&nbsp;&nbsp; =&nbsp;&nbsp;&nbsp; 5,0 mm <br />\r\nges. H&ouml;he&nbsp; =&nbsp; 19,0 mm</span></span></span></span></span></p>','Fensterdichtungen kaufen, Fensterdichtung pfegen,Fensterdichtung Silikon, Dichtung,Fensterdichtung Kunststofffenster, Dichtung erneuern','Fensterdichtung Holzfenster, Dichtung Holzfenster,','Fensterdichtung Holzfenster, Fensterdichtung Holzfenster kaufen, Dichtung Holzfenster, Fensterdichtung austauschen,Fensterdichtung, Fensterd','Fensterdichtungen Holzfenster, Fensterdichtung Holzfenster kaufen, Dichtung Holzfenster,Fenster undicht, Fenterdichtung pflegen. Holzfensterdichtung','','8','');
INSERT INTO `products_description` (`products_id`, `language_id`, `products_name`, `products_description`, `products_short_description`, `products_keywords`, `products_meta_title`, `products_meta_description`, `products_meta_keywords`, `products_url`, `products_viewed`, `products_order_description`) VALUES ('23','2','Holzfensterdichtung HO TPE RF 0022','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><strong>Eigenschaften:</strong><br />\r\n<br />\r\n- gutes R&uuml;ckstellverm&ouml;gen, leichter Einbau<br />\r\n<br />\r\n- zum verschwei&szlig;en und kleben geeignet<br />\r\n<br />\r\n- vertr&auml;glich mit Kunstharz - und DD- Lacken.<br />\r\n<br />\r\n- temperaturbest&auml;ndig -45 Celsius bis + 65 Celsius<br />\r\n<br />\r\n- alterungs-, witterungs-, lichtriss- und ozonbest&auml;ndig. <br />\r\n<br />\r\n- hohe Lebensdauer in Form und Funktion.</span></span></p>','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Kopfbreite&nbsp; =&nbsp;&nbsp;&nbsp; 8,0 mm<br />\r\nFalzh&ouml;he&nbsp;&nbsp;&nbsp; =&nbsp; 12,0 mm <br />\r\nNutbreite&nbsp;&nbsp; =&nbsp;&nbsp;&nbsp; 5,0 mm <br />\r\nges. H&ouml;he&nbsp; =&nbsp; 19,0 mm</span></span></p>','Fensterdichtungen kaufen, Fensterdichtung pfegen,Fensterdichtung Silikon, Dichtung,Fensterdichtung Kunststofffenster, Dichtung erneuern','Fensterdichtung Holzfenster, Dichtung Holzfenster,','Fensterdichtung Holzfenster, Fensterdichtung Holzfenster kaufen, Dichtung Holzfenster, Fensterdichtung austauschen,Fensterdichtung, Fensterd','Fensterdichtungen Holzfenster, Fensterdichtung Holzfenster kaufen, Dichtung Holzfenster,Fenster undicht, Fenterdichtung pflegen. Holzfensterdichtung','','1','');
INSERT INTO `products_description` (`products_id`, `language_id`, `products_name`, `products_description`, `products_short_description`, `products_keywords`, `products_meta_title`, `products_meta_description`, `products_meta_keywords`, `products_url`, `products_viewed`, `products_order_description`) VALUES ('24','2','Holzfensterdichtung HO TPE RF 0023','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><strong>Eigenschaften:</strong><br />\r\n<br />\r\n- gutes R&uuml;ckstellverm&ouml;gen, leichter Einbau<br />\r\n<br />\r\n- zum verschwei&szlig;en und kleben geeignet<br />\r\n<br />\r\n- vertr&auml;glich mit Kunstharz - und DD- Lacken.<br />\r\n<br />\r\n- temperaturbest&auml;ndig -45 Celsius bis + 65 Celsius<br />\r\n<br />\r\n- alterungs-, witterungs-, lichtriss- und ozonbest&auml;ndig. <br />\r\n<br />\r\n- hohe Lebensdauer in Form und Funktion.</span></span></p>','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Kopfbreite&nbsp; =&nbsp;&nbsp;&nbsp; 8,5 mm ( 3,0 Seitlich )<br />\r\nFalzh&ouml;he&nbsp;&nbsp;&nbsp; =&nbsp; 12,0 mm <br />\r\nNutbreite&nbsp;&nbsp; =&nbsp;&nbsp;&nbsp; 5,0 mm <br />\r\nges. H&ouml;he&nbsp; =&nbsp; 19,0 mm</span></span></p>','Fensterdichtungen kaufen, Fensterdichtung pfegen,Fensterdichtung Silikon, Dichtung,Fensterdichtung Kunststofffenster, Dichtung erneuern','Fensterdichtung Holzfenster, Dichtung Holzfenster,','Fensterdichtung Holzfenster, Fensterdichtung Holzfenster kaufen, Dichtung Holzfenster, Fensterdichtung austauschen,Fensterdichtung, Fensterd','Fensterdichtungen Holzfenster, Fensterdichtung Holzfenster kaufen, Dichtung Holzfenster,Fenster undicht, Fenterdichtung pflegen. Holzfensterdichtung','','4','');
INSERT INTO `products_description` (`products_id`, `language_id`, `products_name`, `products_description`, `products_short_description`, `products_keywords`, `products_meta_title`, `products_meta_description`, `products_meta_keywords`, `products_url`, `products_viewed`, `products_order_description`) VALUES ('25','2','Holzfensterdichtung HO TPE RF 0009','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><strong>Eigenschaften:</strong><br />\r\n<br />\r\n- gutes R&uuml;ckstellverm&ouml;gen, leichter Einbau<br />\r\n<br />\r\n- zum verschwei&szlig;en und kleben geeignet<br />\r\n<br />\r\n- vertr&auml;glich mit Kunstharz - und DD- Lacken.<br />\r\n<br />\r\n- temperaturbest&auml;ndig -45 Celsius bis + 65 Celsius<br />\r\n<br />\r\n- alterungs-, witterungs-, lichtriss- und ozonbest&auml;ndig. <br />\r\n<br />\r\n- hohe Lebensdauer in Form und Funktion.</span></span></p>','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Kopfbreite&nbsp; =&nbsp;&nbsp;&nbsp; 8,0 mm<br />\r\nFalzh&ouml;he&nbsp;&nbsp;&nbsp; =&nbsp; 12,0 mm <br />\r\nNutbreite&nbsp;&nbsp; =&nbsp;&nbsp;&nbsp; 4,0 mm <br />\r\nges. H&ouml;he&nbsp; =&nbsp; 19,0 mm</span></span></p>','Fensterdichtungen kaufen, Fensterdichtung pfegen,Fensterdichtung Silikon, Dichtung,Fensterdichtung Kunststofffenster, Dichtung erneuern','Fensterdichtung Holzfenster, Dichtung Holzfenster,','Fensterdichtung Holzfenster, Fensterdichtung Holzfenster kaufen, Dichtung Holzfenster, Fensterdichtung austauschen,Fensterdichtung, Fensterd','Fensterdichtungen Holzfenster, Fensterdichtung Holzfenster kaufen, Dichtung Holzfenster,Fenster undicht, Fenterdichtung pflegen. Holzfensterdichtung','','4','');
INSERT INTO `products_description` (`products_id`, `language_id`, `products_name`, `products_description`, `products_short_description`, `products_keywords`, `products_meta_title`, `products_meta_description`, `products_meta_keywords`, `products_url`, `products_viewed`, `products_order_description`) VALUES ('26','2','Holzfensterdichtungen HO TPE RF 0010','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><strong>Eigenschaften:</strong><br />\r\n<br />\r\n- gutes R&uuml;ckstellverm&ouml;gen, leichter Einbau<br />\r\n<br />\r\n- zum verschwei&szlig;en und kleben geeignet<br />\r\n<br />\r\n- vertr&auml;glich mit Kunstharz - und DD- Lacken.<br />\r\n<br />\r\n- temperaturbest&auml;ndig -45 Celsius bis + 65 Celsius<br />\r\n<br />\r\n- alterungs-, witterungs-, lichtriss- und ozonbest&auml;ndig. <br />\r\n<br />\r\n- hohe Lebensdauer in Form und Funktion.</span></span></p>','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: small;\"><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Kopfbreite&nbsp; =&nbsp;&nbsp;&nbsp; 8,5 mm<br />\r\nFalzh&ouml;he&nbsp;&nbsp;&nbsp; =&nbsp; 12,0 mm <br />\r\nNutbreite&nbsp;&nbsp; =&nbsp;&nbsp;&nbsp; 4,0 mm <br />\r\nges. H&ouml;he&nbsp; =&nbsp; 19,0 mm</span></span></span></span></span></p>','Fensterdichtungen kaufen, Fensterdichtung pfegen,Fensterdichtung Silikon, Dichtung,Fensterdichtung Kunststofffenster, Dichtung erneuern','Fensterdichtung Holzfenster, Dichtung Holzfenster,','Fensterdichtung Holzfenster, Fensterdichtung Holzfenster kaufen, Dichtung Holzfenster, Fensterdichtung austauschen,Fensterdichtung, Fensterd','Fensterdichtungen Holzfenster, Fensterdichtung Holzfenster kaufen, Dichtung Holzfenster,Fenster undicht, Fenterdichtung pflegen. Holzfensterdichtung','','12','');
INSERT INTO `products_description` (`products_id`, `language_id`, `products_name`, `products_description`, `products_short_description`, `products_keywords`, `products_meta_title`, `products_meta_description`, `products_meta_keywords`, `products_url`, `products_viewed`, `products_order_description`) VALUES ('27','2','Holzfensterdichtung HO TPE RF 0013','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><strong>Eigenschaften:</strong><br />\r\n<br />\r\n- gutes R&uuml;ckstellverm&ouml;gen, leichter Einbau<br />\r\n<br />\r\n- zum verschwei&szlig;en und kleben geeignet<br />\r\n<br />\r\n- vertr&auml;glich mit Kunstharz - und DD- Lacken.<br />\r\n<br />\r\n- temperaturbest&auml;ndig -45 Celsius bis + 65 Celsius<br />\r\n<br />\r\n- alterungs-, witterungs-, lichtriss- und ozonbest&auml;ndig. <br />\r\n<br />\r\n- hohe Lebensdauer in Form und Funktion.</span></span></p>','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Kopfbreite&nbsp; =&nbsp;&nbsp;&nbsp; 8,0 mm<br />\r\nFalzh&ouml;he&nbsp;&nbsp;&nbsp; =&nbsp; 10,0 mm <br />\r\nNutbreite&nbsp;&nbsp; =&nbsp;&nbsp;&nbsp; 4,0 mm <br />\r\nges. H&ouml;he&nbsp; =&nbsp; 17,0 mm</span></span></p>','','','','','','3','');
INSERT INTO `products_description` (`products_id`, `language_id`, `products_name`, `products_description`, `products_short_description`, `products_keywords`, `products_meta_title`, `products_meta_description`, `products_meta_keywords`, `products_url`, `products_viewed`, `products_order_description`) VALUES ('28','2','Holzfensterdichtung HO TPE RF 0021','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><strong>Eigenschaften:</strong><br />\r\n<br />\r\n- gutes R&uuml;ckstellverm&ouml;gen, leichter Einbau<br />\r\n<br />\r\n- zum verschwei&szlig;en und kleben geeignet<br />\r\n<br />\r\n- vertr&auml;glich mit Kunstharz - und DD- Lacken.<br />\r\n<br />\r\n- temperaturbest&auml;ndig -45 Celsius bis + 65 Celsius<br />\r\n<br />\r\n- alterungs-, witterungs-, lichtriss- und ozonbest&auml;ndig. <br />\r\n<br />\r\n- hohe Lebensdauer in Form und Funktion.</span></span></p>','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Kopfbreite&nbsp; =&nbsp;&nbsp;&nbsp; 8,5 mm<br />\r\nFalzh&ouml;he&nbsp;&nbsp;&nbsp; =&nbsp; 10,0 mm <br />\r\nNutbreite&nbsp;&nbsp; =&nbsp;&nbsp;&nbsp; 4,0 mm <br />\r\nges. H&ouml;he&nbsp; =&nbsp; 17,0 mm</span></span></p>','Fensterdichtungen kaufen, Fensterdichtung pfegen,Fensterdichtung Silikon, Dichtung,Fensterdichtung Kunststofffenster, Dichtung erneuern','Fensterdichtung Holzfenster, Dichtung Holzfenster,','Fensterdichtung Holzfenster, Fensterdichtung Holzfenster kaufen, Dichtung Holzfenster, Fensterdichtung austauschen,Fensterdichtung, Fensterd','Fensterdichtungen Holzfenster, Fensterdichtung Holzfenster kaufen, Dichtung Holzfenster,Fenster undicht, Fenterdichtung pflegen. Holzfensterdichtung','','1','');
INSERT INTO `products_description` (`products_id`, `language_id`, `products_name`, `products_description`, `products_short_description`, `products_keywords`, `products_meta_title`, `products_meta_description`, `products_meta_keywords`, `products_url`, `products_viewed`, `products_order_description`) VALUES ('29','2','Holzfensterdichtungen HO TPE RF 0024','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><strong>Eigenschaften:</strong><br />\r\n<br />\r\n- gutes R&uuml;ckstellverm&ouml;gen, leichter Einbau<br />\r\n<br />\r\n- zum verschwei&szlig;en und kleben geeignet<br />\r\n<br />\r\n- vertr&auml;glich mit Kunstharz - und DD- Lacken.<br />\r\n<br />\r\n- temperaturbest&auml;ndig -45 Celsius bis + 65 Celsius<br />\r\n<br />\r\n- alterungs-, witterungs-, lichtriss- und ozonbest&auml;ndig. <br />\r\n<br />\r\n- hohe Lebensdauer in Form und Funktion.</span></span></p>','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: small;\"><span style=\"font-size: medium;\"><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Kopfbreite&nbsp; =&nbsp;&nbsp;&nbsp; 8,0 mm<br />\r\nFalzh&ouml;he&nbsp;&nbsp;&nbsp; =&nbsp; 10,0 mm <br />\r\nNutbreite&nbsp;&nbsp; =&nbsp;&nbsp;&nbsp; 5,0 mm <br />\r\nges. H&ouml;he&nbsp; =&nbsp; 17,0 mm</span></span></span></span></span></p>','Fensterdichtungen kaufen, Fensterdichtung pfegen,Fensterdichtung Silikon, Dichtung,Fensterdichtung Kunststofffenster, Dichtung erneuern','Fensterdichtung Holzfenster, Dichtung Holzfenster,','Fensterdichtung Holzfenster, Fensterdichtung Holzfenster kaufen, Dichtung Holzfenster, Fensterdichtung austauschen,Fensterdichtung, Fensterd','Fensterdichtungen Holzfenster, Fensterdichtung Holzfenster kaufen, Dichtung Holzfenster,Fenster undicht, Fenterdichtung pflegen. Holzfensterdichtung','','3','');
INSERT INTO `products_description` (`products_id`, `language_id`, `products_name`, `products_description`, `products_short_description`, `products_keywords`, `products_meta_title`, `products_meta_description`, `products_meta_keywords`, `products_url`, `products_viewed`, `products_order_description`) VALUES ('30','2','Holzfensterdichtung HO TPE RF 0011','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><strong>Eigenschaften:</strong><br />\r\n<br />\r\n- gutes R&uuml;ckstellverm&ouml;gen, leichter Einbau<br />\r\n<br />\r\n- zum verschwei&szlig;en und kleben geeignet<br />\r\n<br />\r\n- vertr&auml;glich mit Kunstharz - und DD- Lacken.<br />\r\n<br />\r\n- temperaturbest&auml;ndig -45 Celsius bis + 65 Celsius<br />\r\n<br />\r\n- alterungs-, witterungs-, lichtriss- und ozonbest&auml;ndig. <br />\r\n<br />\r\n- hohe Lebensdauer in Form und Funktion.</span></span></p>','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Kopfbreite&nbsp; =&nbsp;&nbsp;&nbsp; 8,5 mm<br />\r\nFalzh&ouml;he&nbsp;&nbsp;&nbsp; =&nbsp; 10,0 mm <br />\r\nNutbreite&nbsp;&nbsp; =&nbsp;&nbsp;&nbsp; 5,0 mm <br />\r\nges. H&ouml;he&nbsp; =&nbsp; 17,0 mm</span></span></p>','Fensterdichtung Holzfenster nachrüsten','Fensterdichtung Holzfenster, Dichtung Holzfenster,','Fensterdichtung Holzfenster, Fensterdichtung Holzfenster kaufen, Dichtung Holzfenster, Fensterdichtung austauschen,Fensterdichtung, Fensterd','Fensterdichtungen Holzfenster, Fensterdichtung Holzfenster kaufen, Dichtung Holzfenster,Fenster undicht, Fenterdichtung pflegen. Holzfensterdichtung','','7','');
INSERT INTO `products_description` (`products_id`, `language_id`, `products_name`, `products_description`, `products_short_description`, `products_keywords`, `products_meta_title`, `products_meta_description`, `products_meta_keywords`, `products_url`, `products_viewed`, `products_order_description`) VALUES ('32','2','Holzfensterdichtung HO TPE RF 0004','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><strong>Eigenschaften:</strong><br />\r\n<br />\r\n- gutes R&uuml;ckstellverm&ouml;gen, leichter Einbau<br />\r\n<br />\r\n- zum verschwei&szlig;en und kleben geeignet<br />\r\n<br />\r\n- vertr&auml;glich mit Kunstharz - und DD- Lacken.<br />\r\n<br />\r\n- temperaturbest&auml;ndig -45 Celsius bis + 65 Celsius<br />\r\n<br />\r\n- alterungs-, witterungs-, lichtriss- und ozonbest&auml;ndig. <br />\r\n<br />\r\n- hohe Lebensdauer in Form und Funktion.</span></span></p>','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Kopfbreite&nbsp; =&nbsp;&nbsp;&nbsp; 8,5 mm<br />\r\nFalzh&ouml;he&nbsp;&nbsp;&nbsp; =&nbsp; 15,0 mm <br />\r\nNutbreite&nbsp;&nbsp; =&nbsp;&nbsp;&nbsp; 5,0 mm <br />\r\nges. H&ouml;he&nbsp; =&nbsp; 22,0 mm</span></span></p>','Fensterdichtung Holzfenster nachrüsten','Fensterdichtung Holzfenster, Dichtung Holzfenster,','Fensterdichtung Holzfenster, Fensterdichtung Holzfenster kaufen, Dichtung Holzfenster, Fensterdichtung austauschen,Fensterdichtung, Fensterd','Fensterdichtungen Holzfenster, Fensterdichtung Holzfenster kaufen, Dichtung Holzfenster,Fenster undicht, Fenterdichtung pflegen. Holzfensterdichtung','','9','');
INSERT INTO `products_description` (`products_id`, `language_id`, `products_name`, `products_description`, `products_short_description`, `products_keywords`, `products_meta_title`, `products_meta_description`, `products_meta_keywords`, `products_url`, `products_viewed`, `products_order_description`) VALUES ('33','2','Holzfensterdichtung HO TPE RF 1840','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><strong>Eigenschaften:</strong><br />\r\n<br />\r\n- gutes R&uuml;ckstellverm&ouml;gen, leichter Einbau<br />\r\n<br />\r\n- zum verschwei&szlig;en und kleben geeignet<br />\r\n<br />\r\n- vertr&auml;glich mit Kunstharz - und DD- Lacken.<br />\r\n<br />\r\n- temperaturbest&auml;ndig -45 Celsius bis + 65 Celsius<br />\r\n<br />\r\n- alterungs-, witterungs-, lichtriss- und ozonbest&auml;ndig. <br />\r\n<br />\r\n- hohe Lebensdauer in Form und Funktion.</span></span></p>','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Kopfbreite&nbsp; =&nbsp;&nbsp;&nbsp; 8,0 mm<br />\r\nFalzh&ouml;he&nbsp;&nbsp;&nbsp; =&nbsp; 18,0 mm <br />\r\nNutbreite&nbsp;&nbsp; =&nbsp;&nbsp;&nbsp; 4,0 mm <br />\r\nges. H&ouml;he&nbsp; =&nbsp; 25,0 mm</span></span></p>','Fensterdichtungen kaufen, Fensterdichtung pfegen,Fensterdichtung Silikon, Dichtung,Fensterdichtung Kunststofffenster, Dichtung erneuern','Fensterdichtung Holzfenster, Dichtung Holzfenster,','Fensterdichtung Holzfenster, Fensterdichtung Holzfenster kaufen, Dichtung Holzfenster, Fensterdichtung austauschen,Fensterdichtung, Fensterd','Fensterdichtungen Holzfenster, Fensterdichtung Holzfenster kaufen, Dichtung Holzfenster,Fenster undicht, Fenterdichtung pflegen. Holzfensterdichtung','','2','');
INSERT INTO `products_description` (`products_id`, `language_id`, `products_name`, `products_description`, `products_short_description`, `products_keywords`, `products_meta_title`, `products_meta_description`, `products_meta_keywords`, `products_url`, `products_viewed`, `products_order_description`) VALUES ('34','2','Holzfensterdichtung HO TPE RF 0005','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><strong>Eigenschaften:</strong><br />\r\n<br />\r\n- gutes R&uuml;ckstellverm&ouml;gen, leichter Einbau<br />\r\n<br />\r\n- zum verschwei&szlig;en und kleben geeignet<br />\r\n<br />\r\n- vertr&auml;glich mit Kunstharz - und DD- Lacken.<br />\r\n<br />\r\n- temperaturbest&auml;ndig -45 Celsius bis + 65 Celsius<br />\r\n<br />\r\n- alterungs-, witterungs-, lichtriss- und ozonbest&auml;ndig. <br />\r\n<br />\r\n- hohe Lebensdauer in Form und Funktion.</span></span></p>','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Kopfbreite&nbsp; =&nbsp;&nbsp;&nbsp; 8,5 mm<br />\r\nFalzh&ouml;he&nbsp;&nbsp;&nbsp; =&nbsp; 18,0 mm <br />\r\nNutbreite&nbsp;&nbsp; =&nbsp;&nbsp;&nbsp; 5,0 mm <br />\r\nges. H&ouml;he&nbsp; =&nbsp; 25,0 mm</span></span></p>','Fensterdichtungen kaufen, Fensterdichtung pfegen,Fensterdichtung Silikon, Dichtung,Fensterdichtung Kunststofffenster, Dichtung erneuern','Fensterdichtung Holzfenster, Dichtung Holzfenster,','Fensterdichtung Holzfenster, Fensterdichtung Holzfenster kaufen, Dichtung Holzfenster, Fensterdichtung austauschen,Fensterdichtung, Fensterd','Fensterdichtungen Holzfenster, Fensterdichtung Holzfenster kaufen, Dichtung Holzfenster,Fenster undicht, Fenterdichtung pflegen. Holzfensterdichtung','','4','');
INSERT INTO `products_description` (`products_id`, `language_id`, `products_name`, `products_description`, `products_short_description`, `products_keywords`, `products_meta_title`, `products_meta_description`, `products_meta_keywords`, `products_url`, `products_viewed`, `products_order_description`) VALUES ('35','2','Holzfensterdichtung  weich HO - FS - 0125','<p><strong><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Die Produktlinie &bdquo;Super weich&ldquo; - eine neue technische L&ouml;sung !</span></span></strong><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><br />\r\n<br />\r\n</span></span><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Die Basis der Dichtung ist ein Grundelement aus einem festen Werkstoff.</span></span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"> Dies gibt der Dichtung Stabilit&auml;t und sorgt bei der Montage f&uuml;r einen </span></span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">leichten</span></span>&nbsp;<span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"> Einbau in die Nut.<br />\r\n<br />\r\n&nbsp;<br />\r\nDer Profilkopf<br />\r\n<br />\r\nHier kommt ein weicherer besonders hochwertiger Werkstoff<br />\r\n<br />\r\nzur Anwendung, denn dieses Element ist f&uuml;r die Dichtfunktion<br />\r\n<br />\r\nvon entscheidender Bedeutung. Toleranzen werden spielend<br />\r\n<br />\r\nausgeglichen,der Schlie&szlig;druck wird als besonders angenehm<br />\r\n<br />\r\nempfunden.<br />\r\n<br />\r\n&nbsp;<br />\r\nDie Fu&szlig;-Haltelippen<br />\r\n<br />\r\nAuch dieses Konstruktionselement ist entsprechend.<br />\r\n<br />\r\nDie Haltelippen sind Teil des neuentwickelten Profilfu&szlig;es,<br />\r\n<br />\r\ndiese sorgen ebenfalls f&uuml;r leichten Einbau bei gleichzeitig exakten<br />\r\n<br />\r\nHalt und Sitz in der Nut.<br />\r\n<br />\r\n</span></span></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Die farbige Beschichtung<br />\r\n<br />\r\nDie glatte Spezial-Beschichtung ist ebenfalls aus einem besonderen Material.<br />\r\n<br />\r\nAufgrund der glatten Oberfl&auml;che l&auml;sst sich die Dichtung sehr gut reinigen.<br />\r\n</span></span></p>\r\n<p>&nbsp;</p>\r\n<p><img width=\"596\" height=\"634\" src=\"/images/105.jpg\" alt=\"\" />&nbsp;&nbsp;</p>','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Kopfbreite&nbsp; =&nbsp;&nbsp;&nbsp; 9,0 mm<br />\r\nFalzh&ouml;he&nbsp;&nbsp;&nbsp; =&nbsp; 12,0 mm <br />\r\nNutbreite&nbsp;&nbsp; =&nbsp;&nbsp;&nbsp; 5,0 mm <br />\r\nges. H&ouml;he&nbsp; =&nbsp; 19,0 mm</span></span></p>','Fensterdichtungen kaufen, Fensterdichtung pfegen,Fensterdichtung Silikon, Dichtung,Fensterdichtung Kunststofffenster, Dichtung erneuern','Fensterdichtung Holzfenster, Dichtung Holzfenster,','Fensterdichtung Holzfenster, Fensterdichtung Holzfenster kaufen, Dichtung Holzfenster, Fensterdichtung austauschen,Fensterdichtung, Fensterd','Fensterdichtungen Holzfenster, Fensterdichtung Holzfenster kaufen, Dichtung Holzfenster,Fenster undicht, Fenterdichtung pflegen. Holzfensterdichtung','','14','');
INSERT INTO `products_description` (`products_id`, `language_id`, `products_name`, `products_description`, `products_short_description`, `products_keywords`, `products_meta_title`, `products_meta_description`, `products_meta_keywords`, `products_url`, `products_viewed`, `products_order_description`) VALUES ('36','2','Holzfensterdichtung  weich HO - FS - 0155','<p><strong><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Die Produktlinie &bdquo;Super weich&ldquo; - eine neue technische L&ouml;sung !</span></span></strong><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><br />\r\n<br />\r\n</span></span><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Die Basis der Dichtung ist ein Grundelement aus einem festen Werkstoff.</span></span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"> Dies gibt der Dichtung Stabilit&auml;t und sorgt bei der Montage f&uuml;r einen </span></span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">leichten</span></span>&nbsp;<span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"> Einbau in die Nut.<br />\r\n<br />\r\n&nbsp;<br />\r\nDer Profilkopf<br />\r\n<br />\r\nHier kommt ein weicherer besonders hochwertiger Werkstoff<br />\r\n<br />\r\nzur Anwendung, denn dieses Element ist f&uuml;r die Dichtfunktion<br />\r\n<br />\r\nvon entscheidender Bedeutung. Toleranzen werden spielend<br />\r\n<br />\r\nausgeglichen,der Schlie&szlig;druck wird als besonders angenehm<br />\r\n<br />\r\nempfunden.<br />\r\n<br />\r\n&nbsp;<br />\r\nDie Fu&szlig;-Haltelippen<br />\r\n<br />\r\nAuch dieses Konstruktionselement ist entsprechend.<br />\r\n<br />\r\nDie Haltelippen sind Teil des neuentwickelten Profilfu&szlig;es,<br />\r\n<br />\r\ndiese sorgen ebenfalls f&uuml;r leichten Einbau bei gleichzeitig exakten<br />\r\n<br />\r\nHalt und Sitz in der Nut.<br />\r\n<br />\r\n</span></span></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Die farbige Beschichtung<br />\r\n<br />\r\nDie glatte Spezial-Beschichtung ist ebenfalls aus einem besonderen Material.<br />\r\n<br />\r\nAufgrund der glatten Oberfl&auml;che l&auml;sst sich die Dichtung sehr gut reinigen.<br />\r\n</span></span></p>\r\n<p>&nbsp;</p>\r\n<p><img width=\"596\" height=\"634\" src=\"/images/105.jpg\" alt=\"\" /></p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Kopfbreite&nbsp; =&nbsp;&nbsp;&nbsp; 8,5 mm<br />\r\nFalzh&ouml;he&nbsp;&nbsp;&nbsp; =&nbsp; 15,0 mm <br />\r\nNutbreite&nbsp;&nbsp; =&nbsp;&nbsp;&nbsp; 5,5 mm <br />\r\nges. H&ouml;he&nbsp; = &nbsp;22,0 mm</span></span></p>','Fensterdichtungen kaufen, Fensterdichtung pfegen,Fensterdichtung Silikon, Dichtung,Fensterdichtung Kunststofffenster, Dichtung erneuern','Fensterdichtung Holzfenster, Dichtung Holzfenster,','Fensterdichtung Holzfenster, Fensterdichtung Holzfenster kaufen, Dichtung Holzfenster, Fensterdichtung austauschen,Fensterdichtung, Fensterd','Fensterdichtungen Holzfenster, Fensterdichtung Holzfenster kaufen, Dichtung Holzfenster,Fenster undicht, Fenterdichtung pflegen. Holzfensterdichtung','','2','');
INSERT INTO `products_description` (`products_id`, `language_id`, `products_name`, `products_description`, `products_short_description`, `products_keywords`, `products_meta_title`, `products_meta_description`, `products_meta_keywords`, `products_url`, `products_viewed`, `products_order_description`) VALUES ('37','2','Holzfensterdichtung  weich HO - FS - 0185','<p><strong><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Die Produktlinie &bdquo;Super weich&ldquo; - eine neue technische L&ouml;sung !</span></span></strong><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><br />\r\n<br />\r\n</span></span><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Die Basis der Dichtung ist ein Grundelement aus einem festen Werkstoff.</span></span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"> Dies gibt der Dichtung Stabilit&auml;t und sorgt bei der Montage f&uuml;r einen </span></span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">leichten</span></span>&nbsp;<span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"> Einbau in die Nut.<br />\r\n<br />\r\n&nbsp;<br />\r\nDer Profilkopf<br />\r\n<br />\r\nHier kommt ein weicherer besonders hochwertiger Werkstoff<br />\r\n<br />\r\nzur Anwendung, denn dieses Element ist f&uuml;r die Dichtfunktion<br />\r\n<br />\r\nvon entscheidender Bedeutung. Toleranzen werden spielend<br />\r\n<br />\r\nausgeglichen,der Schlie&szlig;druck wird als besonders angenehm<br />\r\n<br />\r\nempfunden.<br />\r\n<br />\r\n&nbsp;<br />\r\nDie Fu&szlig;-Haltelippen<br />\r\n<br />\r\nAuch dieses Konstruktionselement ist entsprechend.<br />\r\n<br />\r\nDie Haltelippen sind Teil des neuentwickelten Profilfu&szlig;es,<br />\r\n<br />\r\ndiese sorgen ebenfalls f&uuml;r leichten Einbau bei gleichzeitig exakten<br />\r\n<br />\r\nHalt und Sitz in der Nut.<br />\r\n<br />\r\n</span></span></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Die farbige Beschichtung<br />\r\n<br />\r\nDie glatte Spezial-Beschichtung ist ebenfalls aus einem besonderen Material.<br />\r\n<br />\r\nAufgrund der glatten Oberfl&auml;che l&auml;sst sich die Dichtung sehr gut reinigen.<br />\r\n</span></span></p>\r\n<p>&nbsp;</p>\r\n<p><img width=\"596\" height=\"634\" src=\"/images/105.jpg\" alt=\"\" /></p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p><img width=\"596\" height=\"634\" alt=\"\" src=\"/images/105.jpg\" /></p>','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Kopfbreite&nbsp; =&nbsp;&nbsp;&nbsp; 8,5 mm<br />\r\nFalzh&ouml;he&nbsp;&nbsp;&nbsp; =&nbsp; 18,0 mm <br />\r\nNutbreite&nbsp;&nbsp; =&nbsp;&nbsp;&nbsp; 5,5 mm <br />\r\nges. H&ouml;he&nbsp; = &nbsp;25,0 mm</span></span></p>','Fensterdichtungen kaufen, Fensterdichtung pfegen,Fensterdichtung Silikon, Dichtung,Fensterdichtung Kunststofffenster, Dichtung erneuern','Fensterdichtung Holzfenster, Dichtung Holzfenster,','Fensterdichtung Holzfenster, Fensterdichtung Holzfenster kaufen, Dichtung Holzfenster, Fensterdichtung austauschen,Fensterdichtung, Fensterd','','','2','');
INSERT INTO `products_description` (`products_id`, `language_id`, `products_name`, `products_description`, `products_short_description`, `products_keywords`, `products_meta_title`, `products_meta_description`, `products_meta_keywords`, `products_url`, `products_viewed`, `products_order_description`) VALUES ('38','2','Dichtungskleber für Fensterdichtungen 20 gr.','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><span class=\"art_nr\">Produkttelegramm: Cyan - Acylat Klebstoff<br />\r\n</span></span></span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><br />\r\n&bull;Kleben von Dichtungsprofilen aus APTK / EPDM, <br />\r\n&nbsp; die Sto&szlig;fugen und Gehrungsschnitte der Dichtungen <br />\r\n&nbsp; werden  schnell und dauerhaft verklebt</span></span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\"><br />\r\n&bull;Verklebung der Dichtungsprofile an PVC-HART <br />\r\n&nbsp; oder an ALU-Profilen<br />\r\n&nbsp; Inhalt 20 gr.</span></span></p>','<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">Inhalt : 20 gr. im Fl&auml;schchen<br />\r\n</span></span></p>\r\n<p><span style=\"font-family: Verdana;\"><span style=\"font-size: medium;\">VE = 1 Stck.</span></span></p>','','','','','','6','');
/*!40000 ALTER TABLE `products_description` ENABLE KEYS */;

DROP TABLE IF EXISTS `products_graduated_prices`;
CREATE TABLE `products_graduated_prices` (
  `products_id` int(11) NOT NULL DEFAULT '0',
  `quantity` int(11) NOT NULL DEFAULT '0',
  `unitprice` decimal(15,4) NOT NULL DEFAULT '0.0000',
  KEY `products_id` (`products_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `products_graduated_prices` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_graduated_prices` ENABLE KEYS */;

DROP TABLE IF EXISTS `products_images`;
CREATE TABLE `products_images` (
  `image_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL,
  `image_nr` smallint(6) NOT NULL,
  `image_name` varchar(254) COLLATE latin1_german1_ci NOT NULL,
  PRIMARY KEY (`image_id`)
) ENGINE=MyISAM AUTO_INCREMENT=50 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `products_images` DISABLE KEYS */;
INSERT INTO `products_images` (`image_id`, `products_id`, `image_nr`, `image_name`) VALUES ('9','8','1','8_1.jpg');
INSERT INTO `products_images` (`image_id`, `products_id`, `image_nr`, `image_name`) VALUES ('8','7','1','7_1.jpg');
INSERT INTO `products_images` (`image_id`, `products_id`, `image_nr`, `image_name`) VALUES ('10','9','1','9_1.JPG');
INSERT INTO `products_images` (`image_id`, `products_id`, `image_nr`, `image_name`) VALUES ('11','10','1','10_1.jpg');
INSERT INTO `products_images` (`image_id`, `products_id`, `image_nr`, `image_name`) VALUES ('14','11','1','11_1.jpg');
INSERT INTO `products_images` (`image_id`, `products_id`, `image_nr`, `image_name`) VALUES ('13','12','1','12_1.JPG');
INSERT INTO `products_images` (`image_id`, `products_id`, `image_nr`, `image_name`) VALUES ('18','13','1','13_1.JPG');
INSERT INTO `products_images` (`image_id`, `products_id`, `image_nr`, `image_name`) VALUES ('17','14','1','14_1.jpg');
INSERT INTO `products_images` (`image_id`, `products_id`, `image_nr`, `image_name`) VALUES ('19','15','1','15_1.JPG');
INSERT INTO `products_images` (`image_id`, `products_id`, `image_nr`, `image_name`) VALUES ('29','16','1','16_1.JPG');
INSERT INTO `products_images` (`image_id`, `products_id`, `image_nr`, `image_name`) VALUES ('30','18','1','18_1.JPG');
INSERT INTO `products_images` (`image_id`, `products_id`, `image_nr`, `image_name`) VALUES ('31','20','1','20_1.JPG');
INSERT INTO `products_images` (`image_id`, `products_id`, `image_nr`, `image_name`) VALUES ('32','21','1','21_1.JPG');
INSERT INTO `products_images` (`image_id`, `products_id`, `image_nr`, `image_name`) VALUES ('33','22','1','22_1.JPG');
INSERT INTO `products_images` (`image_id`, `products_id`, `image_nr`, `image_name`) VALUES ('34','23','1','23_1.JPG');
INSERT INTO `products_images` (`image_id`, `products_id`, `image_nr`, `image_name`) VALUES ('35','24','1','24_1.JPG');
INSERT INTO `products_images` (`image_id`, `products_id`, `image_nr`, `image_name`) VALUES ('36','25','1','25_1.JPG');
INSERT INTO `products_images` (`image_id`, `products_id`, `image_nr`, `image_name`) VALUES ('37','26','1','26_1.JPG');
INSERT INTO `products_images` (`image_id`, `products_id`, `image_nr`, `image_name`) VALUES ('38','27','1','27_1.JPG');
INSERT INTO `products_images` (`image_id`, `products_id`, `image_nr`, `image_name`) VALUES ('39','28','1','28_1.JPG');
INSERT INTO `products_images` (`image_id`, `products_id`, `image_nr`, `image_name`) VALUES ('40','29','1','29_1.JPG');
INSERT INTO `products_images` (`image_id`, `products_id`, `image_nr`, `image_name`) VALUES ('41','30','1','30_1.JPG');
INSERT INTO `products_images` (`image_id`, `products_id`, `image_nr`, `image_name`) VALUES ('46','35','1','35_1.JPG');
INSERT INTO `products_images` (`image_id`, `products_id`, `image_nr`, `image_name`) VALUES ('43','32','1','32_1.JPG');
INSERT INTO `products_images` (`image_id`, `products_id`, `image_nr`, `image_name`) VALUES ('44','33','1','33_1.JPG');
INSERT INTO `products_images` (`image_id`, `products_id`, `image_nr`, `image_name`) VALUES ('45','34','1','34_1.JPG');
INSERT INTO `products_images` (`image_id`, `products_id`, `image_nr`, `image_name`) VALUES ('47','36','1','36_1.JPG');
INSERT INTO `products_images` (`image_id`, `products_id`, `image_nr`, `image_name`) VALUES ('48','37','1','37_1.JPG');
INSERT INTO `products_images` (`image_id`, `products_id`, `image_nr`, `image_name`) VALUES ('49','38','1','38_1.jpg');
/*!40000 ALTER TABLE `products_images` ENABLE KEYS */;

DROP TABLE IF EXISTS `products_notifications`;
CREATE TABLE `products_notifications` (
  `products_id` int(11) NOT NULL,
  `customers_id` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`products_id`,`customers_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `products_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_notifications` ENABLE KEYS */;

DROP TABLE IF EXISTS `products_options`;
CREATE TABLE `products_options` (
  `products_options_id` int(11) NOT NULL DEFAULT '0',
  `language_id` tinyint(4) NOT NULL DEFAULT '1',
  `products_options_name` varchar(32) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `products_options_sortorder` int(11) NOT NULL,
  PRIMARY KEY (`products_options_id`,`language_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `products_options` DISABLE KEYS */;
INSERT INTO `products_options` (`products_options_id`, `language_id`, `products_options_name`, `products_options_sortorder`) VALUES ('1','2','Laufende Meter','0');
INSERT INTO `products_options` (`products_options_id`, `language_id`, `products_options_name`, `products_options_sortorder`) VALUES ('2','2','Farbe','0');
/*!40000 ALTER TABLE `products_options` ENABLE KEYS */;

DROP TABLE IF EXISTS `products_options_values`;
CREATE TABLE `products_options_values` (
  `products_options_values_id` int(11) NOT NULL DEFAULT '0',
  `language_id` tinyint(4) NOT NULL DEFAULT '1',
  `products_options_values_name` varchar(64) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`products_options_values_id`,`language_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `products_options_values` DISABLE KEYS */;
INSERT INTO `products_options_values` (`products_options_values_id`, `language_id`, `products_options_values_name`) VALUES ('3','2','18');
INSERT INTO `products_options_values` (`products_options_values_id`, `language_id`, `products_options_values_name`) VALUES ('2','2','6');
INSERT INTO `products_options_values` (`products_options_values_id`, `language_id`, `products_options_values_name`) VALUES ('1','2','5');
INSERT INTO `products_options_values` (`products_options_values_id`, `language_id`, `products_options_values_name`) VALUES ('5','2','25');
INSERT INTO `products_options_values` (`products_options_values_id`, `language_id`, `products_options_values_name`) VALUES ('4','2','24');
INSERT INTO `products_options_values` (`products_options_values_id`, `language_id`, `products_options_values_name`) VALUES ('9','2','weiß');
INSERT INTO `products_options_values` (`products_options_values_id`, `language_id`, `products_options_values_name`) VALUES ('6','2','50');
INSERT INTO `products_options_values` (`products_options_values_id`, `language_id`, `products_options_values_name`) VALUES ('7','2','100');
INSERT INTO `products_options_values` (`products_options_values_id`, `language_id`, `products_options_values_name`) VALUES ('8','2','schwarz');
INSERT INTO `products_options_values` (`products_options_values_id`, `language_id`, `products_options_values_name`) VALUES ('10','2','braun');
INSERT INTO `products_options_values` (`products_options_values_id`, `language_id`, `products_options_values_name`) VALUES ('11','2','grau');
/*!40000 ALTER TABLE `products_options_values` ENABLE KEYS */;

DROP TABLE IF EXISTS `products_options_values_to_products_options`;
CREATE TABLE `products_options_values_to_products_options` (
  `products_options_values_to_products_options_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_options_id` int(11) NOT NULL,
  `products_options_values_id` int(11) NOT NULL,
  PRIMARY KEY (`products_options_values_to_products_options_id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `products_options_values_to_products_options` DISABLE KEYS */;
INSERT INTO `products_options_values_to_products_options` (`products_options_values_to_products_options_id`, `products_options_id`, `products_options_values_id`) VALUES ('17','1','3');
INSERT INTO `products_options_values_to_products_options` (`products_options_values_to_products_options_id`, `products_options_id`, `products_options_values_id`) VALUES ('16','1','2');
INSERT INTO `products_options_values_to_products_options` (`products_options_values_to_products_options_id`, `products_options_id`, `products_options_values_id`) VALUES ('15','1','1');
INSERT INTO `products_options_values_to_products_options` (`products_options_values_to_products_options_id`, `products_options_id`, `products_options_values_id`) VALUES ('20','1','6');
INSERT INTO `products_options_values_to_products_options` (`products_options_values_to_products_options_id`, `products_options_id`, `products_options_values_id`) VALUES ('19','1','5');
INSERT INTO `products_options_values_to_products_options` (`products_options_values_to_products_options_id`, `products_options_id`, `products_options_values_id`) VALUES ('18','1','4');
INSERT INTO `products_options_values_to_products_options` (`products_options_values_to_products_options_id`, `products_options_id`, `products_options_values_id`) VALUES ('23','2','9');
INSERT INTO `products_options_values_to_products_options` (`products_options_values_to_products_options_id`, `products_options_id`, `products_options_values_id`) VALUES ('22','2','8');
INSERT INTO `products_options_values_to_products_options` (`products_options_values_to_products_options_id`, `products_options_id`, `products_options_values_id`) VALUES ('21','1','7');
INSERT INTO `products_options_values_to_products_options` (`products_options_values_to_products_options_id`, `products_options_id`, `products_options_values_id`) VALUES ('24','2','10');
INSERT INTO `products_options_values_to_products_options` (`products_options_values_to_products_options_id`, `products_options_id`, `products_options_values_id`) VALUES ('25','2','11');
/*!40000 ALTER TABLE `products_options_values_to_products_options` ENABLE KEYS */;

DROP TABLE IF EXISTS `products_to_categories`;
CREATE TABLE `products_to_categories` (
  `products_id` int(11) NOT NULL,
  `categories_id` int(11) NOT NULL,
  PRIMARY KEY (`products_id`,`categories_id`),
  KEY `idx_categories_id` (`categories_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `products_to_categories` DISABLE KEYS */;
INSERT INTO `products_to_categories` (`products_id`, `categories_id`) VALUES ('7','2');
INSERT INTO `products_to_categories` (`products_id`, `categories_id`) VALUES ('8','2');
INSERT INTO `products_to_categories` (`products_id`, `categories_id`) VALUES ('9','2');
INSERT INTO `products_to_categories` (`products_id`, `categories_id`) VALUES ('10','2');
INSERT INTO `products_to_categories` (`products_id`, `categories_id`) VALUES ('11','2');
INSERT INTO `products_to_categories` (`products_id`, `categories_id`) VALUES ('12','2');
INSERT INTO `products_to_categories` (`products_id`, `categories_id`) VALUES ('13','4');
INSERT INTO `products_to_categories` (`products_id`, `categories_id`) VALUES ('14','4');
INSERT INTO `products_to_categories` (`products_id`, `categories_id`) VALUES ('15','4');
INSERT INTO `products_to_categories` (`products_id`, `categories_id`) VALUES ('16','4');
INSERT INTO `products_to_categories` (`products_id`, `categories_id`) VALUES ('18','4');
INSERT INTO `products_to_categories` (`products_id`, `categories_id`) VALUES ('20','5');
INSERT INTO `products_to_categories` (`products_id`, `categories_id`) VALUES ('21','5');
INSERT INTO `products_to_categories` (`products_id`, `categories_id`) VALUES ('22','5');
INSERT INTO `products_to_categories` (`products_id`, `categories_id`) VALUES ('23','5');
INSERT INTO `products_to_categories` (`products_id`, `categories_id`) VALUES ('24','5');
INSERT INTO `products_to_categories` (`products_id`, `categories_id`) VALUES ('25','5');
INSERT INTO `products_to_categories` (`products_id`, `categories_id`) VALUES ('26','5');
INSERT INTO `products_to_categories` (`products_id`, `categories_id`) VALUES ('27','5');
INSERT INTO `products_to_categories` (`products_id`, `categories_id`) VALUES ('28','5');
INSERT INTO `products_to_categories` (`products_id`, `categories_id`) VALUES ('29','5');
INSERT INTO `products_to_categories` (`products_id`, `categories_id`) VALUES ('30','5');
INSERT INTO `products_to_categories` (`products_id`, `categories_id`) VALUES ('32','5');
INSERT INTO `products_to_categories` (`products_id`, `categories_id`) VALUES ('33','5');
INSERT INTO `products_to_categories` (`products_id`, `categories_id`) VALUES ('34','5');
INSERT INTO `products_to_categories` (`products_id`, `categories_id`) VALUES ('35','6');
INSERT INTO `products_to_categories` (`products_id`, `categories_id`) VALUES ('36','6');
INSERT INTO `products_to_categories` (`products_id`, `categories_id`) VALUES ('37','6');
INSERT INTO `products_to_categories` (`products_id`, `categories_id`) VALUES ('38','7');
/*!40000 ALTER TABLE `products_to_categories` ENABLE KEYS */;

DROP TABLE IF EXISTS `products_vpe`;
CREATE TABLE `products_vpe` (
  `products_vpe_id` int(11) NOT NULL DEFAULT '0',
  `language_id` tinyint(4) NOT NULL DEFAULT '1',
  `products_vpe_name` varchar(32) COLLATE latin1_german1_ci NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `products_vpe` DISABLE KEYS */;
INSERT INTO `products_vpe` (`products_vpe_id`, `language_id`, `products_vpe_name`) VALUES ('1','2','lfm.');
/*!40000 ALTER TABLE `products_vpe` ENABLE KEYS */;

DROP TABLE IF EXISTS `products_xsell`;
CREATE TABLE `products_xsell` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `products_id` int(10) unsigned NOT NULL DEFAULT '1',
  `products_xsell_grp_name_id` int(10) unsigned NOT NULL DEFAULT '1',
  `xsell_id` int(10) unsigned NOT NULL DEFAULT '1',
  `sort_order` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `products_xsell` DISABLE KEYS */;
INSERT INTO `products_xsell` (`ID`, `products_id`, `products_xsell_grp_name_id`, `xsell_id`, `sort_order`) VALUES ('1','1','0','2','1');
/*!40000 ALTER TABLE `products_xsell` ENABLE KEYS */;

DROP TABLE IF EXISTS `products_xsell_grp_name`;
CREATE TABLE `products_xsell_grp_name` (
  `products_xsell_grp_name_id` int(10) NOT NULL,
  `xsell_sort_order` int(10) NOT NULL DEFAULT '0',
  `language_id` tinyint(4) NOT NULL DEFAULT '1',
  `groupname` varchar(255) COLLATE latin1_german1_ci NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `products_xsell_grp_name` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_xsell_grp_name` ENABLE KEYS */;

DROP TABLE IF EXISTS `reviews`;
CREATE TABLE `reviews` (
  `reviews_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL,
  `customers_id` int(11) DEFAULT NULL,
  `customers_name` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `reviews_rating` int(1) DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `reviews_read` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`reviews_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;

DROP TABLE IF EXISTS `reviews_description`;
CREATE TABLE `reviews_description` (
  `reviews_id` int(11) NOT NULL,
  `languages_id` int(11) NOT NULL,
  `reviews_text` text COLLATE latin1_german1_ci NOT NULL,
  PRIMARY KEY (`reviews_id`,`languages_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `reviews_description` DISABLE KEYS */;
/*!40000 ALTER TABLE `reviews_description` ENABLE KEYS */;

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `sesskey` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `expiry` int(11) unsigned NOT NULL,
  `value` text COLLATE latin1_german1_ci NOT NULL,
  `flag` varchar(5) COLLATE latin1_german1_ci DEFAULT NULL,
  PRIMARY KEY (`sesskey`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
DROP TABLE IF EXISTS `shipping_status`;
CREATE TABLE `shipping_status` (
  `shipping_status_id` int(11) NOT NULL DEFAULT '0',
  `language_id` tinyint(4) NOT NULL DEFAULT '1',
  `shipping_status_name` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `shipping_status_image` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  PRIMARY KEY (`shipping_status_id`,`language_id`),
  KEY `idx_shipping_status_name` (`shipping_status_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `shipping_status` DISABLE KEYS */;
INSERT INTO `shipping_status` (`shipping_status_id`, `language_id`, `shipping_status_name`, `shipping_status_image`) VALUES ('1','1','3-4 Days','');
INSERT INTO `shipping_status` (`shipping_status_id`, `language_id`, `shipping_status_name`, `shipping_status_image`) VALUES ('1','2','3-4 Tage','');
INSERT INTO `shipping_status` (`shipping_status_id`, `language_id`, `shipping_status_name`, `shipping_status_image`) VALUES ('2','1','1 Week','');
INSERT INTO `shipping_status` (`shipping_status_id`, `language_id`, `shipping_status_name`, `shipping_status_image`) VALUES ('2','2','1 Woche','');
INSERT INTO `shipping_status` (`shipping_status_id`, `language_id`, `shipping_status_name`, `shipping_status_image`) VALUES ('3','1','2 Weeks','');
INSERT INTO `shipping_status` (`shipping_status_id`, `language_id`, `shipping_status_name`, `shipping_status_image`) VALUES ('3','2','2 Wochen','');
/*!40000 ALTER TABLE `shipping_status` ENABLE KEYS */;

DROP TABLE IF EXISTS `shop_configuration`;
CREATE TABLE `shop_configuration` (
  `configuration_id` int(11) NOT NULL AUTO_INCREMENT,
  `configuration_key` varchar(255) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `configuration_value` text COLLATE latin1_german1_ci NOT NULL,
  PRIMARY KEY (`configuration_id`),
  KEY `configuration_key` (`configuration_key`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `shop_configuration` DISABLE KEYS */;
INSERT INTO `shop_configuration` (`configuration_id`, `configuration_key`, `configuration_value`) VALUES ('1','SHOP_OFFLINE','');
INSERT INTO `shop_configuration` (`configuration_id`, `configuration_key`, `configuration_value`) VALUES ('2','SHOP_OFFLINE_MSG','<p style=\"text-align: center;\"><span style=\"font-size: large;\"><font face=\"Arial\">Unser Shop ist aufgrund von Wartungsarbeiten im Moment nicht erreichbar.<br /></font><font face=\"Arial\">Bitte besuchen Sie uns zu einem sp&auml;teren Zeitpunkt noch einmal.<br /><br /><br /><br /></font></span><font><font><a href=\"login_admin.php\"><font color=\"#808080\">Login</font></a></font></font><span style=\"font-size: large;\"><font face=\"Arial\"><br /></font></span></p>');
/*!40000 ALTER TABLE `shop_configuration` ENABLE KEYS */;

DROP TABLE IF EXISTS `sofort_orders`;
CREATE TABLE `sofort_orders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `orders_id` int(11) unsigned NOT NULL,
  `transaction_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `payment_method` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `payment_secret` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `serialized_session` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `data_acquired` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `sofort_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `sofort_orders` ENABLE KEYS */;

DROP TABLE IF EXISTS `sofort_orders_notification`;
CREATE TABLE `sofort_orders_notification` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sofort_orders_id` int(11) unsigned NOT NULL,
  `items` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `amount` float NOT NULL,
  `customer_comment` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `seller_comment` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `status_id` int(11) unsigned NOT NULL,
  `status` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `status_reason` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `invoice_status` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `invoice_objection` varchar(45) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `sofort_orders_notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `sofort_orders_notification` ENABLE KEYS */;

DROP TABLE IF EXISTS `sofort_products`;
CREATE TABLE `sofort_products` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `orders_id` int(11) unsigned NOT NULL,
  `orders_products_id` int(11) unsigned NOT NULL,
  `item_id` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `sofort_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `sofort_products` ENABLE KEYS */;

DROP TABLE IF EXISTS `specials`;
CREATE TABLE `specials` (
  `specials_id` int(11) NOT NULL AUTO_INCREMENT,
  `products_id` int(11) NOT NULL,
  `specials_quantity` int(4) NOT NULL,
  `specials_new_products_price` decimal(15,4) NOT NULL,
  `specials_date_added` datetime DEFAULT NULL,
  `specials_last_modified` datetime DEFAULT NULL,
  `expires_date` datetime DEFAULT NULL,
  `date_status_change` datetime DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`specials_id`),
  KEY `idx_specials_products_id` (`products_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `specials` DISABLE KEYS */;
/*!40000 ALTER TABLE `specials` ENABLE KEYS */;

DROP TABLE IF EXISTS `tax_class`;
CREATE TABLE `tax_class` (
  `tax_class_id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_class_title` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `tax_class_description` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `last_modified` datetime DEFAULT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`tax_class_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `tax_class` DISABLE KEYS */;
INSERT INTO `tax_class` (`tax_class_id`, `tax_class_title`, `tax_class_description`, `last_modified`, `date_added`) VALUES ('1','Standardsatz','','0000-00-00 00:00:00','2014-10-16 20:38:36');
INSERT INTO `tax_class` (`tax_class_id`, `tax_class_title`, `tax_class_description`, `last_modified`, `date_added`) VALUES ('2','erm&auml;&szlig;igter Steuersatz','',NULL,'2014-10-16 20:38:36');
/*!40000 ALTER TABLE `tax_class` ENABLE KEYS */;

DROP TABLE IF EXISTS `tax_rates`;
CREATE TABLE `tax_rates` (
  `tax_rates_id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_zone_id` int(11) NOT NULL,
  `tax_class_id` int(11) NOT NULL,
  `tax_priority` int(5) DEFAULT '1',
  `tax_rate` decimal(7,4) NOT NULL,
  `tax_description` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `last_modified` datetime DEFAULT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`tax_rates_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `tax_rates` DISABLE KEYS */;
INSERT INTO `tax_rates` (`tax_rates_id`, `tax_zone_id`, `tax_class_id`, `tax_priority`, `tax_rate`, `tax_description`, `last_modified`, `date_added`) VALUES ('1','5','1','1','19.0000','MwSt. 19%','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `tax_rates` (`tax_rates_id`, `tax_zone_id`, `tax_class_id`, `tax_priority`, `tax_rate`, `tax_description`, `last_modified`, `date_added`) VALUES ('2','5','2','1','7.0000','MwSt. 7%','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `tax_rates` (`tax_rates_id`, `tax_zone_id`, `tax_class_id`, `tax_priority`, `tax_rate`, `tax_description`, `last_modified`, `date_added`) VALUES ('3','6','1','1','0.0000','EU-AUS-UST 0%','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `tax_rates` (`tax_rates_id`, `tax_zone_id`, `tax_class_id`, `tax_priority`, `tax_rate`, `tax_description`, `last_modified`, `date_added`) VALUES ('4','6','2','1','0.0000','EU-AUS-UST 0%','0000-00-00 00:00:00','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `tax_rates` ENABLE KEYS */;

DROP TABLE IF EXISTS `whos_online`;
CREATE TABLE `whos_online` (
  `customer_id` int(11) DEFAULT NULL,
  `full_name` varchar(64) COLLATE latin1_german1_ci NOT NULL,
  `session_id` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `ip_address` varchar(39) COLLATE latin1_german1_ci NOT NULL,
  `time_entry` varchar(14) COLLATE latin1_german1_ci NOT NULL,
  `time_last_click` varchar(14) COLLATE latin1_german1_ci NOT NULL,
  `last_page_url` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `http_referer` varchar(255) COLLATE latin1_german1_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `whos_online` DISABLE KEYS */;
DROP TABLE IF EXISTS `zones`;
CREATE TABLE `zones` (
  `zone_id` int(11) NOT NULL AUTO_INCREMENT,
  `zone_country_id` int(11) NOT NULL,
  `zone_code` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  `zone_name` varchar(32) COLLATE latin1_german1_ci NOT NULL,
  PRIMARY KEY (`zone_id`)
) ENGINE=MyISAM AUTO_INCREMENT=876 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `zones` DISABLE KEYS */;
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('1','223','AL','Alabama');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('2','223','AK','Alaska');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('3','223','AS','American Samoa');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('4','223','AZ','Arizona');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('5','223','AR','Arkansas');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('6','223','AF','Armed Forces Africa');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('7','223','AA','Armed Forces Americas');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('8','223','AC','Armed Forces Canada');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('9','223','AE','Armed Forces Europe');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('10','223','AM','Armed Forces Middle East');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('11','223','AP','Armed Forces Pacific');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('12','223','CA','California');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('13','223','CO','Colorado');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('14','223','CT','Connecticut');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('15','223','DE','Delaware');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('16','223','DC','District of Columbia');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('17','223','FM','Federated States Of Micronesia');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('18','223','FL','Florida');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('19','223','GA','Georgia');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('20','223','GU','Guam');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('21','223','HI','Hawaii');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('22','223','ID','Idaho');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('23','223','IL','Illinois');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('24','223','IN','Indiana');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('25','223','IA','Iowa');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('26','223','KS','Kansas');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('27','223','KY','Kentucky');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('28','223','LA','Louisiana');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('29','223','ME','Maine');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('30','223','MH','Marshall Islands');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('31','223','MD','Maryland');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('32','223','MA','Massachusetts');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('33','223','MI','Michigan');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('34','223','MN','Minnesota');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('35','223','MS','Mississippi');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('36','223','MO','Missouri');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('37','223','MT','Montana');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('38','223','NE','Nebraska');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('39','223','NV','Nevada');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('40','223','NH','New Hampshire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('41','223','NJ','New Jersey');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('42','223','NM','New Mexico');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('43','223','NY','New York');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('44','223','NC','North Carolina');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('45','223','ND','North Dakota');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('46','223','MP','Northern Mariana Islands');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('47','223','OH','Ohio');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('48','223','OK','Oklahoma');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('49','223','OR','Oregon');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('50','223','PW','Palau');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('51','223','PA','Pennsylvania');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('52','223','PR','Puerto Rico');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('53','223','RI','Rhode Island');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('54','223','SC','South Carolina');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('55','223','SD','South Dakota');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('56','223','TN','Tennessee');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('57','223','TX','Texas');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('58','223','UT','Utah');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('59','223','VT','Vermont');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('60','223','VI','Virgin Islands');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('61','223','VA','Virginia');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('62','223','WA','Washington');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('63','223','WV','West Virginia');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('64','223','WI','Wisconsin');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('65','223','WY','Wyoming');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('66','38','AB','Alberta');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('67','38','BC','British Columbia');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('68','38','MB','Manitoba');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('69','38','NF','Newfoundland');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('70','38','NB','New Brunswick');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('71','38','NS','Nova Scotia');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('72','38','NT','Northwest Territories');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('73','38','NU','Nunavut');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('74','38','ON','Ontario');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('75','38','PE','Prince Edward Island');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('76','38','QC','Quebec');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('77','38','SK','Saskatchewan');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('78','38','YT','Yukon Territory');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('79','81','NI','Niedersachsen');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('80','81','BW','Baden-W�rttemberg');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('81','81','BY','Bayern');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('82','81','BE','Berlin');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('83','81','BR','Brandenburg');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('84','81','HB','Bremen');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('85','81','HH','Hamburg');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('86','81','HE','Hessen');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('87','81','MV','Mecklenburg-Vorpommern');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('88','81','NW','Nordrhein-Westfalen');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('89','81','RP','Rheinland-Pfalz');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('90','81','SL','Saarland');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('91','81','SN','Sachsen');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('92','81','ST','Sachsen-Anhalt');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('93','81','SH','Schleswig-Holstein');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('94','81','TH','Th�ringen');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('95','14','WI','Wien');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('96','14','NO','Nieder�sterreich');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('97','14','OO','Ober�sterreich');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('98','14','SB','Salzburg');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('99','14','KN','K�rnten');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('100','14','ST','Steiermark');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('101','14','TI','Tirol');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('102','14','BL','Burgenland');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('103','14','VB','Voralberg');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('104','204','AG','Aargau');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('105','204','AI','Appenzell Innerrhoden');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('106','204','AR','Appenzell Ausserrhoden');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('107','204','BE','Bern');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('108','204','BL','Basel-Landschaft');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('109','204','BS','Basel-Stadt');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('110','204','FR','Freiburg');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('111','204','GE','Genf');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('112','204','GL','Glarus');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('113','204','JU','Graub�nden');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('114','204','JU','Jura');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('115','204','LU','Luzern');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('116','204','NE','Neuenburg');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('117','204','NW','Nidwalden');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('118','204','OW','Obwalden');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('119','204','SG','St. Gallen');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('120','204','SH','Schaffhausen');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('121','204','SO','Solothurn');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('122','204','SZ','Schwyz');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('123','204','TG','Thurgau');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('124','204','TI','Tessin');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('125','204','UR','Uri');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('126','204','VD','Waadt');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('127','204','VS','Wallis');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('128','204','ZG','Zug');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('129','204','ZH','Z�rich');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('130','195','A Coru�a','A Coru�a');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('131','195','Alava','Alava');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('132','195','Albacete','Albacete');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('133','195','Alicante','Alicante');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('134','195','Almeria','Almeria');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('135','195','Asturias','Asturias');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('136','195','Avila','Avila');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('137','195','Badajoz','Badajoz');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('138','195','Baleares','Baleares');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('139','195','Barcelona','Barcelona');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('140','195','Burgos','Burgos');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('141','195','Caceres','Caceres');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('142','195','Cadiz','Cadiz');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('143','195','Cantabria','Cantabria');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('144','195','Castellon','Castellon');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('145','195','Ceuta','Ceuta');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('146','195','Ciudad Real','Ciudad Real');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('147','195','Cordoba','Cordoba');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('148','195','Cuenca','Cuenca');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('149','195','Girona','Girona');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('150','195','Granada','Granada');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('151','195','Guadalajara','Guadalajara');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('152','195','Guipuzcoa','Guipuzcoa');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('153','195','Huelva','Huelva');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('154','195','Huesca','Huesca');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('155','195','Jaen','Jaen');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('156','195','La Rioja','La Rioja');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('157','195','Las Palmas','Las Palmas');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('158','195','Leon','Leon');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('159','195','Lleida','Lleida');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('160','195','Lugo','Lugo');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('161','195','Madrid','Madrid');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('162','195','Malaga','Malaga');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('163','195','Melilla','Melilla');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('164','195','Murcia','Murcia');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('165','195','Navarra','Navarra');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('166','195','Ourense','Ourense');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('167','195','Palencia','Palencia');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('168','195','Pontevedra','Pontevedra');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('169','195','Salamanca','Salamanca');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('170','195','Santa Cruz de Tenerife','Santa Cruz de Tenerife');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('171','195','Segovia','Segovia');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('172','195','Sevilla','Sevilla');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('173','195','Soria','Soria');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('174','195','Tarragona','Tarragona');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('175','195','Teruel','Teruel');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('176','195','Toledo','Toledo');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('177','195','Valencia','Valencia');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('178','195','Valladolid','Valladolid');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('179','195','Vizcaya','Vizcaya');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('180','195','Zamora','Zamora');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('181','195','Zaragoza','Zaragoza');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('182','13','NSW','New South Wales');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('183','13','VIC','Victoria');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('184','13','QLD','Queensland');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('185','13','NT','Northern Territory');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('186','13','WA','Western Australia');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('187','13','SA','South Australia');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('188','13','TAS','Tasmania');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('189','13','ACT','Australian Capital Territory');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('190','153','Northland','Northland');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('191','153','Auckland','Auckland');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('192','153','Waikato','Waikato');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('193','153','Bay of Plenty','Bay of Plenty');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('194','153','Gisborne','Gisborne');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('195','153','Hawkes Bay','Hawkes Bay');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('196','153','Taranaki','Taranaki');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('197','153','Manawatu-Wanganui','Manawatu-Wanganui');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('198','153','Wellington','Wellington');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('199','153','West Coast','West Coast');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('200','153','Canterbury','Canterbury');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('201','153','Otago','Otago');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('202','153','Southland','Southland');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('203','153','Tasman','Tasman');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('204','153','Nelson','Nelson');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('205','153','Marlborough','Marlborough');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('206','30','SP','S�o Paulo');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('207','30','RJ','Rio de Janeiro');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('208','30','PE','Pernanbuco');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('209','30','BA','Bahia');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('210','30','AM','Amazonas');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('211','30','MG','Minas Gerais');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('212','30','ES','Espirito Santo');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('213','30','RS','Rio Grande do Sul');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('214','30','PR','Paran�');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('215','30','SC','Santa Catarina');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('216','30','RG','Rio Grande do Norte');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('217','30','MS','Mato Grosso do Sul');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('218','30','MT','Mato Grosso');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('219','30','GO','Goias');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('220','30','TO','Tocantins');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('221','30','DF','Distrito Federal');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('222','30','RO','Rondonia');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('223','30','AC','Acre');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('224','30','AP','Amapa');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('225','30','RO','Roraima');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('226','30','AL','Alagoas');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('227','30','CE','Cear�');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('228','30','MA','Maranh�o');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('229','30','PA','Par�');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('230','30','PB','Para�ba');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('231','30','PI','Piau�');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('232','30','SE','Sergipe');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('233','43','I','I Regi�n de Tarapac�');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('234','43','II','II Regi�n de Antofagasta');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('235','43','III','III Regi�n de Atacama');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('236','43','IV','IV Regi�n de Coquimbo');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('237','43','V','V Regi�n de Valapara�so');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('238','43','RM','Regi�n Metropolitana');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('239','43','VI','VI Regi�n de L. B. O�higgins');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('240','43','VII','VII Regi�n del Maule');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('241','43','VIII','VIII Regi�n del B�o B�o');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('242','43','IX','IX Regi�n de la Araucan�a');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('243','43','X','X Regi�n de los Lagos');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('244','43','XI','XI Regi�n de Ays�n');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('245','43','XII','XII Regi�n de Magallanes');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('246','47','AMA','Amazonas');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('247','47','ANT','Antioquia');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('248','47','ARA','Arauca');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('249','47','ATL','Atlantico');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('250','47','BOL','Bolivar');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('251','47','BOY','Boyaca');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('252','47','CAL','Caldas');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('253','47','CAQ','Caqueta');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('254','47','CAS','Casanare');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('255','47','CAU','Cauca');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('256','47','CES','Cesar');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('257','47','CHO','Choco');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('258','47','COR','Cordoba');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('259','47','CUN','Cundinamarca');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('260','47','HUI','Huila');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('261','47','GUA','Guainia');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('262','47','GUA','Guajira');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('263','47','GUV','Guaviare');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('264','47','MAG','Magdalena');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('265','47','MET','Meta');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('266','47','NAR','Narino');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('267','47','NDS','Norte de Santander');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('268','47','PUT','Putumayo');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('269','47','QUI','Quindio');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('270','47','RIS','Risaralda');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('271','47','SAI','San Andres Islas');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('272','47','SAN','Santander');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('273','47','SUC','Sucre');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('274','47','TOL','Tolima');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('275','47','VAL','Valle');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('276','47','VAU','Vaupes');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('277','47','VIC','Vichada');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('278','73','Et','Etranger');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('279','73','01','Ain');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('280','73','02','Aisne');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('281','73','03','Allier');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('282','73','04','Alpes de Haute Provence');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('283','73','05','Hautes-Alpes');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('284','73','06','Alpes Maritimes');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('285','73','07','Ard�che');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('286','73','08','Ardennes');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('287','73','09','Ari�ge');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('288','73','10','Aube');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('289','73','11','Aude');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('290','73','12','Aveyron');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('291','73','13','Bouches-du-Rh�ne');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('292','73','14','Calvados');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('293','73','15','Cantal');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('294','73','16','Charente');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('295','73','17','Charente Maritime');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('296','73','18','Cher');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('297','73','19','Corr�ze');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('298','73','2A','Corse du Sud');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('299','73','2B','Haute Corse');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('300','73','21','C�te-d\'Or');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('301','73','22','C�tes-d\'Armor');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('302','73','23','Creuse');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('303','73','24','Dordogne');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('304','73','25','Doubs');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('305','73','26','Dr�me');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('306','73','27','Eure');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('307','73','28','Eure et Loir');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('308','73','29','Finist�re');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('309','73','30','Gard');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('310','73','31','Haute Garonne');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('311','73','32','Gers');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('312','73','33','Gironde');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('313','73','34','H�rault');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('314','73','35','Ille et Vilaine');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('315','73','36','Indre');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('316','73','37','Indre et Loire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('317','73','38','Is�re');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('318','73','39','Jura');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('319','73','40','Landes');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('320','73','41','Loir et Cher');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('321','73','42','Loire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('322','73','43','Haute Loire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('323','73','44','Loire Atlantique');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('324','73','45','Loiret');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('325','73','46','Lot');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('326','73','47','Lot et Garonne');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('327','73','48','Loz�re');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('328','73','49','Maine et Loire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('329','73','50','Manche');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('330','73','51','Marne');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('331','73','52','Haute Marne');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('332','73','53','Mayenne');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('333','73','54','Meurthe et Moselle');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('334','73','55','Meuse');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('335','73','56','Morbihan');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('336','73','57','Moselle');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('337','73','58','Ni�vre');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('338','73','59','Nord');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('339','73','60','Oise');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('340','73','61','Orne');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('341','73','62','Pas de Calais');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('342','73','63','Puy-de-D�me');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('343','73','64','Pyr�n�es-Atlantiques');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('344','73','65','Hautes-Pyr�n�es');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('345','73','66','Pyr�n�es-Orientales');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('346','73','67','Bas Rhin');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('347','73','68','Haut Rhin');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('348','73','69','Rh�ne');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('349','73','70','Haute-Sa�ne');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('350','73','71','Sa�ne-et-Loire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('351','73','72','Sarthe');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('352','73','73','Savoie');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('353','73','74','Haute Savoie');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('354','73','75','Paris');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('355','73','76','Seine Maritime');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('356','73','77','Seine et Marne');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('357','73','78','Yvelines');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('358','73','79','Deux-S�vres');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('359','73','80','Somme');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('360','73','81','Tarn');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('361','73','82','Tarn et Garonne');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('362','73','83','Var');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('363','73','84','Vaucluse');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('364','73','85','Vend�e');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('365','73','86','Vienne');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('366','73','87','Haute Vienne');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('367','73','88','Vosges');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('368','73','89','Yonne');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('369','73','90','Territoire de Belfort');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('370','73','91','Essonne');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('371','73','92','Hauts de Seine');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('372','73','93','Seine St-Denis');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('373','73','94','Val de Marne');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('374','73','95','Val d\'Oise');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('375','73','971 (DOM)','Guadeloupe');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('376','73','972 (DOM)','Martinique');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('377','73','973 (DOM)','Guyane');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('378','73','974 (DOM)','Saint Denis');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('379','73','975 (DOM)','St-Pierre de Miquelon');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('380','73','976 (TOM)','Mayotte');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('381','73','984 (TOM)','Terres australes et Antartiques ');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('382','73','985 (TOM)','Nouvelle Cal�donie');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('383','73','986 (TOM)','Wallis et Futuna');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('384','73','987 (TOM)','Polyn�sie fran�aise');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('385','99','DL','Delhi');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('386','99','MH','Maharashtra');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('387','99','TN','Tamil Nadu');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('388','99','KL','Kerala');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('389','99','AP','Andhra Pradesh');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('390','99','KA','Karnataka');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('391','99','GA','Goa');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('392','99','MP','Madhya Pradesh');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('393','99','PY','Pondicherry');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('394','99','GJ','Gujarat');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('395','99','OR','Orrisa');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('396','99','CA','Chhatisgarh');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('397','99','JH','Jharkhand');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('398','99','BR','Bihar');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('399','99','WB','West Bengal');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('400','99','UP','Uttar Pradesh');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('401','99','RJ','Rajasthan');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('402','99','PB','Punjab');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('403','99','HR','Haryana');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('404','99','CH','Chandigarh');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('405','99','JK','Jammu & Kashmir');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('406','99','HP','Himachal Pradesh');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('407','99','UA','Uttaranchal');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('408','99','LK','Lakshadweep');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('409','99','AN','Andaman & Nicobar');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('410','99','MG','Meghalaya');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('411','99','AS','Assam');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('412','99','DR','Dadra & Nagar Haveli');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('413','99','DN','Daman & Diu');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('414','99','SK','Sikkim');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('415','99','TR','Tripura');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('416','99','MZ','Mizoram');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('417','99','MN','Manipur');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('418','99','NL','Nagaland');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('419','99','AR','Arunachal Pradesh');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('420','105','AG','Agrigento');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('421','105','AL','Alessandria');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('422','105','AN','Ancona');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('423','105','AO','Aosta');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('424','105','AR','Arezzo');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('425','105','AP','Ascoli Piceno');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('426','105','AT','Asti');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('427','105','AV','Avellino');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('428','105','BA','Bari');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('429','105','BT','Barletta-Andria-Trani');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('430','105','BL','Belluno');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('431','105','BN','Benevento');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('432','105','BG','Bergamo');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('433','105','BI','Biella');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('434','105','BO','Bologna');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('435','105','BZ','Bolzano');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('436','105','BS','Brescia');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('437','105','BR','Brindisi');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('438','105','CA','Cagliari');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('439','105','CL','Caltanissetta');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('440','105','CB','Campobasso');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('441','105','CI','Carbonia-Iglesias');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('442','105','CE','Caserta');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('443','105','CT','Catania');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('444','105','CZ','Catanzaro');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('445','105','CH','Chieti');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('446','105','CO','Como');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('447','105','CS','Cosenza');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('448','105','CR','Cremona');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('449','105','KR','Crotone');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('450','105','CN','Cuneo');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('451','105','EN','Enna');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('452','105','FM','Fermo');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('453','105','FE','Ferrara');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('454','105','FI','Firenze');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('455','105','FG','Foggia');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('456','105','FC','Forl�-Cesena');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('457','105','FR','Frosinone');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('458','105','GE','Genova');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('459','105','GO','Gorizia');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('460','105','GR','Grosseto');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('461','105','IM','Imperia');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('462','105','IS','Isernia');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('463','105','SP','La Spezia');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('464','105','AQ','Aquila');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('465','105','LT','Latina');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('466','105','LE','Lecce');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('467','105','LC','Lecco');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('468','105','LI','Livorno');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('469','105','LO','Lodi');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('470','105','LU','Lucca');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('471','105','MC','Macerata');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('472','105','MN','Mantova');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('473','105','MS','Massa-Carrara');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('474','105','MT','Matera');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('475','105','ME','Messina');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('476','105','MI','Milano');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('477','105','MO','Modena');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('478','105','MB','Monza e della Brianza');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('479','105','NA','Napoli');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('480','105','NO','Novara');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('481','105','NU','Nuoro');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('482','105','OT','Olbia-Tempio');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('483','105','OR','Oristano');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('484','105','PD','Padova');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('485','105','PA','Palermo');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('486','105','PR','Parma');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('487','105','PV','Pavia');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('488','105','PG','Perugia');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('489','105','PU','Pesaro e Urbino');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('490','105','PE','Pescara');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('491','105','PC','Piacenza');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('492','105','PI','Pisa');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('493','105','PT','Pistoia');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('494','105','PN','Pordenone');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('495','105','PZ','Potenza');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('496','105','PO','Prato');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('497','105','RG','Ragusa');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('498','105','RA','Ravenna');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('499','105','RC','Reggio di Calabria');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('500','105','RE','Reggio Emilia');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('501','105','RI','Rieti');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('502','105','RN','Rimini');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('503','105','RM','Roma');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('504','105','RO','Rovigo');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('505','105','SA','Salerno');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('506','105','VS','Medio Campidano');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('507','105','SS','Sassari');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('508','105','SV','Savona');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('509','105','SI','Siena');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('510','105','SR','Siracusa');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('511','105','SO','Sondrio');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('512','105','TA','Taranto');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('513','105','TE','Teramo');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('514','105','TR','Terni');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('515','105','TO','Torino');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('516','105','OG','Ogliastra');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('517','105','TP','Trapani');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('518','105','TN','Trento');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('519','105','TV','Treviso');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('520','105','TS','Trieste');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('521','105','UD','Udine');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('522','105','VA','Varese');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('523','105','VE','Venezia');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('524','105','VB','Verbania');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('525','105','VC','Vercelli');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('526','105','VR','Verona');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('527','105','VV','Vibo Valentia');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('528','105','VI','Vicenza');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('529','105','VT','Viterbo');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('530','107','Niigata','Niigata');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('531','107','Toyama','Toyama');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('532','107','Ishikawa','Ishikawa');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('533','107','Fukui','Fukui');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('534','107','Yamanashi','Yamanashi');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('535','107','Nagano','Nagano');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('536','107','Gifu','Gifu');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('537','107','Shizuoka','Shizuoka');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('538','107','Aichi','Aichi');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('539','107','Mie','Mie');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('540','107','Shiga','Shiga');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('541','107','Kyoto','Kyoto');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('542','107','Osaka','Osaka');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('543','107','Hyogo','Hyogo');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('544','107','Nara','Nara');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('545','107','Wakayama','Wakayama');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('546','107','Tottori','Tottori');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('547','107','Shimane','Shimane');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('548','107','Okayama','Okayama');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('549','107','Hiroshima','Hiroshima');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('550','107','Yamaguchi','Yamaguchi');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('551','107','Tokushima','Tokushima');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('552','107','Kagawa','Kagawa');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('553','107','Ehime','Ehime');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('554','107','Kochi','Kochi');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('555','107','Fukuoka','Fukuoka');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('556','107','Saga','Saga');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('557','107','Nagasaki','Nagasaki');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('558','107','Kumamoto','Kumamoto');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('559','107','Oita','Oita');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('560','107','Miyazaki','Miyazaki');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('561','107','Kagoshima','Kagoshima');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('562','129','JOH','Johor');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('563','129','KDH','Kedah');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('564','129','KEL','Kelantan');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('565','129','KL','Kuala Lumpur');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('566','129','MEL','Melaka');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('567','129','NS','Negeri Sembilan');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('568','129','PAH','Pahang');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('569','129','PRK','Perak');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('570','129','PER','Perlis');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('571','129','PP','Pulau Pinang');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('572','129','SAB','Sabah');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('573','129','SWK','Sarawak');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('574','129','SEL','Selangor');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('575','129','TER','Terengganu');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('576','129','LAB','W.P.Labuan');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('577','138','AGS','Aguascalientes');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('578','138','BC','Baja California');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('579','138','BCS','Baja California Sur');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('580','138','CAM','Campeche');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('581','138','COA','Coahuila');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('582','138','COL','Colima');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('583','138','CHI','Chiapas');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('584','138','CHIH','Chihuahua');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('585','138','DF','Distrito Federal');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('586','138','DGO','Durango');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('587','138','MEX','Estado de Mexico');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('588','138','GTO','Guanajuato');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('589','138','GRO','Guerrero');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('590','138','HGO','Hidalgo');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('591','138','JAL','Jalisco');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('592','138','MCH','Michoacan');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('593','138','MOR','Morelos');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('594','138','NAY','Nayarit');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('595','138','NL','Nuevo Leon');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('596','138','OAX','Oaxaca');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('597','138','PUE','Puebla');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('598','138','QRO','Queretaro');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('599','138','QR','Quintana Roo');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('600','138','SLP','San Luis Potosi');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('601','138','SIN','Sinaloa');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('602','138','SON','Sonora');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('603','138','TAB','Tabasco');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('604','138','TMPS','Tamaulipas');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('605','138','TLAX','Tlaxcala');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('606','138','VER','Veracruz');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('607','138','YUC','Yucatan');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('608','138','ZAC','Zacatecas');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('609','160','OSL','Oslo');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('610','160','AKE','Akershus');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('611','160','AUA','Aust-Agder');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('612','160','BUS','Buskerud');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('613','160','FIN','Finnmark');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('614','160','HED','Hedmark');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('615','160','HOR','Hordaland');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('616','160','MOR','M�re og Romsdal');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('617','160','NOR','Nordland');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('618','160','NTR','Nord-Tr�ndelag');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('619','160','OPP','Oppland');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('620','160','ROG','Rogaland');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('621','160','SOF','Sogn og Fjordane');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('622','160','STR','S�r-Tr�ndelag');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('623','160','TEL','Telemark');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('624','160','TRO','Troms');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('625','160','VEA','Vest-Agder');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('626','160','OST','�stfold');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('627','160','SVA','Svalbard');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('628','162','KHI','Karachi');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('629','162','LH','Lahore');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('630','162','ISB','Islamabad');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('631','162','QUE','Quetta');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('632','162','PSH','Peshawar');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('633','162','GUJ','Gujrat');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('634','162','SAH','Sahiwal');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('635','162','FSB','Faisalabad');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('636','162','RIP','Rawal Pindi');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('637','175','AB','Alba');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('638','175','AR','Arad');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('639','175','AG','Arges');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('640','175','BC','Bacau');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('641','175','BH','Bihor');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('642','175','BN','Bistrita-Nasaud');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('643','175','BT','Botosani');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('644','175','BV','Brasov');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('645','175','BR','Braila');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('646','175','B','Bucuresti');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('647','175','BZ','Buzau');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('648','175','CS','Caras-Severin');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('649','175','CL','Calarasi');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('650','175','CJ','Cluj');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('651','175','CT','Constanta');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('652','175','CV','Covasna');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('653','175','DB','Dimbovita');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('654','175','DJ','Dolj');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('655','175','GL','Galati');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('656','175','GR','Giurgiu');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('657','175','GJ','Gorj');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('658','175','HR','Harghita');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('659','175','HD','Hunedoara');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('660','175','IL','Ialomita');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('661','175','IS','Iasi');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('662','175','IF','Ilfov');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('663','175','MM','Maramures');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('664','175','MH','Mehedint');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('665','175','MS','Mures');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('666','175','NT','Neamt');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('667','175','OT','Olt');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('668','175','PH','Prahova');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('669','175','SM','Satu-Mare');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('670','175','SJ','Salaj');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('671','175','SB','Sibiu');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('672','175','SV','Suceava');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('673','175','TR','Teleorman');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('674','175','TM','Timis');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('675','175','TL','Tulcea');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('676','175','VS','Vaslui');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('677','175','VL','Valcea');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('678','175','VN','Vrancea');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('679','193','WP','Western Cape');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('680','193','GP','Gauteng');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('681','193','KZN','Kwazulu-Natal');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('682','193','NC','Northern-Cape');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('683','193','EC','Eastern-Cape');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('684','193','MP','Mpumalanga');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('685','193','NW','North-West');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('686','193','FS','Free State');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('687','193','NP','Northern Province');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('688','215','AA','Adana');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('689','215','AD','Adiyaman');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('690','215','AF','Afyonkarahisar');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('691','215','AG','Agri');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('692','215','AK','Aksaray');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('693','215','AM','Amasya');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('694','215','AN','Ankara');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('695','215','AL','Antalya');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('696','215','AR','Ardahan');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('697','215','AV','Artvin');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('698','215','AY','Aydin');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('699','215','BK','Balikesir');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('700','215','BR','Bartin');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('701','215','BM','Batman');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('702','215','BB','Bayburt');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('703','215','BC','Bilecik');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('704','215','BG','Bing�l');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('705','215','BT','Bitlis');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('706','215','BL','Bolu');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('707','215','BD','Burdur');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('708','215','BU','Bursa');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('709','215','CK','�anakkale');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('710','215','CI','�ankiri');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('711','215','CM','�orum');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('712','215','DN','Denizli');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('713','215','DY','Diyarbakir');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('714','215','DU','D�zce');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('715','215','ED','Edirne');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('716','215','EG','Elazig');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('717','215','EN','Erzincan');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('718','215','EM','Erzurum');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('719','215','ES','Eskisehir');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('720','215','GA','Gaziantep');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('721','215','GI','Giresun');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('722','215','GU','G�m�shane');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('723','215','HK','Hakkari');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('724','215','HT','Hatay');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('725','215','IG','Igdir');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('726','215','IP','Isparta');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('727','215','IB','Istanbul');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('728','215','IZ','Izmir');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('729','215','KM','Kahramanmaras');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('730','215','KB','Karab�k');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('731','215','KR','Karaman');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('732','215','KA','Kars');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('733','215','KS','Kastamonu');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('734','215','KY','Kayseri');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('735','215','KI','Kilis');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('736','215','KK','Kirikkale');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('737','215','KL','Kirklareli');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('738','215','KH','Kirsehir');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('739','215','KC','Kocaeli');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('740','215','KO','Konya');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('741','215','KU','K�tahya');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('742','215','ML','Malatya');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('743','215','MN','Manisa');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('744','215','MR','Mardin');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('745','215','IC','Mersin');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('746','215','MG','Mugla');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('747','215','MS','Mus');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('748','215','NV','Nevsehir');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('749','215','NG','Nigde');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('750','215','OR','Ordu');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('751','215','OS','Osmaniye');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('752','215','RI','Rize');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('753','215','SK','Sakarya');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('754','215','SS','Samsun');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('755','215','SU','Sanliurfa');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('756','215','SI','Siirt');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('757','215','SP','Sinop');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('758','215','SR','Sirnak');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('759','215','SV','Sivas');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('760','215','TG','Tekirdag');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('761','215','TT','Tokat');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('762','215','TB','Trabzon');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('763','215','TC','Tunceli');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('764','215','US','Usak');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('765','215','VA','Van');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('766','215','YL','Yalova');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('767','215','YZ','Yozgat');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('768','215','ZO','Zonguldak');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('769','229','AM','Amazonas');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('770','229','AN','Anzo�tegui');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('771','229','AR','Aragua');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('772','229','AP','Apure');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('773','229','BA','Barinas');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('774','229','BO','Bol�var');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('775','229','CA','Carabobo');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('776','229','CO','Cojedes');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('777','229','DA','Delta Amacuro');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('778','229','DC','Distrito Capital');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('779','229','FA','Falc�n');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('780','229','GA','Gu�rico');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('781','229','GU','Guayana');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('782','229','LA','Lara');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('783','229','ME','M�rida');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('784','229','MI','Miranda');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('785','229','MO','Monagas');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('786','229','NE','Nueva Esparta');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('787','229','PO','Portuguesa');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('788','229','SU','Sucre');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('789','229','TA','T�chira');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('790','229','TU','Trujillo');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('791','229','VA','Vargas');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('792','229','YA','Yaracuy');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('793','229','ZU','Zulia');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('794','222','BAS','Bath and North East Somerset');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('795','222','BDF','Bedfordshire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('796','222','WBK','Berkshire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('797','222','BBD','Blackburn with Darwen');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('798','222','BPL','Blackpool');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('799','222','BPL','Bournemouth');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('800','222','BNH','Brighton and Hove');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('801','222','BST','Bristol');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('802','222','BKM','Buckinghamshire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('803','222','CAM','Cambridgeshire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('804','222','CHS','Cheshire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('805','222','CON','Cornwall');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('806','222','DUR','County Durham');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('807','222','CMA','Cumbria');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('808','222','DAL','Darlington');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('809','222','DER','Derby');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('810','222','DBY','Derbyshire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('811','222','DEV','Devon');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('812','222','DOR','Dorset');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('813','222','ERY','East Riding of Yorkshire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('814','222','ESX','East Sussex');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('815','222','ESS','Essex');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('816','222','GLS','Gloucestershire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('817','222','LND','Greater London');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('818','222','MAN','Greater Manchester');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('819','222','HAL','Halton');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('820','222','HAM','Hampshire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('821','222','HPL','Hartlepool');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('822','222','HEF','Herefordshire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('823','222','HRT','Hertfordshire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('824','222','KHL','Hull');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('825','222','IOW','Isle of Wight');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('826','222','KEN','Kent');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('827','222','LAN','Lancashire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('828','222','LCE','Leicester');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('829','222','LEC','Leicestershire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('830','222','LIN','Lincolnshire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('831','222','LUT','Luton');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('832','222','MDW','Medway');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('833','222','MER','Merseyside');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('834','222','MDB','Middlesbrough');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('835','222','MDB','Milton Keynes');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('836','222','NFK','Norfolk');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('837','222','NTH','Northamptonshire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('838','222','NEL','North East Lincolnshire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('839','222','NLN','North Lincolnshire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('840','222','NSM','North Somerset');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('841','222','NBL','Northumberland');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('842','222','NYK','North Yorkshire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('843','222','NGM','Nottingham');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('844','222','NTT','Nottinghamshire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('845','222','OXF','Oxfordshire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('846','222','PTE','Peterborough');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('847','222','PLY','Plymouth');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('848','222','POL','Poole');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('849','222','POR','Portsmouth');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('850','222','RCC','Redcar and Cleveland');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('851','222','RUT','Rutland');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('852','222','SHR','Shropshire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('853','222','SOM','Somerset');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('854','222','STH','Southampton');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('855','222','SOS','Southend-on-Sea');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('856','222','SGC','South Gloucestershire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('857','222','SYK','South Yorkshire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('858','222','STS','Staffordshire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('859','222','STT','Stockton-on-Tees');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('860','222','STE','Stoke-on-Trent');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('861','222','SFK','Suffolk');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('862','222','SRY','Surrey');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('863','222','SWD','Swindon');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('864','222','TFW','Telford and Wrekin');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('865','222','THR','Thurrock');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('866','222','TOB','Torbay');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('867','222','TYW','Tyne and Wear');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('868','222','WRT','Warrington');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('869','222','WAR','Warwickshire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('870','222','WMI','West Midlands');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('871','222','WSX','West Sussex');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('872','222','WYK','West Yorkshire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('873','222','WIL','Wiltshire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('874','222','WOR','Worcestershire');
INSERT INTO `zones` (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`) VALUES ('875','222','YOR','York');
/*!40000 ALTER TABLE `zones` ENABLE KEYS */;

DROP TABLE IF EXISTS `zones_to_geo_zones`;
CREATE TABLE `zones_to_geo_zones` (
  `association_id` int(11) NOT NULL AUTO_INCREMENT,
  `zone_country_id` int(11) NOT NULL,
  `zone_id` int(11) DEFAULT NULL,
  `geo_zone_id` int(11) DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`association_id`)
) ENGINE=MyISAM AUTO_INCREMENT=240 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

/*!40000 ALTER TABLE `zones_to_geo_zones` DISABLE KEYS */;
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('14','14','0','5',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('21','21','0','5',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('33','33','0','5',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('55','55','0','5',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('56','56','0','5',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('57','57','0','5',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('67','67','0','5',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('72','72','0','5',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('73','73','0','5',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('81','81','0','5',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('84','84','0','5',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('97','97','0','5',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('103','103','0','5',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('105','105','0','5',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('117','117','0','5',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('123','123','0','5',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('124','124','0','5',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('132','132','0','5',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('150','150','0','5',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('170','170','0','5',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('171','171','0','5',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('175','175','0','5',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('189','189','0','5',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('190','190','0','5',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('195','195','0','5',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('203','203','0','5',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('222','222','0','5',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('1','1','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('2','2','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('3','3','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('4','4','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('5','5','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('6','6','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('7','7','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('8','8','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('9','9','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('10','10','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('11','11','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('12','12','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('13','13','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('15','15','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('16','16','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('17','17','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('18','18','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('19','19','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('20','20','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('22','22','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('23','23','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('24','24','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('25','25','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('26','26','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('27','27','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('28','28','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('29','29','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('30','30','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('31','31','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('32','32','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('34','34','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('35','35','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('36','36','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('37','37','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('38','38','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('39','39','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('40','40','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('41','41','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('42','42','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('43','43','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('44','44','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('45','45','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('46','46','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('47','47','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('48','48','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('49','49','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('50','50','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('51','51','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('52','52','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('53','53','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('54','54','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('58','58','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('59','59','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('60','60','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('61','61','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('62','62','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('63','63','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('64','64','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('65','65','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('66','66','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('68','68','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('69','69','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('70','70','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('71','71','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('74','74','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('75','75','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('76','76','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('77','77','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('78','78','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('79','79','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('80','80','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('82','82','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('83','83','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('85','85','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('86','86','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('87','87','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('88','88','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('89','89','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('90','90','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('91','91','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('92','92','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('93','93','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('94','94','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('95','95','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('96','96','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('98','98','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('99','99','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('100','100','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('101','101','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('102','102','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('104','104','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('106','106','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('107','107','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('108','108','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('109','109','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('110','110','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('111','111','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('112','112','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('113','113','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('114','114','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('115','115','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('116','116','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('118','118','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('119','119','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('120','120','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('121','121','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('122','122','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('125','125','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('126','126','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('127','127','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('128','128','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('129','129','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('130','130','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('131','131','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('133','133','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('134','134','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('135','135','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('136','136','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('137','137','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('138','138','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('139','139','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('140','140','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('141','141','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('142','142','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('143','143','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('144','144','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('145','145','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('146','146','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('147','147','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('148','148','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('149','149','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('151','151','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('152','152','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('153','153','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('154','154','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('155','155','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('156','156','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('157','157','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('158','158','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('159','159','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('160','160','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('161','161','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('162','162','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('163','163','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('164','164','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('165','165','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('166','166','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('167','167','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('168','168','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('169','169','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('172','172','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('173','173','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('174','174','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('176','176','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('177','177','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('178','178','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('179','179','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('180','180','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('181','181','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('182','182','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('183','183','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('184','184','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('185','185','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('186','186','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('187','187','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('188','188','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('191','191','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('192','192','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('193','193','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('194','194','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('196','196','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('197','197','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('198','198','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('199','199','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('200','200','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('201','201','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('202','202','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('204','204','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('205','205','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('206','206','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('207','207','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('208','208','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('209','209','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('210','210','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('211','211','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('212','212','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('213','213','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('214','214','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('215','215','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('216','216','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('217','217','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('218','218','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('219','219','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('220','220','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('221','221','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('223','223','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('224','224','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('225','225','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('226','226','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('227','227','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('228','228','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('229','229','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('230','230','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('231','231','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('232','232','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('233','233','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('234','234','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('235','235','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('236','236','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('237','237','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('238','238','0','6',NULL,'2014-10-16 20:38:36');
INSERT INTO `zones_to_geo_zones` (`association_id`, `zone_country_id`, `zone_id`, `geo_zone_id`, `last_modified`, `date_added`) VALUES ('239','239','0','6',NULL,'2014-10-16 20:38:36');
/*!40000 ALTER TABLE `zones_to_geo_zones` ENABLE KEYS */;

